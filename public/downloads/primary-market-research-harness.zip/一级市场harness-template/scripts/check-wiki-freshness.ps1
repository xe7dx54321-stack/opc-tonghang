param(
    [Parameter(Mandatory = $true)]
    [string]$IndustryId,

    [datetime]$AsOf = (Get-Date),

    [switch]$MaterialEvent
)

$ErrorActionPreference = "Stop"

$harnessRoot = Split-Path -Parent $PSScriptRoot
$topicFile = Join-Path $harnessRoot "wiki\$IndustryId\TOPIC.md"

if (-not (Test-Path -LiteralPath $topicFile -PathType Leaf)) {
    throw "Wiki topic not found: $IndustryId"
}

$topic = Get-Content -Raw -Encoding utf8 -LiteralPath $topicFile

function Read-WikiMetadata {
    param(
        [string]$Content,
        [string]$Field
    )

    $pattern = "(?m)^- " + [regex]::Escape($Field) + "(?<value>[^\r\n]*)$"
    $match = [regex]::Match($Content, $pattern)
    if (-not $match.Success) {
        throw "Missing Wiki metadata field '$Field' in $topicFile"
    }
    $rawValue = $match.Groups["value"].Value.Trim()
    $rawValue = $rawValue.TrimStart([char]0xFF1A, [char]0x003A).Trim()
    return $rawValue.Trim('`')
}

function Read-OptionalWikiMetadata {
    param(
        [string]$Content,
        [string]$Field,
        [string]$DefaultValue = ""
    )

    $pattern = "(?m)^- " + [regex]::Escape($Field) + "(?<value>[^\r\n]*)$"
    $match = [regex]::Match($Content, $pattern)
    if (-not $match.Success) { return $DefaultValue }
    $rawValue = $match.Groups["value"].Value.Trim()
    $rawValue = $rawValue.TrimStart([char]0xFF1A, [char]0x003A).Trim()
    return $rawValue.Trim('`')
}

$lastVerifiedText = Read-WikiMetadata -Content $topic -Field "last_verified_at"
$freshnessText = Read-WikiMetadata -Content $topic -Field "freshness_days"
$status = Read-OptionalWikiMetadata -Content $topic -Field "status" -DefaultValue "fresh"
$sourceVerification = Read-OptionalWikiMetadata -Content $topic -Field "source_verification" -DefaultValue "verified"
$topicKind = Read-OptionalWikiMetadata -Content $topic -Field "topic_kind" -DefaultValue "industry"

$lastVerified = [datetime]::ParseExact(
    $lastVerifiedText,
    "yyyy-MM-dd",
    [System.Globalization.CultureInfo]::InvariantCulture
)
$freshnessDays = [int]$freshnessText
$ageDays = [math]::Floor(($AsOf.Date - $lastVerified.Date).TotalDays)

if ($ageDays -lt 0) {
    throw "AsOf date cannot be earlier than last_verified_at."
}

$reasons = [System.Collections.Generic.List[string]]::new()
if ($MaterialEvent.IsPresent) { $reasons.Add("material_event") }
if ($ageDays -gt $freshnessDays) { $reasons.Add("stale") }
if ($status -in @("review_due", "updating")) { $reasons.Add("status_$status") }
if ($sourceVerification -in @("partial", "unverified")) { $reasons.Add("source_$sourceVerification") }

$decision = if ($reasons.Count -gt 0) {
    "quick_update_required"
} else {
    "fresh"
}

[pscustomobject]@{
    industry_id = $IndustryId
    last_verified_at = $lastVerified.ToString("yyyy-MM-dd")
    as_of = $AsOf.ToString("yyyy-MM-dd")
    age_days = $ageDays
    freshness_days = $freshnessDays
    topic_kind = $topicKind
    status = $status
    source_verification = $sourceVerification
    material_event = $MaterialEvent.IsPresent
    decision = $decision
    reasons = @($reasons)
} | ConvertTo-Json
