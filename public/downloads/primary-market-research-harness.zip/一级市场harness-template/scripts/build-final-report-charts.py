import argparse
from pathlib import Path

from PIL import Image, ImageDraw

from font_utils import load_cjk_font


OUT = Path("projects/weijiuguangdian/outputs/investment")
WIDTH, HEIGHT = 2400, 1350
BG = "#F7F9FC"
INK = "#172033"
MUTED = "#667085"
BLUE = "#2667FF"
BLUE_LIGHT = "#BFD1FF"
GREEN = "#00A884"
GRAY = "#8A94A6"
RED = "#E45756"
GRID = "#D7DDE8"


def font(size, bold=False):
    # load_cjk_font() resolves a working CJK font on Windows, macOS, and Linux.
    # On macOS the bold variant falls back to the regular STHeiti weight because
    # Microsoft YaHei Bold is not bundled; PIL still renders the chart legibly.
    return load_cjk_font(size, bold=bold)


def canvas(title, subtitle):
    image = Image.new("RGB", (WIDTH, HEIGHT), BG)
    draw = ImageDraw.Draw(image)
    draw.text((120, 70), title, fill=INK, font=font(52, True))
    draw.text((120, 145), subtitle, fill=MUTED, font=font(26))
    return image, draw


def grid(draw, left, top, right, bottom, max_value, steps, suffix=""):
    for index in range(steps + 1):
        value = max_value * index / steps
        y_value = bottom - (bottom - top) * index / steps
        draw.line((left, y_value, right, y_value), fill=GRID, width=2)
        label = f"{value:g}{suffix}"
        draw.text((left - 95, y_value - 16), label, fill=MUTED, font=font(22))
    draw.line((left, top, left, bottom), fill=INK, width=3)
    draw.line((left, bottom, right, bottom), fill=INK, width=3)


def output_path(name, submission):
    directory = OUT / "word-visuals" if submission else OUT
    directory.mkdir(parents=True, exist_ok=True)
    stem = Path(name).stem + ("-submission" if submission else "")
    return directory / f"{stem}.png"


def financial_scenarios(submission=False):
    image, draw = canvas(
        "微玖光电收入情景：里程碑兑现区间",
        "单位：百万元；中性情景要求北京线有效产能、头部客户商业闭环与良率/成本同步改善",
    )
    left, top, right, bottom = 180, 260, 2260, 1120
    grid(draw, left, top, right, bottom, 5000, 5)
    years = list(range(2026, 2034))
    series = [
        ("保守", [2, 15, 45, 90, 150, 220, 300, 380], GRAY),
        ("中性", [8, 50, 180, 360, 620, 900, 1200, 1500], BLUE),
        ("乐观", [15, 100, 450, 900, 1600, 2500, 3500, 4500], GREEN),
    ]
    x_positions = [left + (right - left) * index / (len(years) - 1) for index in range(len(years))]
    for x_value, year in zip(x_positions, years):
        draw.text((x_value - 34, bottom + 25), str(year), fill=MUTED, font=font(22))
    for series_index, (name, values, color) in enumerate(series):
        points = []
        for x_value, value in zip(x_positions, values):
            y_value = bottom - (bottom - top) * value / 5000
            points.append((x_value, y_value))
        draw.line(points, fill=color, width=8, joint="curve")
        for point_index, ((x_value, y_value), value) in enumerate(zip(points, values)):
            draw.ellipse((x_value - 10, y_value - 10, x_value + 10, y_value + 10), fill=color)
            label_offset = 42 + (2 - series_index) * 28 if point_index < 2 else 45
            draw.text((x_value - 28, y_value - label_offset), str(value), fill=color, font=font(19, True))
    for index, (name, _, color) in enumerate(series):
        x_value = 1780 + index * 155
        draw.line((x_value, 215, x_value + 45, 215), fill=color, width=8)
        draw.text((x_value + 55, 197), name, fill=INK, font=font(23))
    draw.text(
        (120, 1255),
        "当前证据下，大概率区间更接近保守至中性下沿；数字是可证伪情景，不是公司预算。",
        fill=MUTED,
        font=font(24),
    )
    image.save(output_path("02-investment-memo-05-financial-scenarios.png", submission))


def milestone_probability(submission=False):
    image, draw = canvas(
        "里程碑累计概率：短期较高，远期逐级衰减",
        "每步条件于此前全部里程碑；累计区间按概率链式法则逐级相乘",
    )
    left, top, right, bottom = 180, 280, 2260, 1090
    grid(draw, left, top, right, bottom, 80, 8, "%")
    labels = (
        [
            "数据治理\n基线闭环",
            "稳定小批量\n资金覆盖",
            "头部客户\n商业闭环",
            "规模量产",
            "可持续成长\n接近盈亏平衡",
            "具备上市\n申报条件",
            "上市解禁\n开始退出",
        ]
        if submission
        else [
            "M1\n数据/治理",
            "M2\n稳定小批量",
            "M3\n头部客户",
            "M4\n规模量产",
            "M5\n可持续成长",
            "M6\n申报条件",
            "M7\n上市解禁",
        ]
    )
    lows = [65, 33, 13, 6, 3, 1, 0.5]
    highs = [75, 45, 25, 15, 10, 5, 3.5]
    mids = [70, 39, 19, 10.5, 6.5, 3, 2]
    slot = (right - left) / len(labels)
    for index, (label, low, high, mid) in enumerate(zip(labels, lows, highs, mids)):
        center = left + slot * (index + 0.5)
        bar_width = slot * 0.48
        y_high = bottom - (bottom - top) * high / 80
        y_low = bottom - (bottom - top) * low / 80
        draw.rounded_rectangle(
            (center - bar_width / 2, y_high, center + bar_width / 2, y_low),
            radius=12,
            fill=BLUE_LIGHT,
            outline=BLUE,
            width=4,
        )
        y_mid = bottom - (bottom - top) * mid / 80
        draw.ellipse((center - 11, y_mid - 11, center + 11, y_mid + 11), fill=BLUE)
        draw.text((center - 68, y_high - 42), f"{low:g}%–{high:g}%", fill=BLUE, font=font(22, True))
        lines = label.split("\n")
        for line_index, line in enumerate(lines):
            draw.text((center - 68, bottom + 25 + line_index * 30), line, fill=INK, font=font(21))
    draw.text(
        (120, 1250),
        (
            "头部客户商业闭环是第一次出现可交易价值跃升的节点；上市退出应被视为高回报、低概率尾部期权。"
            if submission
            else "M3是第一次出现可交易价值跃升的节点；M7应被视为高回报、低概率尾部期权。"
        ),
        fill=MUTED,
        font=font(24),
    )
    image.save(output_path("02-investment-memo-08-milestone-probability.png", submission))


def exit_paths(submission=False):
    image, draw = canvas(
        "单节点全退回报：里程碑转让与IPO尾部",
        "每1,000万元初始投资、在单一节点100%退出的MOIC；分段组合现金流见报告第7.4节",
    )
    left, top, right, bottom = 220, 280, 2220, 1090
    grid(draw, left, top, right, bottom, 15, 5, "×")
    stages = (
        ["头部客户商业闭环\n2028", "规模量产\n2029", "可持续成长\n2030", "上市解禁\n2033"]
        if submission
        else ["M3 头部客户\n2028", "M4 规模量产\n2029", "M5 可持续成长\n2030", "上市解禁\n2033"]
    )
    lows = [1.39, 1.63, 2.64, 9.13]
    highs = [2.50, 2.74, 3.96, 13.70]
    probabilities = [19, 10.5, 6.5, 2]
    colors = ["#BFD1FF", "#9FC5FF", "#7CB7F7", "#7AD6BA"]
    slot = (right - left) / len(stages)
    for index, (stage, low, high, probability, color) in enumerate(
        zip(stages, lows, highs, probabilities, colors)
    ):
        center = left + slot * (index + 0.5)
        bar_width = slot * 0.46
        y_high = bottom - (bottom - top) * high / 15
        y_low = bottom - (bottom - top) * low / 15
        draw.rounded_rectangle(
            (center - bar_width / 2, y_high, center + bar_width / 2, y_low),
            radius=14,
            fill=color,
            outline=GREEN if index == 3 else BLUE,
            width=4,
        )
        draw.text((center - 75, y_high - 45), f"{low:.2f}–{high:.2f}×", fill=INK, font=font(23, True))
        draw.text((center - 82, y_low + 15), f"累计概率中点≈{probability:g}%", fill=RED, font=font(20))
        for line_index, line in enumerate(stage.split("\n")):
            draw.text((center - 75, bottom + 28 + line_index * 32), line, fill=INK, font=font(22))
    draw.text(
        (120, 1250),
        "若协议未预留转让权、下一轮无买方或里程碑证据不可审计，一级市场退出路径不可执行。",
        fill=MUTED,
        font=font(24),
    )
    image.save(output_path("02-investment-memo-07-exit-paths.png", submission))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--submission", action="store_true")
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    financial_scenarios(args.submission)
    milestone_probability(args.submission)
    exit_paths(args.submission)
    print("created 3 final-report charts" + (" for Word submission" if args.submission else ""))
