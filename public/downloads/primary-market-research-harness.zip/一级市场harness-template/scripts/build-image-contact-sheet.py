from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageDraw

from font_utils import load_cjk_font


def font(size: int):
    # Cross-platform: font_utils resolves the first available CJK font on
    # Windows, macOS, and Linux. On macOS this typically picks STHeiti Medium
    # so the contact-sheet labels render Simplified Chinese without needing
    # Microsoft Office to be installed.
    return load_cjk_font(size, bold=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prefix", default="")
    args = parser.parse_args()

    files = sorted(
        path for path in args.source.glob(f"{args.prefix}*.png")
        if path.is_file() and "contact-sheet" not in path.name
    )
    thumb_w, thumb_h, label_h = 720, 430, 64
    cols = 2
    rows = (len(files) + cols - 1) // cols
    canvas = Image.new("RGB", (cols * thumb_w, rows * (thumb_h + label_h)), "white")
    draw = ImageDraw.Draw(canvas)
    title_font = font(23)
    meta_font = font(18)

    for index, path in enumerate(files):
        image = Image.open(path).convert("RGB")
        original_size = image.size
        image.thumbnail((thumb_w - 28, thumb_h - 28), Image.Resampling.LANCZOS)
        x = (index % cols) * thumb_w
        y = (index // cols) * (thumb_h + label_h)
        px = x + (thumb_w - image.width) // 2
        py = y + (thumb_h - image.height) // 2
        canvas.paste(image, (px, py))
        draw.rectangle((x, y, x + thumb_w - 1, y + thumb_h + label_h - 1), outline="#D0D5DD", width=2)
        draw.text((x + 14, y + thumb_h + 4), path.name, fill="#101828", font=title_font)
        draw.text((x + 14, y + thumb_h + 34), f"{original_size[0]} × {original_size[1]}", fill="#667085", font=meta_font)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(args.output, quality=92)
    print(f"Created {args.output} with {len(files)} images")


if __name__ == "__main__":
    main()
