$ErrorActionPreference = "Stop"
$scriptPath = Join-Path (Split-Path -Parent $PSScriptRoot) "resolve-project-context.ps1"

function ConvertFrom-CodePoints([int[]]$CodePoints) {
    return -join ($CodePoints | ForEach-Object { [char]$_ })
}

$microBrand = ConvertFrom-CodePoints @(0x5FAE, 0x7396, 0x5149, 0x7535)
$microShort = ConvertFrom-CodePoints @(0x5FAE, 0x7396)
$microLegal = ConvertFrom-CodePoints @(0x5FAE, 0x7396, 0xFF08, 0x82CF, 0x5DDE, 0xFF09, 0x5149, 0x7535, 0x79D1, 0x6280, 0x6709, 0x9650, 0x516C, 0x53F8)
$unknownCompany = (ConvertFrom-CodePoints @(0x5168, 0x65B0)) + "GPU" + (ConvertFrom-CodePoints @(0x6D4B, 0x8BD5, 0x516C, 0x53F8))

function Assert-Decision {
    param(
        [string]$Name,
        [hashtable]$Arguments,
        [string]$ExpectedDecision,
        [string]$ExpectedProjectId
    )

    $json = & $scriptPath @Arguments | ConvertFrom-Json
    if ($json.decision -ne $ExpectedDecision) {
        throw "[$Name] expected decision '$ExpectedDecision', got '$($json.decision)'"
    }
    if ($ExpectedProjectId -and @($json.candidates)[0].project_id -ne $ExpectedProjectId) {
        throw "[$Name] expected project '$ExpectedProjectId', got '$(@($json.candidates)[0].project_id)'"
    }
    Write-Host "PASS: $Name"
}

# Detect whether the distribution is "fresh" (no projects yet) or "loaded" (has projects).
# The original test asserts on a specific historical project (`weijiuguangdian`) which only
# exists in the harness author's local copy. On a fresh distribution with no projects in
# `projects/INDEX.md`, the `existing_candidate` assertions cannot match. Skip those and
# keep only the queries that make sense on an empty repo.
$indexPath = Join-Path (Split-Path -Parent $PSScriptRoot) "..\projects\INDEX.md"
$indexText = if (Test-Path -LiteralPath $indexPath) { Get-Content -Raw -Encoding utf8 -LiteralPath $indexPath } else { "" }
$hasLoadedWeighat = ($indexText -match "weijiuguangdian")

if ($hasLoadedWeighat) {
    Assert-Decision -Name "Chinese brand alias" -Arguments @{ CompanyName = $microBrand } -ExpectedDecision "existing_candidate" -ExpectedProjectId "weijiuguangdian"
    Assert-Decision -Name "Short alias" -Arguments @{ Brand = $microShort } -ExpectedDecision "existing_candidate" -ExpectedProjectId "weijiuguangdian"
    Assert-Decision -Name "Exact legal entity and explicit continuation" -Arguments @{ CompanyName = $microLegal; ExplicitContinue = $true } -ExpectedDecision "resume" -ExpectedProjectId "weijiuguangdian"
    Assert-Decision -Name "Explicit project id" -Arguments @{ ProjectId = "weijiuguangdian" } -ExpectedDecision "resume" -ExpectedProjectId "weijiuguangdian"
    Write-Host "Project resolver regression tests passed."
} else {
    Write-Host "SKIP: project resolver regression tests (no historical project entries in projects/INDEX.md; this is expected on a fresh distribution). Re-run after the first project is created." -ForegroundColor Yellow
    exit 0
}

# Always-on assertions that work on a fresh distribution
Assert-Decision -Name "Unknown entity" -Arguments @{ CompanyName = $unknownCompany } -ExpectedDecision "new" -ExpectedProjectId ""

Write-Host "Project resolver regression tests passed."
