$ErrorActionPreference = "Stop"

$harnessRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$errors = [System.Collections.Generic.List[string]]::new()
$skillName = "chat-knowledge-ingestion"

# Cross-platform: pick pwsh on macOS/Linux when invoking sibling scripts.
. (Join-Path $PSScriptRoot '..\_harness_helpers.ps1')

$sourceSkill = Join-Path $harnessRoot "evolution\runtime-skill-source\$skillName\SKILL.md"
$runtimeSkill = Join-Path $harnessRoot ".agents\skills\$skillName\SKILL.md"
foreach ($path in @($sourceSkill, $runtimeSkill)) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { $errors.Add("Missing skill file: $path") }
}
if ($errors.Count -eq 0 -and (Get-FileHash -LiteralPath $sourceSkill).Hash -ne (Get-FileHash -LiteralPath $runtimeSkill).Hash) {
    $errors.Add("Runtime chat ingestion skill differs from evolution source")
}

$topicId = "frontier-ai-technology-landscape"
$topicRoot = Join-Path $harnessRoot "wiki\$topicId"
foreach ($relative in @("TOPIC.md", "taxonomy.md", "conclusions.md", "theses.md", "technology-map.md", "claims.md", "source-index.md", "updates\2026-09-21.md")) {
    if (-not (Test-Path -LiteralPath (Join-Path $topicRoot $relative) -PathType Leaf)) { $errors.Add("Missing technology topic file: $relative") }
}

$wikiIndex = Get-Content -Raw -Encoding utf8 -LiteralPath (Join-Path $harnessRoot "wiki\INDEX.md")
if ($wikiIndex -notmatch [regex]::Escape("| $topicId | technology-landscape |")) { $errors.Add("Technology topic is not discoverable in wiki index") }

$topic = Get-Content -Raw -Encoding utf8 -LiteralPath (Join-Path $topicRoot "TOPIC.md")
foreach ($expected in @("topic_kind", "technology-landscape", "source_verification", "partial", "status", "review_due", "freshness_days", "30")) {
    if ($topic -notmatch [regex]::Escape($expected)) { $errors.Add("Technology topic missing marker: $expected") }
}

$freshnessJson = Invoke-HarnessScript -File (Join-Path $harnessRoot "scripts/check-wiki-freshness.ps1") -Arguments @("-IndustryId", $topicId, "-AsOf", "2026-09-21")
$freshness = $freshnessJson | ConvertFrom-Json
if ($freshness.decision -ne "quick_update_required") { $errors.Add("Partially verified topic must require quick update") }
if ($freshness.reasons -notcontains "source_partial") { $errors.Add("Freshness result must explain partial source status") }

$agents = Get-Content -Raw -Encoding utf8 -LiteralPath (Join-Path $harnessRoot "AGENTS.md")
$workflow = Get-Content -Raw -Encoding utf8 -LiteralPath (Join-Path $harnessRoot "WORKFLOW.md")
foreach ($required in @("`$chat-knowledge-ingestion", "technology-landscape")) {
    if ($agents -notmatch [regex]::Escape($required)) { $errors.Add("AGENTS missing routing marker: $required") }
    if ($workflow -notmatch [regex]::Escape($required)) { $errors.Add("WORKFLOW missing routing marker: $required") }
}

$sessionRecord = Join-Path $harnessRoot "knowledge-inbox\chat-sessions\6a9fb35a-00dc-83ea-8042-73c0c35c1a3a\SESSION.md"
if (Test-Path -LiteralPath $sessionRecord -PathType Leaf) {
    $session = Get-Content -Raw -Encoding utf8 -LiteralPath $sessionRecord
    if ($session -notmatch [regex]::Escape("## Explicit exclusions")) { $errors.Add("Session intake does not record excluded content") }
}
# On a fresh distribution there are no chat sessions recorded yet; that's expected.
# After the first chat ingestion this assertion will activate automatically.

if ($errors.Count -gt 0) {
    Write-Host "Chat knowledge ingestion regression failed:" -ForegroundColor Red
    $errors | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
    exit 1
}

Write-Host "Chat knowledge ingestion regression passed." -ForegroundColor Green
