$ErrorActionPreference = "Stop"
$scriptRoot = Split-Path -Parent $PSScriptRoot
$harnessRoot = Split-Path -Parent $scriptRoot
$validator = Join-Path $scriptRoot "validate-portfolio.ps1"
$templatePath = Join-Path $harnessRoot "templates\project-decision-card.md"
$fixtureRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("portfolio-validation-" + [guid]::NewGuid().ToString('N'))
$failures = [System.Collections.Generic.List[string]]::new()

# Cross-platform: pick pwsh on macOS/Linux when invoking sibling scripts.
. (Join-Path $scriptRoot '_harness_helpers.ps1')

function New-Fixture([string]$Name, [switch]$MissingSection, [switch]$MissingIndexRow) {
    $root = Join-Path $fixtureRoot $Name
    New-Item -ItemType Directory -Force -Path (Join-Path $root 'cards'), (Join-Path $root 'runs') | Out-Null
    $indexRow = if ($MissingIndexRow) { '' } else { '| demo-project | Demo | Sector | Segment | Early | Research | Conditional | 2026-09-21 | active | `portfolio/cards/demo-project.md` |' }
    $indexBody = "# Portfolio Index`r`n`r`n| Project ID | Company | Sector | Segment | Stage | Research | Conclusion | Date | Status | Card |`r`n|---|---|---|---|---|---|---|---|---|---|`r`n$indexRow`r`n"
    Set-Content -Encoding utf8 -LiteralPath (Join-Path $root 'INDEX.md') -Value $indexBody

    $card = Get-Content -Raw -Encoding utf8 -LiteralPath $templatePath
    $card = $card.Replace('<project_id>', 'demo-project').Replace('YYYY-MM-DD', '2026-09-21').Replace('active/stale', 'active')
    if ($MissingSection) {
        $lastHeading = @(Get-Content -Encoding utf8 -LiteralPath $templatePath | Where-Object { $_ -match '^## [^#]' })[-1]
        $card = $card.Replace($lastHeading, '')
    }
    Set-Content -Encoding utf8 -LiteralPath (Join-Path $root 'cards\demo-project.md') -Value $card
    return $root
}

function Invoke-Case([string]$Name, [string]$Root, [bool]$ShouldPass) {
    Invoke-HarnessScript -File $validator -Arguments @('-PortfolioRoot', $Root) *> $null
    $passed = $LASTEXITCODE -eq 0
    if ($passed -ne $ShouldPass) { $failures.Add("$Name expected pass=$ShouldPass but got pass=$passed") }
}

try {
    Invoke-Case 'Valid card' (New-Fixture 'valid') $true
    Invoke-Case 'Missing required section' (New-Fixture 'missing-section' -MissingSection) $false
    Invoke-Case 'Card missing from index' (New-Fixture 'missing-index' -MissingIndexRow) $false
} finally {
    if (Test-Path -LiteralPath $fixtureRoot) { Remove-Item -LiteralPath $fixtureRoot -Recurse -Force }
}

if ($failures.Count -gt 0) {
    $failures | ForEach-Object { Write-Host "FAIL: $_" -ForegroundColor Red }
    exit 1
}

Write-Host "Portfolio validation tests passed." -ForegroundColor Green

