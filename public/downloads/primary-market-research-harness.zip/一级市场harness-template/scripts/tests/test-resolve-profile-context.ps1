$ErrorActionPreference = "Stop"
$scriptRoot = Split-Path -Parent $PSScriptRoot
$resolver = Join-Path $scriptRoot "resolve-profile-context.ps1"
$failures = [System.Collections.Generic.List[string]]::new()

# Cross-platform: pick pwsh on macOS/Linux when invoking sibling scripts.
. (Join-Path $scriptRoot '_harness_helpers.ps1')

function Check-Success([string]$Name, [string[]]$ResolverArgs, [string]$ExpectedMode) {
    $output = Invoke-HarnessScript -File $resolver -Arguments $ResolverArgs 2>$null
    if ($LASTEXITCODE -ne 0) { $failures.Add("$Name failed with exit $LASTEXITCODE"); return }
    $result = ($output -join "`n") | ConvertFrom-Json
    if ($result.profile_id -ne "default" -or $result.mode -ne $ExpectedMode) { $failures.Add("$Name returned wrong profile/mode") }
}

function Check-Failure([string]$Name, [string[]]$ResolverArgs) {
    $exitCode = 0
    try {
        Invoke-HarnessScript -File $resolver -Arguments $ResolverArgs *> $null
        $exitCode = $LASTEXITCODE
    } catch {
        $exitCode = if ($LASTEXITCODE) { $LASTEXITCODE } else { 1 }
    }
    if ($exitCode -eq 0) { $failures.Add("$Name should fail") }
}

Check-Success "Default selection" @() "default"
Check-Success "Explicit selection" @("-ProfileId", "default") "explicit"
Check-Failure "Unknown profile" @("-ProfileId", "missing-profile")
Check-Failure "Traversal rejected" @("-ProfileId", "..\default")

if ($failures.Count -gt 0) {
    $failures | ForEach-Object { Write-Host "FAIL: $_" -ForegroundColor Red }
    exit 1
}

Write-Host "Profile resolver tests passed." -ForegroundColor Green
