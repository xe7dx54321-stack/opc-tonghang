param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectId
)

$ErrorActionPreference = "Stop"
$harnessRoot = Split-Path -Parent $PSScriptRoot
$projectRoot = Join-Path $harnessRoot ("projects\" + $ProjectId)
$errors = [System.Collections.Generic.List[string]]::new()

function U([int[]]$CodePoints) {
    return -join ($CodePoints | ForEach-Object { [char]$_ })
}

$conceptFinalReport = U @(0x6700,0x7EC8,0x62A5,0x544A)
$conceptDiligence = U @(0x5C3D,0x8C03)
$conceptConsistency = U @(0x4E00,0x81F4,0x6027)
$outcomeInvest = U @(0x6295,0x8D44)
$outcomeConditional = U @(0x6709,0x6761,0x4EF6,0x6295,0x8D44)
$outcomeReject = U @(0x62D2,0x7EDD)

if (-not (Test-Path -LiteralPath $projectRoot -PathType Container)) {
    throw "Project not found: $ProjectId"
}

$required = @(
    "outputs\industry\04-industry-research-final.md",
    "outputs\investment\02-investment-memo.md",
    "outputs\project\02-dd-checklist.md",
    "outputs\investment\01-verdict.md",
    "outputs\investment\02-final-decision.md",
    "evidence\evidence-matrix.md",
    "evidence\source-index.md",
    "reviews\investment-memo-review.md",
    "reviews\final-investment-decision-review.md"
)

foreach ($relativePath in $required) {
    if (-not (Test-Path -LiteralPath (Join-Path $projectRoot $relativePath) -PathType Leaf)) {
        $errors.Add("Missing final-conclusion artifact: $relativePath")
    }
}

$decisionPath = Join-Path $projectRoot "outputs\investment\02-final-decision.md"
if (Test-Path -LiteralPath $decisionPath) {
    $decision = Get-Content -Raw -Encoding utf8 -LiteralPath $decisionPath
    foreach ($requiredConcept in @($conceptFinalReport, $conceptDiligence, $conceptConsistency)) {
        if ($decision -notmatch [regex]::Escape($requiredConcept)) {
            $errors.Add("Final decision does not show report/DD reconciliation: missing '$requiredConcept'")
        }
    }
    $outcomePattern = [regex]::Escape($outcomeInvest) + "|" + [regex]::Escape($outcomeConditional) + "|" + [regex]::Escape($outcomeReject)
    if ($decision -notmatch $outcomePattern) {
        $errors.Add("Final decision has no explicit invest/conditional/reject outcome")
    }
}

foreach ($reviewName in @("investment-memo-review.md", "final-investment-decision-review.md")) {
    $reviewPath = Join-Path $projectRoot ("reviews\" + $reviewName)
    if (-not (Test-Path -LiteralPath $reviewPath)) { continue }
    $review = Get-Content -Raw -Encoding utf8 -LiteralPath $reviewPath
    if ($review -notmatch "investment_reviewer") { $errors.Add("$reviewName does not identify investment_reviewer") }
    if ($review -notmatch "PASS") { $errors.Add("$reviewName has no PASS/PASS WITH CONDITIONS conclusion") }
}

$finalReviewPath = Join-Path $projectRoot "reviews\final-investment-decision-review.md"
if (Test-Path -LiteralPath $finalReviewPath) {
    $finalReview = Get-Content -Raw -Encoding utf8 -LiteralPath $finalReviewPath
    foreach ($requiredConcept in @("04-industry-research-final.md", "02-investment-memo.md", "02-dd-checklist.md", $conceptConsistency)) {
        if ($finalReview -notmatch [regex]::Escape($requiredConcept)) {
            $errors.Add("Final decision review is not a joint review: missing '$requiredConcept'")
        }
    }
}

if ($errors.Count -gt 0) {
    Write-Host "Final conclusion validation failed: $ProjectId" -ForegroundColor Red
    $errors | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
    exit 1
}

Write-Host "Final conclusion validation passed: $ProjectId" -ForegroundColor Green
