param(
    [Parameter(Mandatory = $true)][string]$Path,
    [switch]$AllowTemplateReady
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.IO.Compression.FileSystem

$resolved = (Resolve-Path -LiteralPath $Path).Path
$archive = [System.IO.Compression.ZipFile]::OpenRead($resolved)

function Read-ZipText([string]$EntryName) {
    $entry = $archive.GetEntry($EntryName)
    if (-not $entry) { return $null }
    $reader = [System.IO.StreamReader]::new($entry.Open(), [System.Text.Encoding]::UTF8)
    try { return $reader.ReadToEnd() } finally { $reader.Dispose() }
}

function Cell-Value($Cell, [string[]]$SharedStrings) {
    if (-not $Cell) { return $null }
    $type = [string]$Cell.t
    if ($type -eq "inlineStr") { return [string]$Cell.is.InnerText }
    $raw = [string]$Cell.v
    if ($type -eq "s" -and $raw -match '^\d+$') { return $SharedStrings[[int]$raw] }
    return $raw
}

$errors = [System.Collections.Generic.List[string]]::new()
try {
    $shared = @()
    $sharedText = Read-ZipText "xl/sharedStrings.xml"
    if ($sharedText) {
        [xml]$sharedXml = $sharedText
        $shared = @($sharedXml.sst.si | ForEach-Object { [string]$_.InnerText })
    }

    [xml]$workbookXml = Read-ZipText "xl/workbook.xml"
    [xml]$relsXml = Read-ZipText "xl/_rels/workbook.xml.rels"
    $relationshipMap = @{}
    foreach ($rel in @($relsXml.Relationships.Relationship)) { $relationshipMap[[string]$rel.Id] = [string]$rel.Target }

    $checksTarget = $null
    foreach ($sheet in @($workbookXml.workbook.sheets.sheet)) {
        $relId = [string]$sheet.GetAttribute("id", "http://schemas.openxmlformats.org/officeDocument/2006/relationships")
        $target = $relationshipMap[$relId]
        if (-not $target) { continue }
        if ($target.StartsWith("/")) { $entryName = $target.TrimStart("/") }
        elseif ($target.StartsWith("xl/")) { $entryName = $target }
        else { $entryName = "xl/$target" }
        if ([string]$sheet.name -eq "Checks") { $checksTarget = $entryName }

        $sheetText = Read-ZipText $entryName
        if (-not $sheetText) { $errors.Add("Missing worksheet entry: $entryName"); continue }
        [xml]$sheetXml = $sheetText
        foreach ($cell in @($sheetXml.worksheet.sheetData.row.c)) {
            $value = Cell-Value $cell $shared
            if ([string]$cell.t -eq "e" -or $value -match '^#(REF!|DIV/0!|VALUE!|NAME\?|N/A|NUM!)$') {
                $errors.Add("Formula error at $([string]$sheet.name)!$([string]$cell.r): $value")
            }
        }
    }

    if (-not $checksTarget) { $errors.Add("Missing Checks worksheet") }
    else {
        [xml]$checksXml = Read-ZipText $checksTarget
        $statusCell = @($checksXml.worksheet.sheetData.row.c | Where-Object { [string]$_.r -eq "E15" }) | Select-Object -First 1
        $status = Cell-Value $statusCell $shared
        $allowed = @("OK")
        if ($AllowTemplateReady) { $allowed += "TEMPLATE READY" }
        if ($status -notin $allowed) { $errors.Add("Checks!E15 must be $($allowed -join ' or '), got '$status'") }
    }
} finally {
    $archive.Dispose()
}

if ($errors.Count -gt 0) {
    $errors | ForEach-Object { Write-Error $_ }
    exit 1
}

Write-Host "Workbook validation passed: $resolved"
