param([switch]$RequireRuntimeSync)

$ErrorActionPreference = "Stop"
$harnessRoot = Split-Path -Parent $PSScriptRoot
$sourceRoot = Join-Path $harnessRoot "evolution\runtime-skill-source"
$runtimeRoot = Join-Path $harnessRoot ".agents\skills"

# Cross-platform: pick pwsh on macOS/Linux when invoking sibling scripts.
. (Join-Path $PSScriptRoot '_harness_helpers.ps1')
$errors = [System.Collections.Generic.List[string]]::new()
$drift = [System.Collections.Generic.List[string]]::new()
$expected = @("harness-evolution", "final-investment-decision", "investment-memo", "investment-verdict", "material-analysis", "project-decision-card", "project-pool-selection", "chat-knowledge-ingestion")

foreach ($name in $expected) {
    $sourceSkill = Join-Path $sourceRoot "$name\SKILL.md"
    $sourceMeta = Join-Path $sourceRoot "$name\agents\openai.yaml"
    foreach ($path in @($sourceSkill, $sourceMeta)) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { $errors.Add("Missing evolution source: $path") }
    }
    if (-not (Test-Path -LiteralPath $sourceSkill)) { continue }
    $content = Get-Content -Raw -Encoding utf8 -LiteralPath $sourceSkill
    $frontmatter = [regex]::Match($content, "\A---\r?\n(?<body>.*?)\r?\n---", "Singleline")
    if (-not $frontmatter.Success) { $errors.Add("Invalid source frontmatter: $name"); continue }
    if ($frontmatter.Groups["body"].Value -notmatch "(?m)^name:\s*$([regex]::Escape($name))\s*$") { $errors.Add("Source name mismatch: $name") }
    if ($content -match "\[TODO|TODO:") { $errors.Add("Unresolved TODO in source: $name") }
    if (Test-Path -LiteralPath $sourceMeta) {
        $meta = Get-Content -Raw -Encoding utf8 -LiteralPath $sourceMeta
        if ($meta -notmatch [regex]::Escape("`$$name")) { $errors.Add("Source metadata prompt missing `$$name") }
    }
    foreach ($relative in @("SKILL.md", "agents\openai.yaml")) {
        $source = Join-Path (Join-Path $sourceRoot $name) $relative
        $runtime = Join-Path (Join-Path $runtimeRoot $name) $relative
        if (-not (Test-Path -LiteralPath $runtime)) { $drift.Add("$name/$relative missing in runtime"); continue }
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $source).Hash -ne (Get-FileHash -Algorithm SHA256 -LiteralPath $runtime).Hash) {
            $drift.Add("$name/$relative differs")
        }
    }
}

Invoke-HarnessScript -File (Join-Path $PSScriptRoot "validate-profiles.ps1")
if ($LASTEXITCODE -ne 0) { $errors.Add("Profile validation failed") }

if ($RequireRuntimeSync -and $drift.Count -gt 0) { $drift | ForEach-Object { $errors.Add("Runtime drift: $_") } }

if ($errors.Count -gt 0) {
    Write-Host "Evolution validation failed:" -ForegroundColor Red
    $errors | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
    exit 1
}

Write-Host "Evolution source validation passed. Source Skills: $($expected.Count)" -ForegroundColor Green
if ($drift.Count -gt 0) {
    Write-Host "Runtime sync required:" -ForegroundColor Yellow
    $drift | ForEach-Object { Write-Host "  - $_" -ForegroundColor Yellow }
} else {
    Write-Host "Runtime Skills match evolution source." -ForegroundColor Green
}
