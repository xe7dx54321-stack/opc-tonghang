param(
    [string]$ProjectId,
    [string]$CompanyName,
    [string]$Brand,
    [switch]$ExplicitContinue
)

$ErrorActionPreference = "Stop"
$harnessRoot = Split-Path -Parent $PSScriptRoot
$indexPath = Join-Path $harnessRoot "projects\INDEX.md"

function Normalize-Identity([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) { return "" }
    # Keep script parsing ASCII-safe under Windows PowerShell 5.1. .NET regex resolves the Unicode escapes.
    return ([regex]::Replace($Value.ToLowerInvariant(), '[\s"''()\uFF08\uFF09\-_/\\,\.\uFF0C\u3001\u00B7]', ''))
}

$rows = [System.Collections.Generic.List[object]]::new()
foreach ($line in Get-Content -Encoding utf8 -LiteralPath $indexPath) {
    if ($line -notmatch '^\|') { continue }
    $cells = $line.Trim('|').Split('|') | ForEach-Object { $_.Trim().Trim('`') }
    if ($cells.Count -lt 8 -or $cells[0] -in @('Project ID', '---')) { continue }
    $rows.Add([pscustomobject]@{
        project_id = $cells[0]
        company = $cells[1]
        aliases = $cells[2]
        status = $cells[3]
        wiki = $cells[4]
        path = $cells[7]
    })
}

if (-not [string]::IsNullOrWhiteSpace($ProjectId)) {
    $selected = @($rows | Where-Object { $_.project_id -eq $ProjectId })
    if ($selected.Count -eq 1) {
        [pscustomobject]@{ decision='resume'; reason='explicit_project_id'; candidates=$selected } | ConvertTo-Json -Depth 4
        exit 0
    }
}

$companyKey = Normalize-Identity $CompanyName
$brandKey = Normalize-Identity $Brand
$matches = @($rows | Where-Object {
    $storedCompanyKey = Normalize-Identity $_.company
    $aliasValues = $_.aliases -split '[,/\u3001\uFF0C]+' | ForEach-Object { Normalize-Identity $_ }
    $companyMatch = $companyKey -and (($storedCompanyKey -eq $companyKey) -or ($aliasValues -contains $companyKey))
    $brandMatch = $brandKey -and (($storedCompanyKey -eq $brandKey) -or ($aliasValues -contains $brandKey))
    $companyMatch -or $brandMatch
})

if ($matches.Count -eq 0) {
    [pscustomobject]@{ decision='new'; reason='no_entity_match'; candidates=@() } | ConvertTo-Json -Depth 4
} elseif ($matches.Count -gt 1) {
    [pscustomobject]@{ decision='ambiguous'; reason='multiple_entity_matches'; candidates=$matches } | ConvertTo-Json -Depth 4
} elseif ($ExplicitContinue) {
    [pscustomobject]@{ decision='resume'; reason='exact_entity_and_explicit_continue'; candidates=$matches } | ConvertTo-Json -Depth 4
} else {
    [pscustomobject]@{ decision='existing_candidate'; reason='exact_entity_requires_session_selection'; candidates=$matches } | ConvertTo-Json -Depth 4
}
