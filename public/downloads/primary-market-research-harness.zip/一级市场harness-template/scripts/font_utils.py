"""Cross-platform CJK font resolver for harness chart and contact-sheet scripts.

Windows PowerShell 5.1 / PowerShell 7 / macOS / Linux are all supported.

The returned fonts are picked from the first existing path in priority order.
On macOS the harness prefers STHeiti Medium for Chinese text because it ships
out-of-the-box on current macOS releases and renders Simplified Chinese without
requiring Microsoft Office to be installed. Windows still prefers Microsoft
YaHei (msyh.ttc) so the Word/Excel report visuals stay byte-stable for users
who already validate them in CI.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Iterable

from PIL import ImageFont


# Ordered preference lists. First existing file wins.
_CJK_CANDIDATES: tuple[str, ...] = (
    # Windows (original harness behavior)
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\msyhbd.ttc",
    # macOS stock fonts
    "/System/Library/Fonts/STHeiti Medium.ttc",
    "/System/Library/Fonts/STHeiti Light.ttc",
    "/System/Library/Fonts/PingFang.ttc",
    "/System/Library/Fonts/Hiragino Sans GB.ttc",
    "/System/Library/Fonts/Songti.ttc",
    # Linux fallbacks (fontconfig or manual install)
    "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/noto-cjk/NotoSansCJK-Regular.ttc",
    "/Library/Fonts/Songti.ttc",
)

_LATIN_CANDIDATES: tuple[str, ...] = (
    r"C:\Windows\Fonts\arial.ttf",
    "/System/Library/Fonts/Helvetica.ttc",
    "/System/Library/Fonts/HelveticaNeue.ttc",
    "/Library/Fonts/Arial.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
)


def _resolve(candidates: Iterable[str]) -> str | None:
    for path in candidates:
        if path and Path(path).exists():
            return path
    return None


def _iter_fontconfig_fonts() -> Iterable[str]:
    """Probe `fc-list` style hints without requiring pyfontconfig."""
    candidates_dir = Path("/System/Library/Fonts/Supplemental")
    if candidates_dir.is_dir():
        for path in candidates_dir.glob("*.ttc"):
            yield str(path)
        for path in candidates_dir.glob("*.ttf"):
            yield str(path)


def find_cjk_font() -> str | None:
    """Return the first existing CJK font path, or ``None``."""
    return _resolve(_CJK_CANDIDATES) or _resolve(_iter_fontconfig_fonts())


def find_latin_font() -> str | None:
    """Return the first existing Latin font path, or ``None``."""
    return _resolve(_LATIN_CANDIDATES)


def load_cjk_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    """Load a CJK font usable on both Windows and macOS.

    Falls back to the bundled default if no candidate is present (PIL still
    succeeds but renders tofu glyphs, which surfaces a visible warning to the
    user instead of crashing mid-chart).
    """
    candidates: list[str] = []
    primary = find_cjk_font()
    if primary:
        candidates.append(primary)
    if bold and sys.platform == "win32":
        candidates.append(r"C:\Windows\Fonts\msyhbd.ttc")
    candidates.extend(_iter_fontconfig_fonts())

    last_error: Exception | None = None
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except OSError as exc:  # pragma: no cover - depends on font file
            last_error = exc
            continue
    if last_error is not None:
        print(
            f"[font_utils] WARN: no usable CJK font found, falling back to PIL default: {last_error}",
            file=sys.stderr,
        )
    return ImageFont.load_default()


def load_latin_font(size: int) -> ImageFont.FreeTypeFont:
    """Load a Western font usable on both Windows and macOS."""
    candidates: list[str] = []
    primary = find_latin_font()
    if primary:
        candidates.append(primary)
    candidates.extend(_iter_fontconfig_fonts())
    last_error: Exception | None = None
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except OSError as exc:  # pragma: no cover
            last_error = exc
            continue
    if last_error is not None:
        print(
            f"[font_utils] WARN: no usable Latin font found, falling back to PIL default: {last_error}",
            file=sys.stderr,
        )
    return ImageFont.load_default()


def is_windows() -> bool:
    return os.name == "nt"


def is_macos() -> bool:
    return sys.platform == "darwin"


__all__ = [
    "find_cjk_font",
    "find_latin_font",
    "load_cjk_font",
    "load_latin_font",
    "is_macos",
    "is_windows",
]
