from __future__ import annotations

import sys
import zipfile
import re
import hashlib
from pathlib import Path
from xml.etree import ElementTree as ET

from docx import Document


NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def audit(
    path: Path,
    expected_images: int,
    expected_headings: list[str],
    required_strings: list[str],
    forbidden_strings: list[str],
    expected_image_files: list[Path],
):
    errors = []
    document = Document(path)
    section = document.sections[0]
    if round(section.page_width.inches, 2) != 8.50 or round(section.page_height.inches, 2) != 11.00:
        errors.append("page size is not US Letter")
    margins = (section.top_margin, section.right_margin, section.bottom_margin, section.left_margin)
    if any(round(v.inches, 2) != 1.00 for v in margins):
        errors.append("margins are not 1 inch")
    if round(section.header_distance.inches, 3) != 0.492 or round(section.footer_distance.inches, 3) != 0.492:
        errors.append("header/footer distance mismatch")
    if document.styles["Normal"].font.name != "Arial":
        errors.append("body font is not Arial")
    if len(document.inline_shapes) != expected_images:
        errors.append(f"images={len(document.inline_shapes)}, expected={expected_images}")

    text_parts = [p.text for p in document.paragraphs]
    for table in document.tables:
        for row in table.rows:
            text_parts.extend(cell.text for cell in row.cells)
    text = "\n".join(text_parts)
    for heading in expected_headings:
        if heading not in text:
            errors.append(f"missing heading: {heading}")
    for required in required_strings:
        if required not in text:
            errors.append(f"missing critical content: {required}")
    for forbidden in forbidden_strings:
        if forbidden.lower() in text.lower():
            errors.append(f"contains forbidden submission content: {forbidden}")

    internal_patterns = {
        "evidence/source code": r"(?<![A-Za-z0-9])(?:W-SRC|W-C|W-U|SRC|CON|DD|PM|E|Q|C)-\d+",
        "milestone code": r"M[1-7](?!\d)",
        "KSF code": r"KSF-\d+",
        "risk code": r"R-\d+",
        "internal filename": r"\b\d{2}[-a-z]+\.md\b",
    }
    for label, pattern in internal_patterns.items():
        if re.search(pattern, text, flags=re.IGNORECASE):
            errors.append(f"contains {label}")
    for term in ("evidence matrix", "canonical", "reviewer", "Wiki", "reviewer Gate", "Fatal Gate", "Harness", "作为AI", "系统认为"):
        if term.lower() in text.lower():
            errors.append(f"contains system term: {term}")
    for label, pattern in {
        "broken punctuation": r"(?:对|为|与)\s*/[，、/]",
        "empty brackets": r"[（(]\s*[）)]",
        "markdown markup": r"\*\*|`[^`]+`",
        "separator-only table residue": r"(?:^|\n)\s*[/,，;；、]+\s*(?:$|\n)",
        "repeated comma residue": r",\s*,|，\s*，",
        "duplicated risk label": r"风险\s+(?:大厂价格战|全彩路线收敛|客户集中|放量窗口)",
    }.items():
        if re.search(pattern, text):
            errors.append(f"contains {label}")

    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        if "word/document.xml" not in names or "word/styles.xml" not in names:
            errors.append("missing core OOXML parts")
        root = ET.fromstring(archive.read("word/document.xml"))
        for index, table in enumerate(root.findall(".//w:tbl", NS), start=1):
            grid = table.find("w:tblGrid", NS)
            grid_widths = [] if grid is None else [int(c.get(W + "w", "0")) for c in grid.findall("w:gridCol", NS)]
            if sum(grid_widths) != 9360:
                errors.append(f"table {index} grid width={sum(grid_widths)}, expected=9360")
            tbl_w = table.find("w:tblPr/w:tblW", NS)
            if tbl_w is None or tbl_w.get(W + "w") != "9360" or tbl_w.get(W + "type") != "dxa":
                errors.append(f"table {index} tblW mismatch")
            tbl_ind = table.find("w:tblPr/w:tblInd", NS)
            if tbl_ind is None or tbl_ind.get(W + "w") != "120":
                errors.append(f"table {index} tblInd mismatch")
            for row_index, row in enumerate(table.findall("w:tr", NS), start=1):
                cells = row.findall("w:tc", NS)
                cell_widths = []
                for cell in cells:
                    tc_w = cell.find("w:tcPr/w:tcW", NS)
                    cell_widths.append(0 if tc_w is None else int(tc_w.get(W + "w", "0")))
                if cell_widths and sum(cell_widths) != 9360:
                    errors.append(f"table {index} row {row_index} width={sum(cell_widths)}")
        media = [name for name in names if name.startswith("word/media/")]
        if len(media) != expected_images:
            errors.append(f"embedded media={len(media)}, expected={expected_images}")
        embedded_hashes = {hashlib.sha256(archive.read(name)).hexdigest() for name in media}
        expected_hashes = {hashlib.sha256(image.read_bytes()).hexdigest() for image in expected_image_files}
        if embedded_hashes != expected_hashes:
            errors.append("embedded images do not match approved submission visuals")

    status = "PASS" if not errors else "FAIL"
    print(f"{status}: {path.name} | paragraphs={len(document.paragraphs)} tables={len(document.tables)} images={len(document.inline_shapes)}")
    for error in errors:
        print(f"  - {error}")
    return not errors


def main():
    root = Path(sys.argv[1]).resolve()
    project = root / "projects" / "weijiuguangdian" / "outputs"
    checks = [
        audit(
            project / "industry" / "04-industry-research-final-submission.docx",
            3,
            ["目录", "核心结论", "1. 行业概述", "10. 行业风险梳理"],
            ["Micro LED", "2027-2028", "良率", "主要资料来源与口径说明"],
            ["微玖", "Google PO", "Meta NDA", "投前3.8", "投前约9", "账面现金", "18个月资金", "当前项目", "本项目", "项目层面", "项目证据充分度", "材料口径", "管理层", "项目尽调", "项目口径", "项目交付边界"],
            [
                project / "industry" / "word-visuals" / "01-value-chain-image2-3840x2400.png",
                project / "industry" / "word-visuals" / "02-technology-routes-image2-3840x2400.png",
                project / "industry" / "word-visuals" / "03-competition-window-image2-3840x2400.png",
            ],
        ),
        audit(
            project / "investment" / "02-investment-memo-final-submission.docx",
            3,
            ["目录", "1. 核心结论", "2. 项目基本信息", "5. 财务预测", "7. 估值与回报测算", "8. 概率分析", "9. 风险及应对措施", "10. 研究依据与重要说明"],
            ["拒绝当前假设条款一次性交割", "8亿元", "1.2亿元", "13%-25%", "3%-10%", "0.5%-3.5%", "0.50×-0.76×", "最终投资决策重新审议", "主要资料来源与口径说明"],
            [],
            [
                project / "investment" / "word-visuals" / "02-investment-memo-05-financial-scenarios-submission.png",
                project / "investment" / "word-visuals" / "02-investment-memo-07-exit-paths-submission.png",
                project / "investment" / "word-visuals" / "02-investment-memo-08-milestone-probability-submission.png",
            ],
        ),
    ]
    raise SystemExit(0 if all(checks) else 1)


if __name__ == "__main__":
    main()
