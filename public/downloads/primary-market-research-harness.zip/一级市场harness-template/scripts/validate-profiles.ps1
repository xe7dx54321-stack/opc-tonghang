$ErrorActionPreference = "Stop"
$harnessRoot = Split-Path -Parent $PSScriptRoot
$profilesRoot = Join-Path $harnessRoot "profiles"
$errors = [System.Collections.Generic.List[string]]::new()

function U([int[]]$CodePoints) {
    return -join ($CodePoints | ForEach-Object { [char]$_ })
}

$overrideLabels = @(
    (U @(0x89E6,0x53D1,0x6761,0x4EF6)),
    (U @(0x8986,0x76D6,0x89C4,0x5219)),
    (U @(0x975E,0x89E6,0x53D1)),
    (U @(0x6D4B,0x8BD5)),
    (U @(0x56DE,0x9000))
)

$indexPath = Join-Path $profilesRoot "INDEX.md"
if (-not (Test-Path -LiteralPath $indexPath -PathType Leaf)) {
    $errors.Add("Missing profiles/INDEX.md")
} else {
    $index = Get-Content -Raw -Encoding utf8 -LiteralPath $indexPath
    foreach ($dir in Get-ChildItem -LiteralPath $profilesRoot -Directory) {
        $id = $dir.Name
        if ($index -notmatch [regex]::Escape("| $id |")) { $errors.Add("Profile missing from INDEX: $id") }
        foreach ($required in @("PROFILE.md", "methodology.md", "feedback-log.md", "overrides")) {
            if (-not (Test-Path -LiteralPath (Join-Path $dir.FullName $required))) {
                $errors.Add("Profile $id missing: $required")
            }
        }
        $profilePath = Join-Path $dir.FullName "PROFILE.md"
        if (Test-Path -LiteralPath $profilePath) {
            $profile = Get-Content -Raw -Encoding utf8 -LiteralPath $profilePath
            $declaredId = ([char]0x60) + $id + ([char]0x60)
            if ($profile -notmatch [regex]::Escape($declaredId)) { $errors.Add("Profile ID not declared in $id/PROFILE.md") }
        }
        foreach ($override in Get-ChildItem -LiteralPath (Join-Path $dir.FullName "overrides") -File -Filter "*.md" -ErrorAction SilentlyContinue) {
            if ($override.Name -eq "README.md") { continue }
            $body = Get-Content -Raw -Encoding utf8 -LiteralPath $override.FullName
            foreach ($label in $overrideLabels) {
                if ($body -notmatch $label) { $errors.Add("Override $($override.FullName) missing section: $label") }
            }
        }
    }
}

foreach ($forbidden in @("ACTIVE_PROFILE", "active-profile", ".active-profile")) {
    if (Test-Path -LiteralPath (Join-Path $profilesRoot $forbidden)) {
        $errors.Add("Forbidden global active-profile state: $forbidden")
    }
}

if ($errors.Count -gt 0) {
    Write-Host "Profile validation failed:" -ForegroundColor Red
    $errors | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
    exit 1
}

Write-Host "Profile validation passed. Profiles: $((Get-ChildItem -LiteralPath $profilesRoot -Directory).Count)" -ForegroundColor Green
