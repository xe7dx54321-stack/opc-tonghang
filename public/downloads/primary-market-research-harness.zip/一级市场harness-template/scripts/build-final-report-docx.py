from __future__ import annotations

import argparse
import re
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
INK = "202830"
MUTED = "667085"
LIGHT = "F2F4F7"
CALLOUT = "F4F6F9"
WHITE = "FFFFFF"
TABLE_WIDTH_DXA = 9360
TABLE_INDENT_DXA = 120

INTERNAL_REFERENCE_RE = re.compile(
    r"(?<![A-Za-z0-9])(?:W-SRC|W-C|W-U|SRC|CON|DD|PM|E|Q|C)-\d+"
    r"(?:\s*[~～]\s*(?:(?:W-SRC|W-C|W-U|SRC|CON|DD|PM|E|Q|C)-)?\d+)?"
)

MILESTONES = {
    "M1": "数据与治理基线闭环",
    "M2": "稳定小批量与资金覆盖",
    "M3": "头部客户商业闭环",
    "M4": "规模量产",
    "M5": "可持续成长并接近盈亏平衡",
    "M6": "具备上市申报条件",
    "M7": "上市解禁退出",
}

KSF_LABELS = {
    "KSF-1": "全彩量产能力",
    "KSF-2": "头部客户定点与认证卡位",
    "KSF-3": "工艺平台与供应链管理",
    "KSF-4": "资本与产能匹配节奏",
}

RISK_LABELS = {
    "R-1": "放量窗口延迟风险",
    "R-2": "大厂价格战与产能挤压风险",
    "R-3": "全彩路线收敛导致资产贬值风险",
    "R-4": "客户集中与供应链约束风险",
}

INDUSTRY_IMAGE_OVERRIDES = {
    "03-industry-research-01a-mled-chain.png": "word-visuals/01-value-chain-image2-3840x2400.png",
    "03-industry-research-07a-substitutes.png": "word-visuals/02-technology-routes-image2-3840x2400.png",
    "03-industry-research-08a-competitors.png": "word-visuals/03-competition-window-image2-3840x2400.png",
}

# Markdown 保留全部研究图；投委会 Word 只采用通过人工检查、且不含内部编码的精选图。
INDUSTRY_WORD_IMAGES = set(INDUSTRY_IMAGE_OVERRIDES)

PROJECT_IMAGE_OVERRIDES = {
    "02-investment-memo-05-financial-scenarios.png": "word-visuals/02-investment-memo-05-financial-scenarios-submission.png",
    "02-investment-memo-07-exit-paths.png": "word-visuals/02-investment-memo-07-exit-paths-submission.png",
    "02-investment-memo-08-milestone-probability.png": "word-visuals/02-investment-memo-08-milestone-probability-submission.png",
}

INDUSTRY_PROJECT_TERMS = (
    "微玖",
    "Google PO",
    "Meta NDA",
    "投前3.8",
    "投前约9",
    "账面现金",
    "18个月资金",
    "当前项目",
    "本项目",
    "项目层面",
)


def rgb(hex_value: str) -> RGBColor:
    return RGBColor.from_string(hex_value)


def set_run_font(run, size=None, bold=None, italic=None, color=INK):
    run.font.name = "Arial"
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Arial")
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Arial")
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color:
        run.font.color.rgb = rgb(color)


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths):
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(TABLE_WIDTH_DXA))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(TABLE_INDENT_DXA))
    tbl_ind.set(qn("w:type"), "dxa")
    layout = tbl_pr.find(qn("w:tblLayout"))
    if layout is None:
        layout = OxmlElement("w:tblLayout")
        tbl_pr.append(layout)
    layout.set(qn("w:type"), "fixed")

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)

    for row in table.rows:
        for index, cell in enumerate(row.cells):
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(widths[index]))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_page_field(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("第 ")
    set_run_font(run, size=9, color=MUTED)
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    paragraph._p.append(fld)
    run = paragraph.add_run(" 页")
    set_run_font(run, size=9, color=MUTED)


def configure_styles(doc):
    normal = doc.styles["Normal"]
    normal.font.name = "Arial"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.font.size = Pt(11)
    normal.font.color.rgb = rgb(INK)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.10

    for name, size, color, before, after in (
        ("Heading 1", 16, BLUE, 12, 6),
        ("Heading 2", 13, BLUE, 10, 5),
        ("Heading 3", 12, DARK_BLUE, 8, 4),
    ):
        style = doc.styles[name]
        style.font.name = "Arial"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = rgb(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    if "Figure Caption" not in [s.name for s in doc.styles]:
        caption = doc.styles.add_style("Figure Caption", WD_STYLE_TYPE.PARAGRAPH)
    else:
        caption = doc.styles["Figure Caption"]
    caption.font.name = "Arial"
    caption._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    caption.font.size = Pt(9)
    caption.font.color.rgb = rgb(MUTED)
    caption.paragraph_format.space_before = Pt(3)
    caption.paragraph_format.space_after = Pt(8)
    caption.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER

    if "Quote Callout" not in [s.name for s in doc.styles]:
        quote = doc.styles.add_style("Quote Callout", WD_STYLE_TYPE.PARAGRAPH)
    else:
        quote = doc.styles["Quote Callout"]
    quote.font.name = "Arial"
    quote._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    quote.font.size = Pt(10.5)
    quote.font.color.rgb = rgb(DARK_BLUE)
    quote.paragraph_format.left_indent = Inches(0.18)
    quote.paragraph_format.right_indent = Inches(0.12)
    quote.paragraph_format.space_before = Pt(4)
    quote.paragraph_format.space_after = Pt(8)
    quote.paragraph_format.line_spacing = 1.10


def configure_section(section, running_label):
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)
    section.different_first_page_header_footer = True

    header = section.header
    p = header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run(running_label)
    set_run_font(run, size=8.5, color=MUTED)
    footer = section.footer
    add_page_field(footer.paragraphs[0])


def add_cover(doc, title, subtitle, date_text, project_label):
    for _ in range(5):
        doc.add_paragraph().paragraph_format.space_after = Pt(18)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(14)
    r = p.add_run("一级市场投资研究")
    set_run_font(r, size=11, bold=True, color=BLUE)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(8)
    r = p.add_run(title)
    set_run_font(r, size=28, bold=True, color=DARK_BLUE)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(30)
    r = p.add_run(subtitle)
    set_run_font(r, size=14, color=MUTED)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(project_label)
    set_run_font(r, size=11, bold=True, color=INK)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(date_text)
    set_run_font(r, size=10.5, color=MUTED)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(38)
    r = p.add_run("机密｜仅供内部投资决策使用")
    set_run_font(r, size=9.5, bold=True, color="9B1C1C")
    doc.add_page_break()


INLINE_RE = re.compile(r"(\*\*.+?\*\*|`.+?`)")


def humanize_text(text: str, report_kind: str) -> str:
    """Convert traceable research notation into submission-ready prose."""
    if report_kind == "project":
        text = text.replace(
            "完整报告没有反转方向，但对赔率给出了更低的独立校准：",
            "补充测算仍支持上述判断，并给出更低的赔率校准：",
        )
        text = text.replace(
            "该差异不改变“拒绝”，但构成必须重新打开最终决策reviewer Gate的实质模型变化。",
            "该模型差异已触发最终投资决策重新审议；重新审议不改变当前“拒绝”的方向，"
            "但必须在报告发布时明确披露两套口径。",
        )
        text = text.replace("8.1 独立重建方法", "8.1 里程碑概率测算方法")
        text = text.replace("本报告独立估计最终上市解禁退出", "基于里程碑条件概率，最终上市解禁退出")
        text = text.replace("本报告的经营里程碑模型没有沿用该概率树", "经营里程碑模型采用逐级条件概率法")
        text = text.replace(
            "经营模型要求逐级跨过M1-M7且只按简化失败回收",
            "经营模型要求逐级跨过从数据与治理基线闭环到上市解禁退出的全部阶段，并按简化失败回收测算",
        )
        text = text.replace(
            "该差异必须重新进入最终投资决策reviewer，而不能在报告中静默解释掉。",
            "该模型差异已触发最终投资决策重新审议，不能用单一结果相互替代。",
        )
        text = re.sub(
            r"独立重建模型与此前最终决策方向一致，但概率加权回报显著更低，已触发最终投资决策定向重开；"
            r"只有 reviewer 对E-097/E-098、Q-25与C-030重新签字后才能发布最终版。"
            r"未来任何模型反转或实质回报差异同样必须暂停报告，不得静默改写已确认决策。",
            "里程碑概率模型与最终投资决策方向一致，但测得的概率加权回报更低。"
            "两套口径均已在报告中如实披露；未来若概率、条款或回报发生实质变化，应重新评估投资结论。",
            text,
        )
        text = text.replace("cap table", "完全摊薄股权结构表")
        text = text.replace("客户forecast", "客户预测")
    else:
        text = text.replace(
            "JBD 先发，微玖只是“待验证追赶者”，尚无证据证明已取得头部二供地位；项目证据充分度为 C。",
            "JBD 具备先发优势，其他创业公司与大型面板、LED 厂商仍处于不同验证阶段；"
            "公开信息尚不足以确认稳定的二供格局。",
        )
        text = text.replace(
            "JBD 先发，微玖/诺视/思坦等追赶，大厂后进；",
            "JBD 先发，诺视、思坦等创业公司与大型面板、LED 厂商从不同路线追赶；",
        )
        text = text.replace("财务/项目尽调显示", "产业样本显示")
        text = text.replace("项目尽调", "企业尽调")
        text = text.replace("项目尽调材料", "产业访谈与公开资料")
        text = text.replace("管理层口径", "企业访谈口径")
        text = text.replace("管理层", "产业访谈")
        text = text.replace("项目口径", "公开口径不足")
        text = text.replace("项目交付边界为企业访谈口径", "研究边界以上述器件交付为准")
        text = text.replace("微玖专利", "相关企业专利")
        text = text.replace("微玖自研", "部分企业自研")
        text = text.replace(
            "当前部分企业自研外延+芯片+键合+Demura 的边界合理",
            "器件企业向外延、芯片、键合和 Demura 延伸具有一定合理性",
        )
        text = text.replace("JBD、谷歌与微玖均有", "JBD、谷歌等行业参与者有")
        text = text.replace("微玖/诺视/思坦", "诺视/思坦")
        text = text.replace("微玖、诺视", "诺视")
        text = text.replace("项目级前五大客户占比尚缺", "企业公开的前五大客户占比口径普遍不足")
        text = text.replace("公开的企业公开的前五大客户占比", "企业公开的前五大客户占比")
        text = text.replace(
            "20% 的器件份额、E-034 的 65% 技术渗透率",
            "20% 的器件份额、另一机构给出的 65% 技术渗透率",
        )
        text = text.replace(
            "20% 的器件份额、另一机构给出的 65% 技术渗透率以及另一机构的 20.9M 终端预测",
            "20% 的器件份额、专业机构给出的 65% 技术渗透率及 20.9M 终端预测",
        )
        text = text.replace("单项目", "单一标的")
        text = text.replace("行业项目通常", "器件企业通常")
        text = text.replace("多项目配置", "多标的配置")
        text = text.replace("单一项目调整", "单一标的调整")
        text = text.replace("验证周期与持有期是否匹配仍待项目证据回答", "验证周期与持有期是否匹配仍需结合具体企业判断")
        text = text.replace("按项目路线选择评估", "按具体技术路线评估")
        text = text.replace("项目特有风险", "企业特有风险")
        text = text.replace("项目份额", "特定企业份额")
        text = text.replace("不是项目事实", "不等于任何一家企业已取得二供地位")
        text = text.replace("衡量项目", "衡量企业")
        text = text.replace("材料口径", "待核验")
        text = text.replace("项目证据充分度为 C", "关键经营信息仍待验证")
    text = text.replace("`01-verdict.md`", "尽调结论")
    text = text.replace("`02-final-decision.md`", "最终投资决策底稿")
    text = re.sub(r"`(?:outputs/)?[^`]+?\.md`", "研究底稿", text)
    text = re.sub(r"reviewer\s+Gate", "独立复核", text, flags=re.IGNORECASE)
    text = re.sub(r"reviewer", "独立复核", text, flags=re.IGNORECASE)
    text = re.sub(r"\bevidence matrix\b", "研究底稿", text, flags=re.IGNORECASE)
    text = re.sub(r"\bcanonical\b", "已确认版本", text, flags=re.IGNORECASE)
    text = re.sub(r"Fatal Gates?", "必须满足的投资前提", text, flags=re.IGNORECASE)
    text = text.replace("证据充分度：C", "研究基础：关键经营证据仍待补强")
    text = text.replace("A/B/C终局情景", "三类终局情景")

    for code, label in MILESTONES.items():
        text = re.sub(rf"{code}\s*[：:]\s*", "", text)
        text = re.sub(rf"{code}(?!\d)", label, text)
    for code, label in KSF_LABELS.items():
        text = text.replace(f"{code} {label}", label)
        text = text.replace(code, label)
    text = text.replace("R-2 大厂价格战/产能挤压", RISK_LABELS["R-2"])
    text = text.replace("R-3 全彩路线收敛资产贬值", RISK_LABELS["R-3"])
    text = text.replace("R-4 客户集中与供应链卡脖子", RISK_LABELS["R-4"])
    for code, label in RISK_LABELS.items():
        text = re.sub(rf"{re.escape(code)}\s+{re.escape(label.removesuffix('风险'))}", label, text)
        text = text.replace(code, label)

    text = INTERNAL_REFERENCE_RE.sub("", text)
    text = re.sub(r"\s*/\s*(?=[/）),，;；])", "", text)
    text = re.sub(r"(?<=[（(])\s*[/,，;；]+\s*", "", text)
    text = re.sub(r"\s*[/,，;；]+\s*(?=[）)])", "", text)
    text = re.sub(r"[（(]\s*[）)]", "", text)
    text = re.sub(r"（\s*，", "（", text)
    text = re.sub(r"（\s+", "（", text)
    text = re.sub(r"\(\s*,", "(", text)
    text = re.sub(r"\s+([，。；：、])", r"\1", text)
    text = re.sub(r"([，；、])\1+", r"\1", text)
    text = re.sub(r"风险\s+与\s+", "风险与", text)
    if re.fullmatch(r"[\s/,，;；、]+", text):
        text = ""
    text = re.sub(r"\s{2,}", " ", text).strip()

    if report_kind == "industry":
        text = text.replace("Wiki", "行业知识库")
    return text


def contains_industry_project_content(text: str) -> bool:
    return any(term in text for term in INDUSTRY_PROJECT_TERMS)


def add_inline(paragraph, text, base_size=11, color=INK, report_kind="project"):
    text = humanize_text(text, report_kind)
    cursor = 0
    for match in INLINE_RE.finditer(text):
        if match.start() > cursor:
            run = paragraph.add_run(text[cursor:match.start()])
            set_run_font(run, size=base_size, color=color)
        token = match.group(0)
        if token.startswith("**"):
            run = paragraph.add_run(token[2:-2])
            set_run_font(run, size=base_size, bold=True, color=color)
        else:
            run = paragraph.add_run(token[1:-1])
            set_run_font(run, size=max(base_size - 0.5, 8.5), color=DARK_BLUE)
        cursor = match.end()
    if cursor < len(text):
        run = paragraph.add_run(text[cursor:])
        set_run_font(run, size=base_size, color=color)


def is_separator(line):
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    return bool(cells) and all(re.fullmatch(r":?-{3,}:?", c or "-") for c in cells)


def split_row(line):
    return [c.strip() for c in line.strip().strip("|").split("|")]


def table_widths(rows):
    cols = max(len(r) for r in rows)
    weights = []
    for col in range(cols):
        lengths = [min(max(len(r[col]) if col < len(r) else 0, 4), 32) for r in rows]
        weights.append(max(sum(lengths) / max(len(lengths), 1), 6))
    total = sum(weights)
    widths = [max(750, int(TABLE_WIDTH_DXA * w / total)) for w in weights]
    delta = TABLE_WIDTH_DXA - sum(widths)
    widths[-1] += delta
    if widths[-1] < 650:
        shortage = 650 - widths[-1]
        widths[-1] = 650
        widest = max(range(len(widths) - 1), key=lambda i: widths[i])
        widths[widest] -= shortage
    return widths


def clean_table_rows(rows, report_kind):
    cleaned = [[humanize_text(value, report_kind) for value in row] for row in rows]
    if not cleaned:
        return cleaned
    cols = max(len(row) for row in cleaned)
    normalized = [row + [""] * (cols - len(row)) for row in cleaned]
    if report_kind == "industry":
        source_headers = ("依据", "证据", "来源", "判断依据")
        for index, header in enumerate(normalized[0]):
            if header in source_headers:
                for row in normalized[1:]:
                    if not re.search(r"[A-Za-z0-9\u4e00-\u9fff]", row[index]):
                        row[index] = "公开资料与产业访谈"
    excluded_headers = ("当前项目", "项目相对状态", "与项目重叠度") if report_kind == "industry" else ()
    candidate_indexes = [
        index for index in range(cols)
        if not any(term in normalized[0][index] for term in excluded_headers)
    ]
    if report_kind == "industry":
        normalized = [normalized[0]] + [
            row for row in normalized[1:]
            if not any(contains_industry_project_content(row[index]) for index in candidate_indexes)
        ]
    def meaningful(value):
        return bool(re.search(r"[A-Za-z0-9\u4e00-\u9fff]", value))

    keep = [
        index for index in range(cols)
        if index in candidate_indexes
        and (index == 0 or any(meaningful(row[index]) for row in normalized[1:]))
    ]
    return [[row[index] for index in keep] for row in normalized]


def add_table(doc, rows, report_kind):
    if not rows:
        return
    rows = clean_table_rows(rows, report_kind)
    cols = max(len(r) for r in rows)
    normalized = [r + [""] * (cols - len(r)) for r in rows]
    table = doc.add_table(rows=len(normalized), cols=cols)
    table.style = "Table Grid"
    widths = table_widths(normalized)
    set_table_geometry(table, widths)
    for row_index, row in enumerate(normalized):
        for col_index, value in enumerate(row):
            cell = table.cell(row_index, col_index)
            if row_index == 0:
                set_cell_shading(cell, LIGHT)
            p = cell.paragraphs[0]
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(2)
            p.paragraph_format.line_spacing = 1.05
            add_inline(p, value, base_size=8.5 if cols >= 5 else 9.2, color=INK, report_kind=report_kind)
            if row_index == 0:
                for run in p.runs:
                    run.bold = True
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_image(doc, image_path: Path, alt, report_kind):
    if not image_path.exists():
        p = doc.add_paragraph(style="Quote Callout")
        add_inline(p, f"图表缺失：{alt}（{image_path.name}）", base_size=10, color="9B1C1C", report_kind=report_kind)
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_together = True
    run = p.add_run()
    run.add_picture(str(image_path), width=Inches(6.45))
    cap = doc.add_paragraph(style="Figure Caption")
    add_inline(cap, f"图：{alt}", base_size=9, color=MUTED, report_kind=report_kind)


def add_blockquote(doc, text, report_kind):
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    set_table_geometry(table, [TABLE_WIDTH_DXA])
    cell = table.cell(0, 0)
    set_cell_shading(cell, CALLOUT)
    set_cell_margins(cell, top=120, start=160, bottom=120, end=160)
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    add_inline(p, text, base_size=10.2, color=DARK_BLUE, report_kind=report_kind)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def add_reader_note(doc, report_kind):
    if report_kind == "industry":
        text = (
            "阅读说明：本报告综合公开行业资料、产业访谈及专业机构数据形成。"
            "对缺乏交叉验证的信息已采用区间、情景或保守表述；报告中的市场预测用于投资判断，"
            "不构成对行业或企业经营结果的保证。"
        )
    else:
        text = (
            "阅读说明：本报告基于公司材料、管理层与产业访谈、财务及法律尽调、历史交易文件和公开行业资料。"
            "财务预测、成功概率与退出回报均为投资分析情景，不构成管理层承诺；交易权利以最终签署文件为准。"
        )
    add_blockquote(doc, text, report_kind)


def add_static_contents(doc, report_kind):
    doc.add_heading("目录", level=1)
    sections = (
        ["核心结论", "尽调后行业判断更新"] + [f"{i}. {name}" for i, name in enumerate([
            "行业概述", "市场规模与增速", "行业生命周期与技术发展周期", "产业链与价值链",
            "客户需求与购买行为", "新进入门槛", "替代威胁", "竞争分析",
            "行业关键成功因素分析", "行业风险梳理"], start=1)]
        if report_kind == "industry"
        else [
            "1. 核心结论", "2. 项目基本信息", "3. 业务介绍", "4. 项目核心优势",
            "5. 财务预测", "6. 交易方案", "7. 估值与回报测算", "8. 概率分析",
            "9. 风险及应对措施", "10. 研究依据与重要说明", "附录A：基础参数",
        ]
    )
    for item in sections:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.15)
        p.paragraph_format.space_after = Pt(3)
        add_inline(p, item, base_size=10.2, color=INK, report_kind=report_kind)
    doc.add_page_break()


def add_source_overview(doc, report_kind):
    doc.add_heading("主要资料来源与口径说明", level=1)
    items = (
        [
            "市场与出货：IDC、Counterpoint、TrendForce 等专业机构公开资料，用于终端出货、技术渗透率和相邻市场规模校准。",
            "企业与技术：上市公司公告、公司官网和产品发布、产业媒体、公开专利与学术论文，用于判断竞争格局、技术路线和量产进度。",
            "产业访谈：用于补充价格、认证周期和采购行为；缺少交叉验证的信息仅作为情景假设，不作为确定事实。",
            "不同机构的产品边界和统计口径并不完全一致，报告优先采用区间和情景推演；完整来源定位保留在可追溯研究版中。",
        ]
        if report_kind == "industry"
        else [
            "公司与经营：公司材料、管理层及产业链访谈，用于梳理产品、客户、产能和业务规划；未获独立验证的内容均按访谈口径处理。",
            "财务与法律：财务尽调、法律尽调、工商资料及历史交易协议，用于还原财务基线、股权结构、治理和投资者权利。",
            "行业与竞争：专业机构公开资料、公司公告、产业媒体、专利及论文，用于校准市场、路线和可比企业。",
            "财务预测、成功概率和退出回报均为投资分析情景，交易权利以最终签署文件为准；完整来源定位保留在可追溯研究版中。",
        ]
    )
    for item in items:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.5)
        p.paragraph_format.first_line_indent = Inches(-0.25)
        r = p.add_run("•\t")
        set_run_font(r, size=11, bold=True, color=BLUE)
        add_inline(p, item, report_kind=report_kind)


def render_markdown(doc, md_path: Path, report_kind: str):
    lines = md_path.read_text(encoding="utf-8").splitlines()
    i = 0
    paragraph_buffer = []
    seen_content_heading = False

    def flush_paragraph():
        nonlocal paragraph_buffer
        if paragraph_buffer:
            text = " ".join(part.strip() for part in paragraph_buffer if part.strip())
            if text:
                p = doc.add_paragraph()
                add_inline(p, text, report_kind=report_kind)
            paragraph_buffer = []

    while i < len(lines):
        line = lines[i].rstrip()
        stripped = line.strip()
        if not stripped:
            flush_paragraph()
            i += 1
            continue
        if i == 0 and stripped.startswith("# "):
            i += 1
            continue
        if report_kind == "industry" and stripped.startswith("## 11. 研究范围"):
            flush_paragraph()
            break
        if report_kind == "industry" and not stripped.startswith("|"):
            preview = humanize_text(stripped, report_kind)
            if contains_industry_project_content(preview):
                flush_paragraph()
                i += 1
                continue
        if report_kind == "project" and stripped.startswith("## 附录B"):
            flush_paragraph()
            break
        if report_kind == "project" and stripped == "## 10. 证据、反证与研究限制":
            stripped = "## 10. 研究依据与重要说明"
        if report_kind == "industry" and stripped == "## 尽调后行业结论变化摘要":
            stripped = "## 尽调后行业判断更新"

        image_match = re.fullmatch(r"!\[([^\]]*)\]\(([^)]+)\)", stripped)
        if image_match:
            flush_paragraph()
            alt, ref = image_match.groups()
            source_name = Path(ref).name
            if report_kind == "industry" and source_name not in INDUSTRY_WORD_IMAGES:
                i += 1
                continue
            if report_kind == "industry":
                ref = INDUSTRY_IMAGE_OVERRIDES.get(source_name, ref)
            else:
                ref = PROJECT_IMAGE_OVERRIDES.get(source_name, ref)
            add_image(doc, (md_path.parent / ref).resolve(), alt, report_kind)
            i += 1
            continue
        if stripped.startswith("|") and i + 1 < len(lines) and is_separator(lines[i + 1]):
            flush_paragraph()
            rows = [split_row(stripped)]
            i += 2
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append(split_row(lines[i]))
                i += 1
            add_table(doc, rows, report_kind)
            continue
        if stripped.startswith("### "):
            flush_paragraph()
            # Markdown H1 is the omitted document title, so H3 becomes Word Heading 2.
            doc.add_heading(humanize_text(stripped[4:].strip(), report_kind), level=2)
            seen_content_heading = True
            i += 1
            continue
        if stripped.startswith("## "):
            flush_paragraph()
            doc.add_heading(humanize_text(stripped[3:].strip(), report_kind), level=1)
            seen_content_heading = True
            i += 1
            continue
        if stripped.startswith("# "):
            flush_paragraph()
            doc.add_heading(humanize_text(stripped[2:].strip(), report_kind), level=1)
            seen_content_heading = True
            i += 1
            continue
        if stripped.startswith("> "):
            flush_paragraph()
            quote_lines = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                quote_lines.append(lines[i].strip().lstrip("> "))
                i += 1
            # The opening Markdown metadata block is an internal research header.
            # The Word version already has a cover and a human-readable source note.
            if seen_content_heading:
                add_blockquote(doc, " ".join(quote_lines), report_kind)
            continue
        if re.match(r"^[-*] ", stripped):
            flush_paragraph()
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.5)
            p.paragraph_format.first_line_indent = Inches(-0.25)
            p.paragraph_format.space_after = Pt(8)
            p.paragraph_format.line_spacing = 1.167
            r = p.add_run("•\t")
            set_run_font(r, size=11, bold=True, color=BLUE)
            add_inline(p, stripped[2:].strip(), report_kind=report_kind)
            i += 1
            continue
        numbered = re.match(r"^(\d+)\.\s+(.*)$", stripped)
        if numbered:
            flush_paragraph()
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.5)
            p.paragraph_format.first_line_indent = Inches(-0.25)
            p.paragraph_format.space_after = Pt(8)
            p.paragraph_format.line_spacing = 1.167
            r = p.add_run(numbered.group(1) + ".\t")
            set_run_font(r, size=11, bold=True, color=BLUE)
            add_inline(p, numbered.group(2), report_kind=report_kind)
            i += 1
            continue
        if stripped == "---":
            flush_paragraph()
            i += 1
            continue
        paragraph_buffer.append(stripped)
        i += 1
    flush_paragraph()


def add_document_properties(doc, title, subject):
    props = doc.core_properties
    props.title = title
    props.subject = subject
    props.author = "投资研究团队"
    props.keywords = "一级市场, 投资研究, 微玖光电, 最终版"
    props.comments = "研究截止2026-08-10；机密，仅供内部投资决策使用。"


def audit_document(doc, output_path):
    section = doc.sections[0]
    assert round(section.page_width.inches, 2) == 8.50
    assert round(section.page_height.inches, 2) == 11.00
    assert all(round(v.inches, 2) == 1.00 for v in (section.top_margin, section.right_margin, section.bottom_margin, section.left_margin))
    assert round(section.header_distance.inches, 3) == 0.492
    assert round(section.footer_distance.inches, 3) == 0.492
    assert doc.styles["Normal"].font.name == "Arial"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output_path)


def build(md_path, output_path, title, subtitle, project_label, running_label, report_kind):
    doc = Document()
    configure_styles(doc)
    configure_section(doc.sections[0], running_label)
    add_document_properties(doc, title, subtitle)
    add_cover(doc, title, subtitle, "最终版｜2026年8月10日", project_label)
    add_reader_note(doc, report_kind)
    add_static_contents(doc, report_kind)
    render_markdown(doc, md_path, report_kind)
    add_source_overview(doc, report_kind)
    audit_document(doc, output_path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    project = root / "projects" / "weijiuguangdian"
    build(
        project / "outputs" / "industry" / "04-industry-research-final.md",
        project / "outputs" / "industry" / "04-industry-research-final-submission.docx",
        "AR/智能眼镜 Micro LED 图像源行业研究报告",
        "尽调后更新与最终版行业判断",
        "研究范围：AR/智能眼镜 Micro LED 图像源器件",
        "Micro LED 图像源行业研究报告｜最终版",
        "industry",
    )
    build(
        project / "outputs" / "investment" / "02-investment-memo.md",
        project / "outputs" / "investment" / "02-investment-memo-final-submission.docx",
        "微玖光电项目投资分析报告",
        "基于假设交易条款的最终版",
        "交易假设：投前估值8亿元，其余核心权利沿用天使++轮",
        "微玖光电项目投资分析报告｜最终版",
        "project",
    )
    print("Generated final DOCX reports.")


if __name__ == "__main__":
    main()
