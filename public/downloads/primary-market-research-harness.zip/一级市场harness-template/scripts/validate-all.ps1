param(
    [string]$ProjectId,
    [switch]$SkipWorkspaceHygiene
)

$ErrorActionPreference = "Continue"
$harnessRoot = Split-Path -Parent $PSScriptRoot
$failures = [System.Collections.Generic.List[string]]::new()

# Cross-platform: pick pwsh on macOS/Linux when invoking sibling scripts.
. (Join-Path $PSScriptRoot '_harness_helpers.ps1')

function U([int[]]$CodePoints) {
    return -join ($CodePoints | ForEach-Object { [char]$_ })
}

$stageSegment = U @(0x7EC6,0x5206,0x7B5B,0x9009)
$stageDeepResearch = U @(0x884C,0x4E1A,0x4E0E,0x9879,0x76EE,0x6DF1,0x7814)
$stageDiligence = U @(0x5C3D,0x8C03,0x8BBE,0x8BA1)
$stageVerdict = (U @(0x6295,0x8D44,0x5224,0x65AD)) + [char]0xFF08 + (U @(0x5C3D,0x8C03,0x7ED3,0x8BBA,0x4E0E,0x6295,0x8D44,0x5EFA,0x8BAE)) + [char]0xFF09
$stageFinalConclusion = U @(0x6700,0x7EC8,0x6295,0x8D44,0x7ED3,0x8BBA)
$gateCore = U @(0x6838,0x5FC3,0x5224,0x65AD,0x786E,0x8BA4)
$pendingWikiValues = @(
    (U @(0x5F85,0x5EFA,0x7ACB)),
    (U @(0x5F85,0x5339,0x914D)),
    "-"
)

function Invoke-Validation([string]$Name, [scriptblock]$Action) {
    Write-Host "`n== $Name =="
    $global:LASTEXITCODE = 0
    & $Action
    if ($LASTEXITCODE -ne 0) { $failures.Add("$Name failed") }
}

function Get-StageStatus([string]$ProjectText, [string]$Stage) {
    $escaped = [regex]::Escape($Stage)
    $match = [regex]::Match($ProjectText, "(?m)^\|\s*$escaped\s*\|\s*([^|]+)\|")
    if ($match.Success) { return $match.Groups[1].Value.Trim() }
    return ""
}

function Require-Review([string]$ProjectPath, [string]$FileName, [string]$StageName) {
    $reviewPath = Join-Path $ProjectPath "reviews\$FileName"
    if (-not (Test-Path -LiteralPath $reviewPath)) {
        $failures.Add("$StageName requires reviews/$FileName in $(Split-Path -Leaf $ProjectPath)")
        return
    }
    $review = Get-Content -Raw -Encoding utf8 -LiteralPath $reviewPath
    if ($review -notmatch 'investment_reviewer') { $failures.Add("$FileName does not identify investment_reviewer") }
    if ($review -match '\u72EC\u7ACB reviewer \u672A\u8FD4\u56DE|\u4E3B Agent \u6309.{0,20}\u81EA\u68C0') {
        $failures.Add("$FileName is self-review, not independent review")
    }
    if ($review -match '(?im)\u590D\u6838\u7ED3\u8BBA.{0,20}\bFAIL\b') { $failures.Add("$FileName has FAIL conclusion") }
    if ($review -notmatch 'PASS') { $failures.Add("$FileName has no PASS/PASS WITH CONDITIONS conclusion") }
}

Invoke-Validation "Harness structure" { Invoke-HarnessScript -File (Join-Path $PSScriptRoot "validate-harness.ps1") }
Invoke-Validation "Project resolver regression" { Invoke-HarnessScript -File (Join-Path $PSScriptRoot "tests\test-resolve-project-context.ps1") }
Invoke-Validation "Profile resolver regression" { Invoke-HarnessScript -File (Join-Path $PSScriptRoot "tests\test-resolve-profile-context.ps1") }
Invoke-Validation "Portfolio validation regression" { Invoke-HarnessScript -File (Join-Path $PSScriptRoot "tests\test-portfolio-validation.ps1") }
Invoke-Validation "Chat knowledge ingestion regression" { Invoke-HarnessScript -File (Join-Path $PSScriptRoot "tests\test-chat-knowledge-ingestion.ps1") }
Invoke-Validation "Portfolio structure" { Invoke-HarnessScript -File (Join-Path $PSScriptRoot "validate-portfolio.ps1") }
Invoke-Validation "Evolution and profiles" { Invoke-HarnessScript -File (Join-Path $PSScriptRoot "validate-evolution.ps1") -Arguments @("-RequireRuntimeSync") }

$projectRoot = Join-Path $harnessRoot "projects"
$projects = if ($ProjectId) { @(Get-Item -LiteralPath (Join-Path $projectRoot $ProjectId) -ErrorAction Stop) } else { @(Get-ChildItem -LiteralPath $projectRoot -Directory) }
$indexPath = Join-Path $projectRoot "INDEX.md"
$indexLines = Get-Content -Encoding utf8 -LiteralPath $indexPath

foreach ($project in $projects) {
    $id = $project.Name
    $projectFile = Join-Path $project.FullName "PROJECT.md"
    if (-not (Test-Path -LiteralPath $projectFile)) { $failures.Add("$id missing PROJECT.md"); continue }
    $projectText = Get-Content -Raw -Encoding utf8 -LiteralPath $projectFile

    Invoke-Validation "Evidence: $id" { Invoke-HarnessScript -File (Join-Path $PSScriptRoot "validate-evidence.ps1") -Arguments @("-ProjectId", $id) }

    $workbook = Join-Path $project.FullName "outputs\industry\02-segment-priority.xlsx"
    if (Test-Path -LiteralPath $workbook) {
        Invoke-Validation "Workbook: $id" { Invoke-HarnessScript -File (Join-Path $PSScriptRoot "validate-workbook.ps1") -Arguments @("-Path", $workbook) }
    }

    if ((Get-StageStatus $projectText $stageSegment) -eq "Completed") { Require-Review $project.FullName "segment-screen-review.md" "segment-screening" }
    if ((Get-StageStatus $projectText $stageDeepResearch) -eq "Completed") { Require-Review $project.FullName "core-judgment-review.md" "deep-research" }
    if ((Get-StageStatus $projectText $stageDiligence) -eq "Completed") { Require-Review $project.FullName "diligence-scope-review.md" "diligence-design" }
    if ((Get-StageStatus $projectText $stageVerdict) -eq "Completed") { Require-Review $project.FullName "investment-verdict-review.md" "investment-verdict" }
    if ((Get-StageStatus $projectText $stageFinalConclusion) -eq "Completed") {
        Invoke-Validation "Final conclusion: $id" { Invoke-HarnessScript -File (Join-Path $PSScriptRoot "validate-final-conclusion.ps1") -Arguments @("-ProjectId", $id) }
    }

    $updatedMatch = [regex]::Match($projectText, '(?m)^- \u6700\u540E\u66F4\u65B0\uFF1A`([^`]+)`')
    $indexPattern = '^\|\s*' + [regex]::Escape($id) + '\s*\|'
    $indexLine = @($indexLines | Where-Object { $_ -match $indexPattern }) | Select-Object -First 1
    if (-not $indexLine) { $failures.Add("$id missing from projects/INDEX.md") }
    elseif ($updatedMatch.Success) {
        $cells = $indexLine.Trim('|').Split('|') | ForEach-Object { $_.Trim().Trim('`') }
        if ($cells.Count -ge 7 -and $cells[6] -ne $updatedMatch.Groups[1].Value) {
            $failures.Add("$id last-update mismatch: PROJECT=$($updatedMatch.Groups[1].Value), INDEX=$($cells[6])")
        }
        $investmentDone = (Get-StageStatus $projectText $stageVerdict) -eq "Completed"
        if ($investmentDone -and $cells[3] -notmatch '\u6295\u8D44\u5224\u65AD') { $failures.Add("$id INDEX status is stale; investment judgment is completed") }

        $gatePattern = '(?m)^\|\s*' + [regex]::Escape($gateCore) + '\s*\|\s*Confirmed\s*\|'
        $coreGateConfirmed = $projectText -match $gatePattern
        if ($coreGateConfirmed -and $cells[4] -in $pendingWikiValues) { $failures.Add("$id completed core gate but has no promoted Wiki topic") }
    }
}

Invoke-Validation "Workbook template" { Invoke-HarnessScript -File (Join-Path $PSScriptRoot "validate-workbook.ps1") -Arguments @("-Path", (Join-Path $harnessRoot "templates\02-segment-priority.xlsx"), "-AllowTemplateReady") }

if (-not $SkipWorkspaceHygiene) {
    $rootTmp = Join-Path $harnessRoot "tmp"
    if (Test-Path -LiteralPath $rootTmp) {
        $sensitive = @(Get-ChildItem -LiteralPath $rootTmp -Recurse -File | Where-Object {
            $_.Extension -in @('.pdf', '.docx', '.doc', '.xls', '.xlsx', '.pptx', '.txt') -and
            $_.FullName -notmatch '[\\/]v1-closeout-20260810[\\/]'
        })
        if ($sensitive.Count -gt 0) { $failures.Add("Root tmp contains $($sensitive.Count) potentially project-sensitive files") }
    }
    $rootInboxFiles = @(Get-ChildItem -LiteralPath (Join-Path $harnessRoot ".agent-inbox") -File -ErrorAction SilentlyContinue)
    if ($rootInboxFiles.Count -gt 0) { $failures.Add(".agent-inbox contains non-namespaced root task files") }
}

Write-Host "`n== Validation summary =="
if ($failures.Count -gt 0) {
    $failures | Sort-Object -Unique | ForEach-Object { Write-Host "FAIL: $_" -ForegroundColor Red }
    exit 1
}

Write-Host "All harness validations passed." -ForegroundColor Green
