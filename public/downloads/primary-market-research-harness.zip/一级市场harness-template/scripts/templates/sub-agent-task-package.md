# Sub-Agent Task Package (Generic Shell)

> **本文件是 sub-agent 任务包的通用外壳**。主 Agent 在派发任何 sub-agent 前，必须按本模板把全部上下文填好，写到 `.agent-inbox/<agent-task-name>.md`，然后才 spawn。
>
> **核心约束**：sub-agent 收到任务包后，**禁止重新读取 AGENTS.md、其他 SKILL.md、或任务包未列出的文件**。任务包已包含所有需要的信息；重读会造成 token 与时间浪费，也会导致 sub-agent 自己选择重点而偏离主 Agent 已经规划的范围。
>
> **兜底**：本环境的 sub-agent 消息通道偶发"唤醒成功、任务正文丢失"。每个 sub-agent 启动后会先查 `.agent-inbox/` 找以自己任务名命名的 .md 文件。任务包落到 `.agent-inbox/` 即可。

## 1. 任务身份（必填）

| 字段 | 取值 | 说明 |
| --- | --- | --- |
| Agent 角色 | `<research_worker / investment_reviewer / portfolio_reviewer>` | 必须与 `.codex/agents/<name>.toml` 一致 |
| 项目 ID | `<project_id>` | 仅在 research_worker / investment_reviewer 时填 |
| 阶段 | `<细分筛选确认前 / 核心判断确认前 / 投资判断前 / ...>` | 决定实质性章节清单与预算 |
| 截止时间 | `<YYYY-MM-DD HH:MM>` | 硬截止；超时主 Agent 按"未完成"处理 |
| Time budget | `<15 / 20 / 25 / 30 分钟>` | 实质性审核预算（reviewer）或总预算（researcher） |

## 2. 已解析的项目上下文（不要再查）

主 Agent 已经把以下项目层信息填好。sub-agent 收到后**直接使用**，**禁止**通过读 AGENTS.md、读 projects/INDEX.md、读 wiki/INDEX.md 自己去 match：

- 公司主体：
- 行业细分（Primary segment）：
- Adjacent segments（不需要深研但要排除的范围）：
- Wiki Topic ID + last_verified_at + source_status：
- 已沉淀 Wiki 复用范围（具体哪些章节可直接复用）：
- 输入材料入口：列出 BP / 访谈纪要 / 已有研究 的路径（按"已读过一次就引用摘要"的口径，不要让 sub-agent 重新读全文）

## 3. 禁读范围（绝对禁止读取）

- 其他项目的任何文件（包括 projects/INDEX.md 中提到的其他 project_id）
- canonical 文件（除非任务包"可写"字段另列）
- AGENTS.md、WORKFLOW.md、EVOLUTION.md（sub-agent 不应该理解全 harness 治理结构）
- 其他 SKILL.md（除非任务包"必读 SKILL"另列）
- templates/ 全目录（任务包会内嵌需要的小节模板，不要让 sub-agent 自己去翻）

## 4. 可读路径（仅此已列出）

按 sub-agent 类型列出具体路径，建议已经**分段读过一次的概要**，让 sub-agent 不必从头读全文：

- `<path 1>` — 用途 + 上次读取过的关键内容摘要
- `<path 2>` — 用途 + 上次读取过的关键内容摘要
- ...

## 5. 已完成的研究（避免重复劳动）

主 Agent 已经把已知内容塞进来，sub-agent 在追加时只能消化，**别从零再做**：

- 已填 E-IDs：E-001 ~ E-NNN（共 N 个）
- 已填 SRC-IDs：SRC-001 ~ SRC-NNN
- 已填 Q-IDs 与已知答案：列出 Q-xx 及其当前 status
- 已填 C-IDs：列出主张
- 待补充（已识别但没填的）：列出具体缺口

## 6. 你的研究问题（按优先级）

主 Agent 应当按重要性排序、给 sub-agent 留好"足够但不过度"的边界：

### Q1：<具体问题>
- 期望输出：<具体到章节或表格>
- 必读来源类型：<公开年报 / 学术论文 / 行业报告 / 监管文件>
- 已有线索：<如"LightCounting 提到...">
- 期望证据 ID 区间：本任务可用 E-NNN ~ E-MMM（避免与已有冲突）

### Q2：<具体问题>
...

## 7. 输出格式（明确要求）

- 文件路径：<sub-agent 是否直接写文件，还是只通过消息返回结构化草稿>
- 章节：模板 `<template-name>` 的 `<sections>`（**小节模板文本内嵌在任务包里**，sub-agent 不用自己翻 templates/）
- E-ID 分配区间：E-NNN ~ E-MMM
- SRC-ID 分配区间：SRC-NNN ~ SRC-NMM
- 引用格式：`<事实陈述> [E-XXX]`，并在 `<source-index 路径>` 末尾追加 `SRC-NNN`
- 失败/找不到来源的处理：标注"未获取" + 写出检索路径，不许编造

## 8. 完成判据

- [ ] 所有研究问题都有答案或明确标注"未获取 + 检索路径"
- [ ] 每个事实有 E-xxx 引用
- [ ] source-index.md 中所有新来源已登记（如果有写入权限）
- [ ] 报告输出符合模板要求
- [ ] 没有修改 canonical 文件
- [ ] 实际耗时在预算内（或说明超预算的具体卡点）

## 9. 停止条件（任何一条触发立即停止）

- 找到 2+ 个独立来源相互印证 → 不必再找第三个
- 找不到公开来源 → 标注"未获取" + 写明检索路径，**不要编造**
- 已超过预算时间 1/3 → 缩小范围或收尾
- 修改了任何 canonical 文件 → 立即停止并报告主 Agent