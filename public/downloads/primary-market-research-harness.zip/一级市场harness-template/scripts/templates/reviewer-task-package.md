# Reviewer Task Package

> 这是 `sub-agent-task-package.md` 的 specialization。`investment_reviewer` 用于在细分筛选 / 核心判断 / 投资判断 / 最终结论 / 最终投资结论 Gate 前做独立复核。
>
> **核心约束**：
> 1. 任务包已经预解析了项目上下文、当前阶段、实质性章节清单、预算上限、必读 SKILL 段——禁止重读 AGENTS.md、其他 SKILL.md、其他项目目录、templates/。
> 2. 默认按 **Tiered Review** 执行：只对驱动投资决策的实质性章节用力，形式审核由 `validate-evidence.ps1` 自动覆盖，reviewer 直接读其输出当作结论，不要重跑。
> 3. 预算由 evidence-review SKILL 第"Time Budget"小节规定，超预算必须把已得发现写入 review 并标注 "review incomplete due to budget"，**禁止 redo / 重跑 / 扩大范围拖延**。

## 1. 任务身份

| 字段 | 取值 |
| --- | --- |
| Agent 角色 | `investment_reviewer` |
| 项目 ID | `<project_id>` |
| 当前阶段 | `<细分筛选 / 核心判断 / 投资判断 / 最终结论 / 最终投资结论>` |
| 截止时间 | `<YYYY-MM-DD HH:MM>` |
| Time budget | 实质性 `<15 / 20 / 25 / 30>` 分钟 + 形式 3 分钟（参考 evidence-review SKILL Time Budget 表） |

## 2. 已解析的项目上下文

- 公司主体：
- 行业细分 + Wiki Topic：
- 已确认的 Gate 状态：`PROJECT.md` 第 5 节记录
- 上一阶段的产物路径（reviewer 必须只读这些，不读其他东西）：
  - `projects/<id>/outputs/industry/02-segment-priority.md`（如果当前是细分筛选 Gate）
  - `projects/<id>/outputs/industry/03-industry-research.md`（如果当前是核心判断 / 投资判断 Gate）
  - `projects/<id>/outputs/project/01-project-element-map.md` + `01-project-assessment.md`（同上）
  - `projects/<id>/outputs/investment/01-verdict.md`（如果是投资判断 / 最终结论 Gate）
  - `projects/<id>/outputs/investment/02-final-decision.md`（如果是最终投资结论 Gate）
- 已有 review 文件（避免重复）：`projects/<id>/reviews/*.md`

## 3. 禁读范围

- 其他项目目录
- AGENTS.md / WORKFLOW.md / EVOLUTION.md
- 其他 SKILL.md
- templates/ 全目录（任务包第 4 节已内嵌必要小节）

## 4. 必读 SKILL / 模板（**内嵌在任务包内，禁止再读原文件**）

主 Agent 复制以下内容到本任务包（按当前阶段勾选）：

- [ ] `evidence-review/SKILL.md` 全文（必含，因 reviewer 必须知道分层规则）
- [ ] `references/evidence-standard.md` 来源分级与口径要求小节
- [ ] `references/investment-rubric.md`（如果是 verdict / final decision Gate）
- [ ] `references/research-framework.md` 中与"Reviewer 必须重算"相关的小节
- [ ] `references/portfolio-selection-framework.md`（如果是项目池择优的 reviewer）

<small>（主 Agent 实际填写时把上面 checkbox 替换为已复制小节全文）</small>

## 5. 可读路径

只列 reviewer 真正需要的项目本地路径（已在第 2 节列出）

## 6. 形式审核结论（直接来自 validate-evidence.ps1）

主 Agent 已经在 spawn 前运行 `pwsh -NoProfile -File ./scripts/validate-evidence.ps1 -ProjectId <id>` 并把**完整输出**嵌在这里。reviewer **不要重跑、不要重读章节内容去复验结构**，直接把这段输出当作形式审核结论。

```
<validate-evidence.ps1 完整输出>
```

## 7. 实质性审核章节清单

按当前阶段只审以下章节（详见 evidence-review SKILL Tiered Review 表格）：

- 细分筛选 Gate：第 2 章排名底稿 + 第 2 章公司层粗筛（仅 P1/P2 + 项目方向）
- 核心判断 Gate：第 4 / 6 / 7 / 8 / 9 / 10 章
- 投资判断 / 最终结论 Gate：同上 + 01-verdict.md
- 最终投资结论 Gate：同上 + 02-final-decision.md

**不要审**：第 1 章行业概述、第 3 章非拐点部分、第 11 章研究范围。

## 8. 输出格式

reviewer 通过最终消息返回：

```
## Reviewer Report — <项目 ID> — <当前阶段 Gate>

### PASS / PASS WITH CONDITIONS / FAIL

### Scope
- Reviewed artifacts: <列出>
- Reviewed versions: <文件名 + last modified>

### Time spent
- Substantive: <N> min (budget <M> min)
- Formal: <N> min (budget 3 min)
- Total: <N> min
- 实际耗时 vs 预算：在/超出预算（说明超预算的具体卡点）

### Inspected chapters (substantive)
- <Chapter N>: <1 句话结论 + 关键证据 ID>

### Findings (按决策影响排序)
1. [P0 / P1 / P2] <位置> — <问题> — <影响> — <Q/E/SRC/DD ID>
2. ...

### Arithmetic audit table (仅 verdict / final 阶段)
| 项目 | Stated | Recomputed | Variance | Status |

### Required fixes / additional evidence
- ...

### Residual limitations after fixes
- ...

### Closure checklist (仅 PASS WITH CONDITIONS)
- [ ] COND-A: ...
- [ ] COND-B: ...
```

reviewer 也可写 `.agent-inbox/<task-name>.response.md` 留档。**不要修改任何 canonical 文件**。

## 9. 完成判据

- [ ] 输出包含 PASS / PASS WITH CONDITIONS / FAIL
- [ ] 输出包含实际耗时与预算对比
- [ ] 输出列出"实质性审核章节清单"（证明分层纪律）
- [ ] findings 按决策影响排序
- [ ] verdict / final 阶段包含算式重算表
- [ ] 没有修改 canonical 文件
- [ ] 没有重读 AGENTS.md / 其他 SKILL.md / templates/
- [ ] 实际耗时在预算内（或标注超预算的具体卡点）

## 10. 停止条件（任何一条触发立即停止）

- 已超过预算时间 → 把已得发现写入 review 并标注 "review incomplete due to budget"
- 发现阻断性问题 → 立即出 FAIL，不要继续扩大检查
- 试图读取其他项目 / canonical 文件 → 立即停止并报告主 Agent