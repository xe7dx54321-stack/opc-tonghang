# Research Worker Task Package

> 这是 `sub-agent-task-package.md` 的 specialization。`research_worker` 用于边界明确、相互独立的研究包（如市场规模、产业链、竞争、技术、政策）。
> 主 Agent 派发研究 worker 时，**按本模板填好所有上下文**，写到 `.agent-inbox/research-worker-<topic>.md`。
>
> **核心约束**：worker 收到任务包后，**禁止重读 AGENTS.md、其他 SKILL.md、templates/、其他项目目录**。任务包内嵌所需小节模板、预解析项目上下文、分配 E-ID / SRC-ID 区间，worker 直接执行研究并按格式返回。

## 1. 任务身份

| 字段 | 取值 |
| --- | --- |
| Agent 角色 | `research_worker` |
| 项目 ID | `<project_id>` |
| 研究包主题 | `<市场规模与客户需求 / 价值链竞争与替代 / 技术壁垒与风险>` |
| Worker 编号 | `<worker 1 / 2 / 3>`（与同项目其他 worker 互斥分配 E-ID/SRC-ID 区间） |
| 截止时间 | `<YYYY-MM-DD HH:MM>` |
| Time budget | `<60 / 90 / 120 分钟>`（按章节复杂度，主 Agent 在任务包指定） |

## 2. 已解析的项目上下文

- 公司主体：
- 行业细分：
- Wiki Topic：`<topic_id>`（last_verified_at、source_status）
- 已沉淀 Wiki 可复用范围：列出可以直接复用的 conclusions.md / theses.md / claims.md 子集
- 项目主 Agent 已经阅读过且认为与你相关的输入材料摘要：
  - BP：<1-2 句话定位>
  - 访谈：<管理层/核心团队/单位>
  - 已有研究：`<wiki 链接或文件名>`

## 3. 禁读范围

- 其他项目（projects/INDEX.md 中提到的其他 project_id 全部禁读）
- AGENTS.md / WORKFLOW.md / EVOLUTION.md
- 其他 SKILL.md（除非任务包第 4 节列了）
- templates/ 全目录（任务包第 7 节会内嵌需要的小节模板）

## 4. 必读 SKILL / 模板（内嵌在任务包内，**禁止再读原文件**）

主 Agent 把下面 Sub-Skill 的相关小节**完整复制**到这里（按需挑选）：

- [ ] `industry-project-research/SKILL.md` 中 Plan the Research / Integrate / Report Structure 相关小节（仅 Plan + Integrate 段，避免重复 Report Structure 全部内容）
- [ ] `references/research-framework.md` 相关小节
- [ ] `references/evidence-standard.md` 来源分级与口径要求小节
- [ ] `references/investment-rubric.md`（如果 worker 输出会被 verdict 阶段使用，复制相关小节）

<small>（主 Agent 实际填写时把上面 checkbox 替换为已复制小节全文）</small>

## 5. 可读路径

只列本次研究真正需要的项目本地路径：

- `projects/<id>/PROJECT.md` — 项目基础信息 / 当前 Gate 状态 / 决策者
- `projects/<id>/inputs/manifest.md` — 输入材料登记
- `projects/<id>/outputs/industry/01-segment-map.md` — 行业图谱（已确认）
- `projects/<id>/outputs/industry/02-segment-priority.md` — 细分筛选（已确认）
- `projects/<id>/evidence/sourcestem.md` — 已登记来源清单
- `projects/<id>/evidence/evidence-matrix.md` — 已填问题 / 证据 / 主张状态
- 主 Agent 指定的 Wiki Topic 子文件路径（如有）
- 主 Agent 指定的项目 1-2 个关键上游研究产物路径（如有）

## 6. 已完成的研究（避免重复劳动）

主 Agent 已经把当前 evidence-matrix 与 source-index 的状态摘要嵌在这里，worker 只能补充缺口，**不能修改、不能删除、不能重新编已确认的证据**。

- 已填 E-IDs：`<E-001 ~ E-NNN>`，共 N 个；本 worker 可分配 E-NNN+1 ~ E-MMM
- 已填 SRC-IDs：`<SRC-001 ~ SRC-NNN>`，本 worker 可分配 SRC-NNN+1 ~ SRC-NMM
- 已填 Q-IDs 与已知答案：列出 Q-xx 及其当前 status
- 待补充（已识别但没填的）：列出主 Agent 留给你研究的 Q-xx 缺口

## 7. 输出格式

- 输出文件：本任务**只通过最终消息返回结构化草稿**，**禁止写任何 canonical 文件**；主 Agent 负责合并
- 章节：参考任务包第 4 节内嵌的小节模板（不是 templates/03-industry-research.md 全文）
- E-ID 分配：本 worker 用 E-NNN+1 ~ E-MMM（不要占用其它 worker 的区间）
- SRC-ID 分配：本 worker 用 SRC-NNN+1 ~ SRC-NMM
- 引用格式：`<事实陈述> [E-XXX]`；来源登记条目写到响应消息末尾的 `## New sources` 段，主 Agent 会负责写到 source-index.md
- 找不到来源时：标注"未获取"+ 列出实际检索路径，**不要编造**

## 8. 完成判据

- [ ] 第 6 节列出的所有待补充 Q-xx 都有答案或明确标注"未获取 + 检索路径"
- [ ] 每个事实有 E-xxx 引用
- [ ] 输出章节符合模板第 4 节内嵌的小节结构
- [ ] 没有修改任何 canonical 文件
- [ ] 没有读取其他项目文件
- [ ] 没有重读 AGENTS.md / 其他 SKILL.md / templates/
- [ ] 实际耗时在预算内（或说明超预算的具体卡点）

## 9. 停止条件（任何一条触发立即停止）

- 找到 2+ 个独立来源相互印证 → 不必再找第三个
- 找不到公开来源 → 标注"未获取"+ 检索路径，不要编造
- 已超过预算时间 1/3 → 缩小范围或收尾
- 修改了任何 canonical 文件 → 立即停止并报告主 Agent
- 试图读取 AGENTS.md / 其他 SKILL.md / templates/ → 立即停止并报告主 Agent