﻿param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectId
)

$ErrorActionPreference = "Stop"
$harnessRoot = Split-Path -Parent $PSScriptRoot
$projectDir = Join-Path $harnessRoot "projects\$ProjectId"

if (-not (Test-Path -LiteralPath $projectDir -PathType Container)) {
    Write-Host "Project not found: $ProjectId" -ForegroundColor Red
    exit 2
}

$errors = [System.Collections.Generic.List[string]]::new()
$warnings = [System.Collections.Generic.List[string]]::new()

# ---------- 读取证据文件 ----------
$matrixPath = Join-Path $projectDir "evidence\evidence-matrix.md"
$sourcePath = Join-Path $projectDir "evidence\source-index.md"
$matrix = if (Test-Path -LiteralPath $matrixPath -PathType Leaf) {
    Get-Content -Raw -Encoding utf8 -LiteralPath $matrixPath
} else { "" }
$source = if (Test-Path -LiteralPath $sourcePath -PathType Leaf) {
    Get-Content -Raw -Encoding utf8 -LiteralPath $sourcePath
} else { "" }

# ---------- 收集已定义编号并检查重复 ----------
$eDefined = @{}; $qDefined = @{}; $cDefined = @{}
$srcDefined = @{}

function Add-Definitions {
    param(
        [string]$Content,
        [hashtable]$Set,
        [string]$Label,
        [string]$Prefix
    )
    foreach ($m in [regex]::Matches($Content, "(?m)^\|\s*($Prefix)\s*\|")) {
        $id = $m.Groups[1].Value
        if ($Set.ContainsKey($id)) {
            $script:errors.Add("Duplicate $Label id: $id")
        } else {
            $Set[$id] = $true
        }
    }
}

Add-Definitions -Content $matrix -Set $eDefined -Label "E" -Prefix "E-\d+"
Add-Definitions -Content $matrix -Set $qDefined -Label "Q" -Prefix "Q-\d+"
Add-Definitions -Content $matrix -Set $cDefined -Label "C" -Prefix "C-\d+"
Add-Definitions -Content $source -Set $srcDefined -Label "SRC" -Prefix "SRC-\d+"

# ---------- 来源分级一致性检查（未打开原文不得标 A/B） ----------
$sourceLines = $source -split "`r?`n"
foreach ($line in $sourceLines) {
    if ($line -match "^\|\s*SRC-\d+\s*\|") {
        $cells = $line.Trim().Trim('|').Split('|') | ForEach-Object { $_.Trim() }
        if ($cells.Count -lt 9) { continue }
        $grade = $cells[6]
        $txt = $cells[7] + " " + $cells[8]
        if (($grade -eq "A" -or $grade -eq "B") -and
            $txt -match "未打开|snippet|搜索摘要" -and
            $txt -notmatch "原文已打开") {
            $errors.Add("$($cells[0]) grade $grade but source not opened (marker: 未打开/snippet/搜索摘要)")
        }
    }
}

# ---------- 证据矩阵内部交叉引用 ----------
$matrixLines = $matrix -split "`r?`n"
foreach ($line in $matrixLines) {
    if ($line -match "^\|\s*E-\d+\s*\|") {
        $cells = $line.Trim().Trim('|').Split('|') | ForEach-Object { $_.Trim() }
        if ($cells.Count -lt 6) { continue }
        $eid = $cells[0]
        foreach ($q in [regex]::Matches($cells[1], "Q-\d+")) {
            if (-not $qDefined.ContainsKey($q.Value)) { $errors.Add("$eid references undefined $($q.Value)") }
        }
        foreach ($c in [regex]::Matches($cells[2], "C-\d+")) {
            if (-not $cDefined.ContainsKey($c.Value)) { $errors.Add("$eid references undefined $($c.Value)") }
        }
        foreach ($s in [regex]::Matches($cells[5], "SRC-\d+")) {
            if (-not $srcDefined.ContainsKey($s.Value)) { $errors.Add("$eid references undefined $($s.Value)") }
        }
    }
    elseif ($line -match "^\|\s*Q-\d+\s*\|") {
        $cells = $line.Trim().Trim('|').Split('|') | ForEach-Object { $_.Trim() }
        $qid = $cells[0]
        for ($i = 1; $i -lt $cells.Count; $i++) {
            foreach ($e in [regex]::Matches($cells[$i], "E-\d+")) {
                if (-not $eDefined.ContainsKey($e.Value)) { $errors.Add("$qid references undefined $($e.Value)") }
            }
        }
    }
    elseif ($line -match "^\|\s*C-\d+\s*\|") {
        $cells = $line.Trim().Trim('|').Split('|') | ForEach-Object { $_.Trim() }
        $cid = $cells[0]
        for ($i = 1; $i -lt $cells.Count; $i++) {
            foreach ($q in [regex]::Matches($cells[$i], "Q-\d+")) {
                if (-not $qDefined.ContainsKey($q.Value)) { $errors.Add("$cid references undefined $($q.Value)") }
            }
            foreach ($e in [regex]::Matches($cells[$i], "E-\d+")) {
                if (-not $eDefined.ContainsKey($e.Value)) { $errors.Add("$cid references undefined $($e.Value)") }
            }
        }
    }
}

# ---------- 扫描阶段产物中的引用与图片 ----------
$scanRoots = @(
    (Join-Path $projectDir "outputs"),
    (Join-Path $projectDir "reviews")
)
$scanFiles = @()
foreach ($root in $scanRoots) {
    if (Test-Path -LiteralPath $root -PathType Container) {
        $scanFiles += Get-ChildItem -LiteralPath $root -Recurse -Filter *.md -File
    }
}

$refPatterns = @(
    @{ Name = "E";    Pattern = "E-\d+" },
    @{ Name = "SRC";  Pattern = "SRC-\d+" },
    @{ Name = "Q";    Pattern = "Q-\d+" },
    @{ Name = "C";    Pattern = "(?<![A-Za-z])C-\d+" }
)
$definedMap = @{ E = $eDefined; SRC = $srcDefined; Q = $qDefined; C = $cDefined }

# ---------- 项目级证据语义防错规则（可选 evidence\semantic-guard.json） ----------
# 规则格式：{"evidenceDenyRules":[{"id":"E-020","forbidden":["合格率"],"note":"..."},
#   {"forbiddenPair":["中望","48\\.94"],"note":"..."},
#   {"id":"E-028","requireInferenceWhen":"12[-－—]36","note":"..."}]}
$semanticRules = @()
$guardPath = Join-Path $projectDir "evidence\semantic-guard.json"
if (Test-Path -LiteralPath $guardPath -PathType Leaf) {
    try {
        $semanticRules = (Get-Content -Raw -Encoding utf8 -LiteralPath $guardPath | ConvertFrom-Json).evidenceDenyRules
    } catch {
        $errors.Add("semantic-guard.json unreadable: $($_.Exception.Message)")
    }
}

foreach ($file in $scanFiles) {
    $content = Get-Content -Raw -Encoding utf8 -LiteralPath $file.FullName
    $relFile = $file.FullName.Substring($harnessRoot.Length).TrimStart('\', '/')

    foreach ($rp in $refPatterns) {
        foreach ($m in [regex]::Matches($content, $rp.Pattern)) {
            $id = $m.Value
            if (-not $definedMap[$rp.Name].ContainsKey($id)) {
                $errors.Add("$relFile references undefined $($rp.Name): $id")
            }
        }
    }

    foreach ($m in [regex]::Matches($content, "!\[[^\]]*\]\(([^)]+)\)")) {
        $ref = $m.Groups[1].Value.Trim()
        if ($ref -match "\.(png|jpg|jpeg|gif|svg)$" -and $ref -notmatch "^(https?://|file://)") {
            $imgPath = Join-Path $file.DirectoryName $ref
            if (-not (Test-Path -LiteralPath $imgPath -PathType Leaf)) {
                $errors.Add("$relFile references missing image: $ref")
            }
        }
    }

    # 语义防错规则只针对研究产出（outputs），不扫描复核报告等元文档（元文档可能合法引用违规描述）
    if ($relFile -match "\\outputs\\") {
        foreach ($rule in $semanticRules) {
            foreach ($line in ($content -split "`r?`n")) {
                $hasId = -not $rule.id -or $line -match [regex]::Escape([string]$rule.id)
                if (-not $hasId) { continue }
                if ($rule.forbidden) {
                    foreach ($f in $rule.forbidden) {
                        if ($line -match [string]$f) {
                            $errors.Add("$relFile semantic guard: $($rule.note) -> $($line.Trim())")
                        }
                    }
                }
                if ($rule.forbiddenPair) {
                    $p1 = [string]$rule.forbiddenPair[0]
                    $p2 = [string]$rule.forbiddenPair[1]
                    if ($line -match $p1 -and $line -match $p2) {
                        $errors.Add("$relFile semantic guard: $($rule.note) -> $($line.Trim())")
                    }
                }
                if ($rule.requireInferenceWhen -and $line -match [string]$rule.requireInferenceWhen -and $line -notmatch "推断") {
                    $errors.Add("$relFile semantic guard: $($rule.note) -> $($line.Trim())")
                }
            }
        }
    }
}

# ---------- 03 行业深研报告结构检查 ----------
$reportPath = Join-Path $projectDir "outputs\industry\03-industry-research.md"
if (Test-Path -LiteralPath $reportPath -PathType Leaf) {
    $report = Get-Content -Raw -Encoding utf8 -LiteralPath $reportPath
    $requiredSections = @(
        "## 核心结论",
        "## 1. 行业概述",
        "## 2. 市场规模与增速",
        "## 3. 行业生命周期与技术发展周期",
        "## 4. 产业链与价值链",
        "## 5. 客户需求与购买行为",
        "## 6. 新进入门槛",
        "## 7. 替代威胁",
        "## 8. 竞争分析",
        "## 9. 行业关键成功因素分析",
        "## 10. 行业风险梳理",
        "## 11. 研究范围、Wiki 复用与可沉淀结论"
    )
    foreach ($h in $requiredSections) {
        if ($report -notmatch [regex]::Escape($h)) {
            $errors.Add("03-industry-research.md missing section: $h")
        }
    }

    # ---------- 03 行业深研 ### 子节校验（从模板动态读取，禁止 Codex 跳过任何子节） ----------
    $templatePath = Join-Path $harnessRoot "templates\03-industry-research.md"
    $templateSubsections = @()
    $templateCanonicalKeys = @()
    if (Test-Path -LiteralPath $templatePath -PathType Leaf) {
        $templateContent = Get-Content -Raw -Encoding utf8 -LiteralPath $templatePath
        foreach ($line in ($templateContent -split "`r?`n")) {
            if ($line -match '^### \d+\.\d+\s') {
                $m = [regex]::Match($line, '^### (?<key>\d+\.\d+(?:\.\d+)?\s+.*?)\s*$')
                if ($m.Success) {
                    $key = $m.Groups['key'].Value.Trim()
                    $templateSubsections += $key
                    # 取"章节号 + 标题主干（截到第一个全角/半角括号之前）"作为规范键
                    # 例：模板 "2.2 需求逻辑推演（为什么会有这个市场）" 与老报告 "2.2 需求逻辑推演" 都归并为 "2.2 需求逻辑推演"
                    $canonical = ($key -split '[（(]')[0].Trim()
                    $templateCanonicalKeys += $canonical
                }
            }
        }
    }
    if ($templateSubsections.Count -gt 0) {
        $reportLines = $report -split "`r?`n"
        $reportSubsectionKeys = @()
        $reportCanonicalKeys = @()
        foreach ($line in $reportLines) {
            if ($line -match '^### \d+\.\d+') {
                $m = [regex]::Match($line, '^### (?<key>\d+\.\d+(?:\.\d+)?\s+.*?)\s*$')
                if ($m.Success) {
                    $k = $m.Groups['key'].Value.Trim()
                    $reportSubsectionKeys += $k
                    $reportCanonicalKeys += ($k -split '[（(]')[0].Trim()
                }
            }
        }
        foreach ($expected in $templateCanonicalKeys) {
            if (-not ($reportCanonicalKeys -contains $expected)) {
                # 报告里没找到这个子节
                $errors.Add("03-industry-research.md missing ### subsection from template: $expected")
            }
        }
        foreach ($actual in $reportSubsectionKeys) {
            $canonical = ($actual -split '[（(]')[0].Trim()
            if (-not ($templateCanonicalKeys -contains $canonical)) {
                # 报告里出现了不属于任何模板子节的 ### 子节
                $errors.Add("03-industry-research.md has ### subsection not in template (forbidden): $actual")
            }
        }
    }

    # ---------- 03 报告图片引用必须使用相对路径 ----------
    foreach ($m in [regex]::Matches($report, "!\[[^\]]*\]\(([^)]+)\)")) {
        $ref = $m.Groups[1].Value.Trim()
        if ($ref -match "\.(png|jpg|jpeg|gif|svg)$") {
            if ($ref -match '^(https?://|file://)') {
                continue
            }
            if ([System.IO.Path]::IsPathRooted($ref)) {
                $errors.Add("03-industry-research.md image uses absolute path (must be relative to .md file): $ref")
            }
        }
    }

    # ---------- 核心结论 one-liner 格式校验（章节名允许短匹配） ----------
    $conclusionBlock = [regex]::Match($report, "(?s)## 核心结论(.*?)## 1\. 行业概述").Groups[1].Value
    $chapterNames = @(
        @{ short = "行业概述"; full = "行业概述" },
        @{ short = "市场规模"; full = "市场规模与增速" },
        @{ short = "行业生命周期"; full = "行业生命周期与技术发展周期" },
        @{ short = "产业链"; full = "产业链与价值链" },
        @{ short = "客户需求"; full = "客户需求与购买行为" },
        @{ short = "新进入门槛"; full = "新进入门槛" },
        @{ short = "替代威胁"; full = "替代威胁" },
        @{ short = "竞争分析"; full = "竞争分析" },
        @{ short = "行业关键成功因素"; full = "行业关键成功因素分析" },
        @{ short = "行业风险"; full = "行业风险梳理" }
    )
    foreach ($entry in $chapterNames) {
        $short = [regex]::Escape($entry.short)
        $pattern = "-\s*\*\*[^*]*$short[^*]*\*\*："
        if ($conclusionBlock -notmatch $pattern) {
            $errors.Add("03-industry-research.md core conclusion missing one-liner for: $($entry.full) (use `- **$($entry.full)**：...` format)")
        }
    }
    if ($conclusionBlock -notmatch "-\s*\*\*整体判断\*\*：") {
        $errors.Add("03-industry-research.md core conclusion missing overall judgment line")
    }

    # ---------- 03 报告证据密度软告警（不阻断；AGENTS.md 未规定下限） ----------
    $evidenceIdCount = ([regex]::Matches($report, '(?<![A-Za-z0-9])E-\d+')).Count
    if ($evidenceIdCount -lt 10) {
        $warnings.Add("03-industry-research.md has only $evidenceIdCount E-xxx evidence IDs; the report may be under-sourced. Hard-tech and fresh-industry research typically needs 30+, but light-weight or fast-swizzle projects can legitimately be lower")
    }
}

# ---------- 项目分析产物检查 ----------
$assessmentPath = Join-Path $projectDir "outputs\project\01-project-assessment.md"
$elementMapPath = Join-Path $projectDir "outputs\project\01-project-element-map.md"
$hasAssessment = Test-Path -LiteralPath $assessmentPath -PathType Leaf
$hasElementMap = Test-Path -LiteralPath $elementMapPath -PathType Leaf
if ($hasAssessment -xor $hasElementMap) {
    $errors.Add("Project analysis outputs incomplete: need both 01-project-assessment.md and 01-project-element-map.md")
}
if ($hasAssessment) {
    $assessment = Get-Content -Raw -Encoding utf8 -LiteralPath $assessmentPath
    $assessmentSections = @(
        "## 核心结论",
        "## 1. 企业的产品和业务介绍",
        "## 2. 企业核心优势",
        "## 3. 企业核心风险"
    )
    foreach ($h in $assessmentSections) {
        if ($assessment -notmatch [regex]::Escape($h)) {
            $errors.Add("01-project-assessment.md missing section: $h")
        }
    }
}

# ---------- 复核文件项目范围自检（防止跨项目复核文件落入本项目） ----------
$otherIds = @()
$indexPath = Join-Path $harnessRoot "projects\INDEX.md"
if (Test-Path -LiteralPath $indexPath -PathType Leaf) {
    $indexText = Get-Content -Raw -Encoding utf8 -LiteralPath $indexPath
    foreach ($m in [regex]::Matches($indexText, "(?m)^\|\s*([a-z0-9_]+)\s*\|")) {
        $candidate = $m.Groups[1].Value
        if ($candidate -ne $ProjectId -and -not $otherIds.Contains($candidate)) {
            $otherIds += $candidate
        }
    }
}
$companyName = ""
$projectMetaPath = Join-Path $projectDir "PROJECT.md"
if (Test-Path -LiteralPath $projectMetaPath -PathType Leaf) {
    $pm = Get-Content -Raw -Encoding utf8 -LiteralPath $projectMetaPath
    if ($pm -match "(?m)^- 公司主体：\s*(.+?)\s*$") { $companyName = $Matches[1].Trim() }
}
$reviewDir = Join-Path $projectDir "reviews"
if (Test-Path -LiteralPath $reviewDir -PathType Container) {
    foreach ($rf in (Get-ChildItem -LiteralPath $reviewDir -Filter *.md -File)) {
        $rc = Get-Content -Raw -Encoding utf8 -LiteralPath $rf.FullName
        $crossHit = $otherIds | Where-Object { $rc -match [regex]::Escape($_) } | Select-Object -First 1
        if ($crossHit) {
            $errors.Add("$($rf.Name) references another project id '$crossHit'; cross-project review must not be filed under $ProjectId")
        } elseif ($rc -notmatch [regex]::Escape($ProjectId) -and
                  (-not $companyName -or $rc -notmatch [regex]::Escape($companyName))) {
            $warnings.Add("$($rf.Name) does not self-identify project ($ProjectId / $companyName); verify review scope manually")
        }
    }
}

# ---------- 尽调设计产物检查 ----------
$ddPath = Join-Path $projectDir "outputs\project\02-dd-checklist.md"
$ddInterviewPath = Join-Path $projectDir "outputs\project\02a-dd-interview-guides.md"
$ddCompetitorPath = Join-Path $projectDir "outputs\project\02b-dd-competitors.md"
$hasDd = Test-Path -LiteralPath $ddPath -PathType Leaf
$hasDdInterview = Test-Path -LiteralPath $ddInterviewPath -PathType Leaf
$hasDdCompetitor = Test-Path -LiteralPath $ddCompetitorPath -PathType Leaf
if ($hasDd -or $hasDdInterview -or $hasDdCompetitor) {
    if (-not ($hasDd -and $hasDdInterview -and $hasDdCompetitor)) {
        $errors.Add("Diligence design outputs incomplete: need 02-dd-checklist.md, 02a-dd-interview-guides.md, 02b-dd-competitors.md")
    }
}
if ($hasDd) {
    $dd = Get-Content -Raw -Encoding utf8 -LiteralPath $ddPath
    foreach ($h in @("## 核心结论", "## 1. 尽调策略", "## 2. 材料与数据请求", "## 3. 管理层尽调安排（概要）", "## 4. 竞争对手尽调说明（概要）")) {
        if ($dd -notmatch [regex]::Escape($h)) {
            $errors.Add("02-dd-checklist.md missing section: $h")
        }
    }
}
if ($hasDdInterview) {
    $di = Get-Content -Raw -Encoding utf8 -LiteralPath $ddInterviewPath
    foreach ($h in @("## 1. 尽调安排说明（为什么这样安排）", "## 2. 分人问题清单", "## 3. 访谈覆盖矩阵", "## 4. 访谈记录格式（访谈后回写）")) {
        if ($di -notmatch [regex]::Escape($h)) {
            $errors.Add("02a-dd-interview-guides.md missing section: $h")
        }
    }
}
if ($hasDdCompetitor) {
    $dc = Get-Content -Raw -Encoding utf8 -LiteralPath $ddCompetitorPath
    foreach ($h in @("## 1. 优先尽调的三家与理由", "## 2. 共性信息（每家都需确认）", "## 3. 差异化重点", "## 5. 降级策略（现实约束）")) {
        if ($dc -notmatch [regex]::Escape($h)) {
            $errors.Add("02b-dd-competitors.md missing section: $h")
        }
    }
}

# ---------- 访谈覆盖矩阵检查（P0/P1 缺口必须有对象或材料覆盖） ----------
if ($hasDd -and $hasDdInterview) {
    $checklistText = Get-Content -Raw -Encoding utf8 -LiteralPath $ddPath
    $interviewText = Get-Content -Raw -Encoding utf8 -LiteralPath $ddInterviewPath
    $p0p1Questions = @{}
    foreach ($line in ($checklistText -split "`r?`n")) {
        if ($line -match "^\|\s*DD-\d+\s*\|\s*(P0|P1)\s*\|") {
            foreach ($m in [regex]::Matches($line, "Q-\d+")) {
                $p0p1Questions[$m.Value] = $true
            }
        }
    }
    $coveredQuestions = @{}
    $inCoverage = $false
    foreach ($line in ($interviewText -split "`r?`n")) {
        if ($line -match "^## 3\. 访谈覆盖矩阵") { $inCoverage = $true; continue }
        if ($inCoverage -and $line -match "^## ") { $inCoverage = $false }
        if ($inCoverage -and $line -match "^\|\s*Q-") {
            foreach ($m in [regex]::Matches($line, "Q-\d+")) {
                $coveredQuestions[$m.Value] = $true
            }
        }
    }
    foreach ($q in $p0p1Questions.Keys) {
        if (-not $coveredQuestions.ContainsKey($q)) {
            $errors.Add("Interview coverage matrix in 02a misses P0/P1 gap $q from 02-dd-checklist.md")
        }
    }
}

# ---------- 汇总 ----------
if ($warnings.Count -gt 0) {
    Write-Host "Warnings:" -ForegroundColor Yellow
    foreach ($w in $warnings) { Write-Host "  - $w" -ForegroundColor Yellow }
}
if ($errors.Count -gt 0) {
    Write-Host "Evidence validation failed for ${ProjectId}:" -ForegroundColor Red
    foreach ($item in $errors) {
        Write-Host "  - $item" -ForegroundColor Red
    }
    exit 1
}

Write-Host "Evidence validation passed for ${ProjectId}." -ForegroundColor Green
Write-Host "E: $($eDefined.Count) | Q: $($qDefined.Count) | C: $($cDefined.Count) | SRC: $($srcDefined.Count)"
Write-Host "Scanned markdown files: $($scanFiles.Count)"
