from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--width", type=int, default=3840)
    parser.add_argument("--height", type=int, default=2400)
    args = parser.parse_args()

    source = Image.open(args.source).convert("RGB")
    target_ratio = args.width / args.height
    source_ratio = source.width / source.height

    if source_ratio > target_ratio:
        canvas_width = source.width
        canvas_height = round(source.width / target_ratio)
    else:
        canvas_height = source.height
        canvas_width = round(source.height * target_ratio)

    canvas = Image.new("RGB", (canvas_width, canvas_height), "white")
    canvas.paste(source, ((canvas_width - source.width) // 2, (canvas_height - source.height) // 2))
    normalized = canvas.resize((args.width, args.height), Image.Resampling.LANCZOS)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    normalized.save(args.output, format="PNG", optimize=True)
    print(f"{args.output}: {normalized.width} x {normalized.height}")


if __name__ == "__main__":
    main()
