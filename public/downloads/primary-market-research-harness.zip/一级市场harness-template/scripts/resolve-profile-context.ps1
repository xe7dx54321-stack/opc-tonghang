param([string]$ProfileId)

$ErrorActionPreference = "Stop"
$harnessRoot = Split-Path -Parent $PSScriptRoot
$profilesRoot = Join-Path $harnessRoot "profiles"
$selected = if ([string]::IsNullOrWhiteSpace($ProfileId)) { "default" } else { $ProfileId.Trim() }

if ($selected -notmatch '^[a-z0-9][a-z0-9-]{0,63}$') {
    Write-Error "Invalid profile id: $selected"
    exit 2
}

$indexPath = Join-Path $profilesRoot "INDEX.md"
$index = Get-Content -Raw -Encoding utf8 -LiteralPath $indexPath
if ($index -notmatch [regex]::Escape("| $selected |")) {
    Write-Error "Profile not found in INDEX: $selected"
    exit 3
}

$profilePath = Join-Path $profilesRoot $selected
if (-not (Test-Path -LiteralPath $profilePath -PathType Container)) {
    Write-Error "Profile directory missing: $selected"
    exit 4
}

[pscustomobject]@{
    profile_id = $selected
    mode = if ($ProfileId) { "explicit" } else { "default" }
    profile_path = (Resolve-Path -LiteralPath $profilePath).Path
    allowed_files = @("PROFILE.md", "methodology.md", "feedback-log.md", "overrides/<selected-skill>.md")
} | ConvertTo-Json -Depth 3
