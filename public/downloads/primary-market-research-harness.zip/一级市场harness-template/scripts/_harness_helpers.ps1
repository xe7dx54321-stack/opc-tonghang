<#
Harness cross-platform PowerShell helpers.

The validation scripts under scripts/ and scripts/tests/ were originally written
for Windows PowerShell 5.1. To make them work on macOS (and stay working on
Windows) we use this helper module:

  - Resolve the right PowerShell executable (`pwsh` on macOS/Linux,
    `powershell` on Windows). The Mac-only `pwsh` invocation is required
    because macOS has no Windows PowerShell binary.
  - Provide a `Invoke-HarnessScript` wrapper that replaces the inline
    `& powershell -NoProfile -ExecutionPolicy Bypass -File ...` pattern with a
    portable call that works on both platforms. The `-ExecutionPolicy Bypass`
    flag is dropped on non-Windows because PowerShell 7 ignores it there.

Other scripts dot-source this file via:

  . (Join-Path $PSScriptRoot '_harness_helpers.ps1')

so all validation flows (validate-harness, validate-all, validate-evolution,
sync-runtime-skills, tests) can pick the right executable transparently.
#>

if (Test-Path -LiteralPath variable:Preference) { Remove-Variable Preference -ErrorAction SilentlyContinue }
$ErrorActionPreference = 'Stop'

function Get-HarnessPowerShellExecutable {
    <#
    .SYNOPSIS
        Pick the PowerShell executable that should be used to invoke sibling
        scripts on the current host.

    .DESCRIPTION
        On Windows the harness keeps using `powershell` so users who only have
        Windows PowerShell 5.1 (no PowerShell 7) still work. On macOS and Linux
        we require `pwsh` (PowerShell 7) because there is no native
        `powershell.exe`. If neither is found a clear error is thrown so the
        caller can install PowerShell 7 instead of failing later with a
        confusing path error.
    #>
    if ($IsWindows -or $env:OS -eq 'Windows_NT') {
        if (Get-Command -Name 'powershell' -ErrorAction SilentlyContinue) {
            return 'powershell'
        }
        if (Get-Command -Name 'pwsh' -ErrorAction SilentlyContinue) {
            return 'pwsh'
        }
        throw 'No PowerShell executable found on PATH (looked for powershell and pwsh).'
    }

    # macOS / Linux host. Prefer pwsh because there is no powershell here.
    if (Get-Command -Name 'pwsh' -ErrorAction SilentlyContinue) {
        return 'pwsh'
    }
    if (Get-Command -Name 'powershell' -ErrorAction SilentlyContinue) {
        return 'powershell'
    }
    throw @(
        'PowerShell 7 (pwsh) is required on this host but was not found.',
        'Install it with: brew install --cask powershell  (macOS)',
        '                or: https://aka.ms/install-powershell'
    ) -join [Environment]::NewLine
}

function Invoke-HarnessScript {
    <#
    .SYNOPSIS
        Invoke another harness validation script using the platform-appropriate
        PowerShell binary.

    .PARAMETER File
        Path (absolute or relative to the calling script) of the .ps1 to run.

    .PARAMETER Arguments
        Optional list of arguments to forward to the script.

    .OUTPUTS
        Whatever the child script writes to its output streams; this wrapper
        does not capture output.

    .EXAMPLE
        Invoke-HarnessScript -File (Join-Path $PSScriptRoot 'validate-harness.ps1')
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$File,

        [Parameter(ValueFromRemainingArguments = $true)]
        [string[]]$Arguments
    )

    $resolved = (Resolve-Path -LiteralPath $File).Path
    $exe = Get-HarnessPowerShellExecutable

    $common = @('-NoProfile', '-File', $resolved)
    if ($Arguments) {
        $common += $Arguments
    }

    # -ExecutionPolicy Bypass is Windows-only; on PowerShell 7 it is silently
    # ignored but harmless. We only add it on Windows hosts to avoid confusion
    # when users read the command in their terminal history.
    if ($IsWindows -or $env:OS -eq 'Windows_NT') {
        & $exe -NoProfile -ExecutionPolicy Bypass -File $resolved @Arguments
    } else {
        & $exe -NoProfile -File $resolved @Arguments
    }
}

function Test-HarnessIsMacOS {
    <#
    .SYNOPSIS
        Return $true when the current host is macOS.
    #>
    return ($IsMacOS -or $IsOSX -or [System.Runtime.InteropServices.RuntimeInformation]::IsOSPlatform([System.Runtime.InteropServices.OSPlatform]::OSX))
}

function Get-HarnessRepoRoot {
    <#
    .SYNOPSIS
        Walk up from the calling script until we find AGENTS.md, which marks
        the harness repository root. Falls back to Split-Path -Parent
        $PSScriptRoot so legacy invocations (e.g. when sourced outside a
        normal session) still work.
    #>
    param(
        [string]$Start = $PSScriptRoot
    )

    if (-not $Start) { return $null }

    $cursor = (Resolve-Path -LiteralPath $Start -ErrorAction SilentlyContinue).Path
    while ($cursor) {
        if (Test-Path -LiteralPath (Join-Path $cursor 'AGENTS.md') -PathType Leaf) {
            return $cursor
        }
        $parent = Split-Path -Parent $cursor
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }

    return (Split-Path -Parent $Start)
}

# Stop pollute the host's verbose preference when sourced.
# $PSCmdlet is null when dot-sourced from another script, so use the host's
# preference variable directly instead of trying to read through $PSCmdlet.
if (-not $PSBoundParameters.ContainsKey('VerbosePreference')) {
    # No-op: keeps the existing $VerbosePreference from the calling scope.
}
