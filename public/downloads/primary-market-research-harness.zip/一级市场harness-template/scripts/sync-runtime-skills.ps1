param(
    [switch]$Apply,
    [string]$RestoreFrom,
    [switch]$ConfirmNoActiveHarnessSession
)

$ErrorActionPreference = "Stop"
$harnessRoot = Split-Path -Parent $PSScriptRoot
$sourceRoot = Join-Path $harnessRoot "evolution\runtime-skill-source"
$runtimeRoot = Join-Path $harnessRoot ".agents\skills"

# Cross-platform: pick pwsh on macOS/Linux when invoking sibling scripts.
. (Join-Path $PSScriptRoot '_harness_helpers.ps1')
$backupRoot = Join-Path $harnessRoot "evolution\backups"
$skillNames = @("harness-evolution", "final-investment-decision", "investment-memo", "investment-verdict", "material-analysis", "project-decision-card", "project-pool-selection", "chat-knowledge-ingestion")

if ($RestoreFrom) {
    if (-not $ConfirmNoActiveHarnessSession) { throw "Restoring requires -ConfirmNoActiveHarnessSession" }
    $resolvedBackup = (Resolve-Path -LiteralPath $RestoreFrom).Path
    if (-not $resolvedBackup.StartsWith((Resolve-Path -LiteralPath $backupRoot).Path, [StringComparison]::OrdinalIgnoreCase)) { throw "Backup must be under evolution/backups" }
    foreach ($name in Get-ChildItem -LiteralPath $resolvedBackup -Directory | Select-Object -ExpandProperty Name) {
        $target = Join-Path $runtimeRoot $name
        New-Item -ItemType Directory -Force -Path (Join-Path $target "agents") | Out-Null
        Copy-Item -LiteralPath (Join-Path $resolvedBackup "$name\SKILL.md") -Destination (Join-Path $target "SKILL.md") -Force
        Copy-Item -LiteralPath (Join-Path $resolvedBackup "$name\agents\openai.yaml") -Destination (Join-Path $target "agents\openai.yaml") -Force
    }
    Write-Host "Runtime Skills restored from $resolvedBackup" -ForegroundColor Green
    exit 0
}

Invoke-HarnessScript -File (Join-Path $PSScriptRoot "validate-evolution.ps1")
if ($LASTEXITCODE -ne 0) { throw "Evolution source validation failed" }

if (-not $Apply) {
    Write-Host "Check only. To publish outside an active Harness session:" -ForegroundColor Yellow
    $exe = Get-HarnessPowerShellExecutable
    Write-Host "  $exe -NoProfile -File ./scripts/sync-runtime-skills.ps1 -Apply -ConfirmNoActiveHarnessSession"
    exit 0
}

if (-not $ConfirmNoActiveHarnessSession) { throw "Publishing requires -ConfirmNoActiveHarnessSession" }

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $backupRoot $stamp
New-Item -ItemType Directory -Force -Path $backup | Out-Null

foreach ($name in $skillNames) {
    $source = Join-Path $sourceRoot $name
    $target = Join-Path $runtimeRoot $name
    if (Test-Path -LiteralPath $target) {
        New-Item -ItemType Directory -Force -Path (Join-Path $backup "$name\agents") | Out-Null
        foreach ($relative in @("SKILL.md", "agents\openai.yaml")) {
            $old = Join-Path $target $relative
            if (Test-Path -LiteralPath $old) { Copy-Item -LiteralPath $old -Destination (Join-Path (Join-Path $backup $name) $relative) -Force }
        }
    }
    New-Item -ItemType Directory -Force -Path (Join-Path $target "agents") | Out-Null
    Copy-Item -LiteralPath (Join-Path $source "SKILL.md") -Destination (Join-Path $target "SKILL.md") -Force
    Copy-Item -LiteralPath (Join-Path $source "agents\openai.yaml") -Destination (Join-Path $target "agents\openai.yaml") -Force
}

Invoke-HarnessScript -File (Join-Path $PSScriptRoot "validate-evolution.ps1") -Arguments @("-RequireRuntimeSync")
if ($LASTEXITCODE -ne 0) { throw "Runtime sync verification failed; restore from $backup" }

Write-Host "Runtime Skills published. Backup: $backup" -ForegroundColor Green
Write-Host "Open a new Codex session before using the updated Skills." -ForegroundColor Green
