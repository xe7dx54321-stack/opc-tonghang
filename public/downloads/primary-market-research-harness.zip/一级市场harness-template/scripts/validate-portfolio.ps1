param([string]$PortfolioRoot)

$ErrorActionPreference = "Stop"
$harnessRoot = Split-Path -Parent $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($PortfolioRoot)) { $PortfolioRoot = Join-Path $harnessRoot "portfolio" }
$errors = [System.Collections.Generic.List[string]]::new()
$fullColon = [char]0xFF1A

if (-not (Test-Path -LiteralPath $PortfolioRoot -PathType Container)) {
    Write-Host "Portfolio validation failed:" -ForegroundColor Red
    Write-Host "  - Missing portfolio root: $PortfolioRoot" -ForegroundColor Red
    exit 1
}

$indexPath = Join-Path $PortfolioRoot "INDEX.md"
$cardsRoot = Join-Path $PortfolioRoot "cards"
$runsRoot = Join-Path $PortfolioRoot "runs"
foreach ($path in @($indexPath, $cardsRoot, $runsRoot)) {
    if (-not (Test-Path -LiteralPath $path)) { $errors.Add("Missing portfolio path: $path") }
}

$templatePath = Join-Path $harnessRoot "templates\project-decision-card.md"
$briefTemplatePath = Join-Path $harnessRoot "templates\portfolio-decision-brief.md"
$requiredHeadings = @()
if (Test-Path -LiteralPath $templatePath) {
    $requiredHeadings = @(Get-Content -Encoding utf8 -LiteralPath $templatePath | Where-Object { $_ -match '^## [^#]' })
    if ($requiredHeadings.Count -ne 9) { $errors.Add("Project decision card template must contain exactly 9 H2 sections") }
} else {
    $errors.Add("Missing project decision card template")
}

if (Test-Path -LiteralPath $briefTemplatePath) {
    $briefTemplate = Get-Content -Raw -Encoding utf8 -LiteralPath $briefTemplatePath
    $standardPattern = '(?m)^- budget_mode' + [regex]::Escape($fullColon) + '`standard`\s*$'
    if ($briefTemplate -notmatch $standardPattern) { $errors.Add("Portfolio decision brief must default budget_mode to standard") }
} else {
    $errors.Add("Missing portfolio decision brief template")
}

$index = if (Test-Path -LiteralPath $indexPath) { Get-Content -Raw -Encoding utf8 -LiteralPath $indexPath } else { "" }
$seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
$cardCount = 0

if (Test-Path -LiteralPath $cardsRoot) {
    foreach ($cardFile in Get-ChildItem -LiteralPath $cardsRoot -File -Filter "*.md" | Where-Object { $_.Name -notmatch '^\.' }) {
        $cardCount++
        $body = Get-Content -Raw -Encoding utf8 -LiteralPath $cardFile.FullName
        $idPattern = '(?m)^- project_id' + [regex]::Escape($fullColon) + '`(?<id>[a-z0-9][a-z0-9-]{0,63})`\s*$'
        $idMatch = [regex]::Match($body, $idPattern)
        if (-not $idMatch.Success) {
            $errors.Add("Card missing valid project_id: $($cardFile.Name)")
            continue
        }
        $id = $idMatch.Groups['id'].Value
        if (-not $seen.Add($id)) { $errors.Add("Duplicate portfolio card project_id: $id") }
        if ($cardFile.BaseName -ne $id) { $errors.Add("Card filename must match project_id: $($cardFile.Name) vs $id") }
        if ($index -notmatch [regex]::Escape("| $id |")) { $errors.Add("Card missing from portfolio/INDEX.md: $id") }

        $metadataPatterns = @(
            ('(?m)^- as_of[^\r\n`]*' + [regex]::Escape($fullColon) + '`\d{4}-\d{2}-\d{2}`\s*$'),
            ('(?m)^- source_project_updated_at' + [regex]::Escape($fullColon) + '`\d{4}-\d{2}-\d{2}`\s*$'),
            ('(?m)^- profile_scope' + [regex]::Escape($fullColon) + '`neutral`\s*$'),
            ('(?m)^- card_status' + [regex]::Escape($fullColon) + '`(active|stale)`\s*$')
        )
        foreach ($pattern in $metadataPatterns) {
            if ($body -notmatch $pattern) { $errors.Add("Card $id missing or invalid required metadata") }
        }
        foreach ($heading in $requiredHeadings) {
            if ($body -notmatch [regex]::Escape($heading)) { $errors.Add("Card $id missing section: $heading") }
        }
    }
}

if ($errors.Count -gt 0) {
    Write-Host "Portfolio validation failed:" -ForegroundColor Red
    $errors | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
    exit 1
}

Write-Host "Portfolio validation passed. Cards: $cardCount" -ForegroundColor Green
