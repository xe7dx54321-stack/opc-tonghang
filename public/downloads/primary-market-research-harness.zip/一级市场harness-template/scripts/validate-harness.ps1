$ErrorActionPreference = "Stop"

# Cross-platform: pick pwsh on macOS/Linux, powershell on Windows, when
# invoking sibling scripts via Invoke-HarnessScript.
. (Join-Path $PSScriptRoot '_harness_helpers.ps1')

$harnessRoot = Split-Path -Parent $PSScriptRoot
$errors = [System.Collections.Generic.List[string]]::new()
$expectedSkills = @(
    "project-setup",
    "bp-segment-screen",
    "industry-wiki",
    "industry-opportunity-screen",
    "industry-project-research",
    "diligence-design",
    "material-analysis",
    "investment-verdict",
    "final-investment-decision",
    "investment-memo",
    "harness-evolution",
    "project-decision-card",
    "project-pool-selection",
    "chat-knowledge-ingestion",
    "evidence-review"
)

$requiredFiles = @(
    "AGENTS.md",
    "WORKFLOW.md",
    "EVOLUTION.md",
    "README.md",
    "scripts/resolve-project-context.ps1",
    "scripts/resolve-profile-context.ps1",
    "scripts/check-wiki-freshness.ps1",
    "scripts/validate-evidence.ps1",
    "scripts/validate-workbook.ps1",
    "scripts/validate-final-conclusion.ps1",
    "scripts/validate-profiles.ps1",
    "scripts/validate-evolution.ps1",
    "scripts/validate-portfolio.ps1",
    "scripts/sync-runtime-skills.ps1",
    "scripts/validate-all.ps1",
    "scripts/tests/test-resolve-project-context.ps1",
    "scripts/tests/test-resolve-profile-context.ps1",
    "scripts/tests/test-portfolio-validation.ps1",
    "scripts/tests/test-chat-knowledge-ingestion.ps1",
    "projects/INDEX.md",
    "portfolio/INDEX.md",
    "wiki/INDEX.md",
    "knowledge-inbox/INDEX.md",
    "profiles/INDEX.md",
    ".codex/config.toml",
    ".codex/agents/research-worker.toml",
    ".codex/agents/investment-reviewer.toml",
    ".codex/agents/portfolio-reviewer.toml",
    "references/research-framework.md",
    "references/segment-screening-framework.md",
    "references/segment-priority-framework.md",
    "references/evidence-standard.md",
    "references/investment-rubric.md",
    "references/portfolio-selection-framework.md",
    "templates/PROJECT.md",
    "templates/input-manifest.md",
    "templates/wiki-topic.md",
    "templates/wiki-update.md",
    "templates/chat-knowledge-intake.md",
    "templates/01-segment-map.md",
    "templates/01-screening-conclusion.md",
    "templates/02-segment-priority.md",
    "templates/02-segment-priority.xlsx",
    "templates/03-industry-research.md",
    "templates/01-project-assessment.md",
    "templates/03-dd-checklist.md",
    "templates/03a-dd-interview-guides.md",
    "templates/03b-dd-competitors.md",
    "templates/04-material-update.md",
    "templates/05-verdict.md",
    "templates/06-final-decision.md",
    "templates/06-investment-memo.md",
    "templates/07-industry-research-final.md",
    "templates/user-profile.md",
    "templates/methodology-override.md",
    "templates/evolution-proposal.md",
    "templates/project-decision-card.md",
    "templates/portfolio-decision-brief.md",
    "templates/portfolio-selection-report.md",
    "templates/evidence-matrix.md",
    "templates/source-index.md"
)

foreach ($relativePath in $requiredFiles) {
    $fullPath = Join-Path $harnessRoot $relativePath
    if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
        $errors.Add("Missing required file: $relativePath")
    }
}

foreach ($skillName in $expectedSkills) {
    $skillDir = Join-Path $harnessRoot ".agents\skills\$skillName"
    $skillFile = Join-Path $skillDir "SKILL.md"
    $metadataFile = Join-Path $skillDir "agents\openai.yaml"

    if (-not (Test-Path -LiteralPath $skillFile -PathType Leaf)) {
        $errors.Add("Missing SKILL.md: $skillName")
        continue
    }
    if (-not (Test-Path -LiteralPath $metadataFile -PathType Leaf)) {
        $errors.Add("Missing agents/openai.yaml: $skillName")
        continue
    }

    $content = Get-Content -Raw -Encoding utf8 -LiteralPath $skillFile
    $frontmatter = [regex]::Match(
        $content,
        "\A---\r?\n(?<body>.*?)\r?\n---",
        [System.Text.RegularExpressions.RegexOptions]::Singleline
    )
    if (-not $frontmatter.Success) {
        $errors.Add("Invalid frontmatter block: $skillName")
        continue
    }

    $frontmatterBody = $frontmatter.Groups["body"].Value
    $nameMatch = [regex]::Match($frontmatterBody, "(?m)^name:\s*(?<name>[a-z0-9-]+)\s*$")
    $descriptionMatch = [regex]::Match($frontmatterBody, "(?m)^description:\s*(?<description>.+)\s*$")

    if (-not $nameMatch.Success -or $nameMatch.Groups["name"].Value -ne $skillName) {
        $errors.Add("Skill name mismatch: $skillName")
    }
    if (-not $descriptionMatch.Success) {
        $errors.Add("Missing description: $skillName")
    } elseif ($descriptionMatch.Groups["description"].Value.Length -gt 1024) {
        $errors.Add("Description exceeds 1024 characters: $skillName")
    }
    if ($content -match "\[TODO|TODO:") {
        $errors.Add("Unresolved TODO in SKILL.md: $skillName")
    }

    $metadata = Get-Content -Raw -Encoding utf8 -LiteralPath $metadataFile
    if ($metadata -notmatch "(?m)^\s*display_name:\s*`".+`"\s*$") {
        $errors.Add("Missing display_name in openai.yaml: $skillName")
    }
    $shortDescription = [regex]::Match(
        $metadata,
        "(?m)^\s*short_description:\s*`"(?<value>.+)`"\s*$"
    )
    if (-not $shortDescription.Success) {
        $errors.Add("Missing short_description in openai.yaml: $skillName")
    } elseif (
        $shortDescription.Groups["value"].Value.Length -lt 25 -or
        $shortDescription.Groups["value"].Value.Length -gt 64
    ) {
        $errors.Add("short_description must be 25-64 characters: $skillName")
    }
    $escapedSkillName = [regex]::Escape("`$$skillName")
    if ($metadata -notmatch $escapedSkillName) {
        $errors.Add("default_prompt must mention `$$($skillName): $($skillName)")
    }
}

foreach ($agentName in @("research-worker", "investment-reviewer", "portfolio-reviewer")) {
    $agentFile = Join-Path $harnessRoot ".codex\agents\$agentName.toml"
    if (-not (Test-Path -LiteralPath $agentFile -PathType Leaf)) {
        continue
    }
    $agent = Get-Content -Raw -Encoding utf8 -LiteralPath $agentFile
    foreach ($field in @("name", "description", "developer_instructions")) {
        if ($agent -notmatch "(?m)^$field\s*=") {
            $errors.Add("Agent $agentName missing top-level field: $field")
        }
    }
    if ($agent -match "(?m)^\[(agent|system_prompt|memory|skills)\]") {
        $errors.Add("Agent $agentName uses unsupported legacy sections")
    }
}

Invoke-HarnessScript -File (Join-Path $PSScriptRoot "validate-portfolio.ps1")
if ($LASTEXITCODE -ne 0) { $errors.Add("Portfolio validation failed") }

$projectRoot = Join-Path $harnessRoot "projects"
$projectIndex = Get-Content -Raw -Encoding utf8 -LiteralPath (Join-Path $projectRoot "INDEX.md")
foreach ($projectDir in Get-ChildItem -LiteralPath $projectRoot -Directory) {
    $projectId = $projectDir.Name
    foreach ($relativePath in @(
        "PROJECT.md",
        "inputs\manifest.md",
        "inputs\bp",
        "inputs\interviews",
        "inputs\research",
        "inputs\financial",
        "inputs\commercial",
        "inputs\technical",
        "inputs\legal-ip",
        "inputs\other",
        "outputs\industry",
        "outputs\project",
        "outputs\investment",
        "evidence\source-index.md",
        "evidence\evidence-matrix.md",
        "reviews",
        "notes"
    )) {
        $fullPath = Join-Path $projectDir.FullName $relativePath
        if (-not (Test-Path -LiteralPath $fullPath)) {
            $errors.Add("Project $projectId missing isolated path: $relativePath")
        }
    }
    if (Test-Path -LiteralPath (Join-Path $projectDir.FullName "inputs\materials")) {
        $errors.Add("Project $projectId still uses legacy mixed input path: inputs\materials")
    }
    if ($projectIndex -notmatch [regex]::Escape("| $projectId |")) {
        $errors.Add("Project missing from projects/INDEX.md: $projectId")
    }

    # Primary industry Wiki topic_id must be a concrete identifier; the legacy
    # "待建立" / "none" / empty placeholder breaks Codex's industry match on
    # next session and forces a redundant segment screening run.
    $indexPattern = '^\|\s*' + [regex]::Escape($projectId) + '\s*\|'
    $indexLine = @($projectIndex -split "`r?`n" | Where-Object { $_ -match $indexPattern }) | Select-Object -First 1
    if ($indexLine) {
        $cells = $indexLine.Trim('|').Split('|') | ForEach-Object { $_.Trim() }
        if ($cells.Count -lt 5) {
            $errors.Add("Project $projectId INDEX row is malformed (need at least 5 columns including Primary industry Wiki)")
        } else {
            $primaryWiki = $cells[4]
            $placeholderPattern = '^(待建立|待建立（.*|none|无|未知|N/?A|n/a|\s*)$'
            if ($primaryWiki -match $placeholderPattern) {
                $errors.Add("Project $projectId has empty Primary industry Wiki; AGENTS.md requires a concrete topic_id once 行业定位确认 is done")
            } elseif ($primaryWiki -notmatch '^[a-z0-9][a-z0-9-]{0,63}$') {
                $errors.Add("Project $projectId Primary industry Wiki '$primaryWiki' is not a valid kebab-case topic_id")
            }
        }
    }
}

$wikiRoot = Join-Path $harnessRoot "wiki"
$wikiIndex = Get-Content -Raw -Encoding utf8 -LiteralPath (Join-Path $wikiRoot "INDEX.md")
foreach ($topicDir in Get-ChildItem -LiteralPath $wikiRoot -Directory) {
    $topicId = $topicDir.Name
    foreach ($relativePath in @("TOPIC.md", "taxonomy.md", "conclusions.md", "claims.md", "source-index.md", "updates")) {
        if (-not (Test-Path -LiteralPath (Join-Path $topicDir.FullName $relativePath))) {
            $errors.Add("Wiki topic $topicId missing: $relativePath")
        }
    }
    $topicFile = Join-Path $topicDir.FullName "TOPIC.md"
    if (Test-Path -LiteralPath $topicFile -PathType Leaf) {
        $topic = Get-Content -Raw -Encoding utf8 -LiteralPath $topicFile
        foreach ($field in @("industry_id", "topic_kind", "last_verified_at", "freshness_days", "next_review_due", "status", "source_verification")) {
            $metadataPattern = "(?m)^- " + [regex]::Escape($field) + "[^\r\n]+$"
            if ($topic -notmatch $metadataPattern) {
                $errors.Add("Wiki topic $topicId missing metadata: $field")
            }
        }
    }
    if (Test-Path -LiteralPath $topicFile -PathType Leaf) {
        $topic = Get-Content -Raw -Encoding utf8 -LiteralPath $topicFile
        if ($topic -match "(?m)^- topic_kind[^\r\n]*technology-landscape") {
            foreach ($relativePath in @("theses.md", "technology-map.md")) {
                if (-not (Test-Path -LiteralPath (Join-Path $topicDir.FullName $relativePath) -PathType Leaf)) {
                    $errors.Add("Technology landscape $topicId missing: $relativePath")
                }
            }
        }
    }
    if ($wikiIndex -notmatch [regex]::Escape("| $topicId |")) {
        $errors.Add("Wiki topic missing from wiki/INDEX.md: $topicId")
    }
}

if ($errors.Count -gt 0) {
    Write-Host "Harness validation failed:" -ForegroundColor Red
    foreach ($item in $errors) {
        Write-Host "  - $item" -ForegroundColor Red
    }
    exit 1
}

Write-Host "Harness validation passed." -ForegroundColor Green
Write-Host "Skills: $($expectedSkills.Count)"
Write-Host "Custom agents: 3"
Write-Host "Required files: $($requiredFiles.Count)"
Write-Host "Projects: $((Get-ChildItem -LiteralPath $projectRoot -Directory).Count)"
Write-Host "Wiki topics: $((Get-ChildItem -LiteralPath $wikiRoot -Directory).Count)"
