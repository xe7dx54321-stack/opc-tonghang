# Knowledge Inbox

这里保存聊天、会议或其他二次研究材料的提炼记录，不直接充当项目证据。只有完成去项目化、Scope校验和必要的公开来源复核后，内容才进入 `wiki/`。

| 来源ID | 标题 | 类型 | 提炼日期 | 状态 | Promotion |
|---|---|---|---|---|---|
| 6a9fb35a-00dc-83ea-8042-73c0c35c1a3a | 梳理大模型前沿论文 | ChatGPT会话 | 2026-09-21 | 已提炼；外部来源部分待复核 | `wiki/frontier-ai-technology-landscape/` |
| research-materials-2026-09-21-semiconductor-optics | 华为AI算力产业链与光互联研究材料 | PDF/DOCX研究材料 | 2026-09-21 | 已去项目化提炼；外部原始来源待定向补充 | `wiki/china-autonomous-ai-compute-stack/`、`wiki/ai-cluster-optical-interconnect/` |
| 6aa4be88-04c8-83ea-a78b-b1d4a99ec985 | DeepSeek华为产业链图谱 | ChatGPT会话 | 2026-09-21 | 已完成差异提炼；至少6条超长回复局部截断，外部事实待复核 | `wiki/china-autonomous-ai-compute-stack/`、`wiki/ai-cluster-optical-interconnect/`、`wiki/frontier-ai-technology-landscape/` |
