# Harness 配置说明（外发版）

> 本文件面向第一次使用本 Harness 的用户。**所有依赖和路径假设都已经按外发版目录结构写好**，按下面 4 步逐项执行即可，无需阅读 `AGENTS.md` / `WORKFLOW.md` 之外的任何文件。
>
> 如果你正在用 AI agent（Codex CLI / Claude Code / 其他），只需要把整份 `SETUP.md` 一次性交给它，并说一句：
>
> > **"请按本目录 `SETUP.md` 的全部要求完成配置，然后用 `pwsh -NoProfile -File ./scripts/validate-harness.ps1` 跑一次确认。"**
>
> Agent 会自动按本说明执行并回报。如果你是人工配置，直接按下面 4 节顺序执行即可。

---

## 0. 适用平台

| 平台 | 状态 |
| --- | --- |
| macOS（Apple Silicon 或 Intel） | ✅ 全功能验证 |
| Windows 10/11 | ✅ 全功能验证 |
| Linux | ⚠️ 未验证，但所有脚本都用 `pwsh` + `python3` 跨平台 |

下面命令对 macOS / Linux 给出 zsh / bash 写法；Windows 用户把 `pwsh` 换成 `powershell`，把 `python3` 换成 `py` 即可。

---

## 1. 安装 PowerShell 7（30 秒）

本 Harness 的所有验证脚本（`scripts/*.ps1`）都用 PowerShell。Windows 自带 Windows PowerShell 5.1 可以直接用，但 macOS / Linux 必须装 PowerShell 7（`pwsh`）。

### macOS

```bash
# 安装 Homebrew（如果还没装）
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# 通过 Homebrew 安装 PowerShell 7
brew install --cask powershell
```

### Windows 10/11

直接用 Windows 自带的 PowerShell 5.1 即可，不必安装 PowerShell 7。如果想用 7：

```powershell
winget install Microsoft.PowerShell
```

### Linux (Ubuntu/Debian)

```bash
# 参考 https://aka.ms/install-powershell
sudo apt update
sudo apt install -y wget
wget -q https://packages.microsoft.com/config/ubuntu/22.04/packages-microsoft-prod.deb
sudo dpkg -i packages-microsoft-prod.deb
sudo apt update
sudo apt install -y powershell
```

### 验证

```bash
pwsh --version   # macOS / Linux
# 期望输出：PowerShell 7.4.x 或更新版本
```

```powershell
powershell -NoProfile -Command '$PSVersionTable.PSVersion'   # Windows（用 5.1 时这条也行）
# 期望输出：Major >= 5（Windows PowerShell）或 Major >= 7（PowerShell 7）
```

如果 `pwsh` 命令找不到，Mac 上通常是 Homebrew 没把 `/opt/homebrew/bin` 加到 PATH，重开终端或执行 `eval "$(/opt/homebrew/bin/brew shellenv)"` 一次。

---

## 2. 安装 Python 依赖（1 分钟）

Harness 用 Python 3 写图表、Word 报告和图片处理。三个依赖：`python-docx`（Word 生成）、`Pillow`（图表字体和图片处理）、`openpyxl`（Excel 工作簿）。

```bash
python3 -m pip install --upgrade python-docx Pillow openpyxl
```

### 验证

```bash
python3 -c "from docx import Document; from PIL import Image; import openpyxl; print('OK')"
# 期望输出：OK
```

如果 `python3` 不存在：

- macOS：用 Homebrew 装 `brew install python@3.12`，或装官方 python.org 安装包。
- Windows：从 python.org 下载安装包，安装时勾选 "Add Python to PATH"。

---

## 3. 选择 AI agent（Codex CLI 推荐）

Harness 在 Codex CLI（OpenAI 出品）下经过完整验证；其他 agent 也可以跑（任何能加载 `AGENTS.md` 并执行 `pwsh`/`python3` 命令的 agent 都行）。

### 推荐：Codex CLI

```bash
# macOS（推荐用 npm 或 Homebrew）
npm install -g @openai/codex

# 或
brew install --cask codex
```

```powershell
# Windows
winget install OpenAI.Codex
```

启动 Codex 时把工作目录切到本 Harness 根目录（即 `SETUP.md` 所在的目录），Codex 会自动读 `AGENTS.md` 并按其角色工作。

### 用 Codex CLI 启动会话

```bash
cd /path/to/research-harness-template   # 替换为你的 Harness 实际路径
codex
```

Codex 启动后会读 `.codex/config.toml` 的 `project_root_markers = [".git", "AGENTS.md"]` 自动识别项目，然后按 `AGENTS.md` 的工作流运行。

### 也可以用其他 agent

如果你用 Claude Code 或别的 agent，确保 agent 启动时工作目录在本 Harness 根目录，并能让 agent 读取 `AGENTS.md`。把 `AGENTS.md` 路径直接告诉 agent 即可。

---

## 4. 跑一次验证（30 秒）

进入 Harness 根目录后跑一次结构验证，确认所有脚本能跑、wiki 与 skills 齐全：

```bash
cd /path/to/research-harness-template
pwsh -NoProfile -File ./scripts/validate-harness.ps1
```

### 期望输出

```
Portfolio validation passed. Cards: 0
Harness validation passed.
Skills: 15
Custom agents: 3
Required files: 61
Projects: 0
Wiki topics: 6
```

> 第一次运行 `Projects: 0` 是正常的——外发版不带任何项目。新建项目后这个数字会增加。

### 如果报错

| 报错 | 处理 |
| --- | --- |
| `pwsh: command not found` | 第 1 节 PowerShell 没装好，重装并验证 PATH |
| `python3: command not found` | 第 2 节 Python 没装好；macOS 推荐 `brew install python@3.12` |
| `Harness validation failed: ...` | 跑 `pwsh -NoProfile -File ./scripts/validate-harness.ps1` 把整段输出贴给 agent，让它按 `validate-harness.ps1` 第 N 行附近的报错定位问题 |
| `Projects: 0` 之外还看到 "Primary industry Wiki" 错误 | 第一次运行不应有此错。如果出现，说明模板 INDEX 写错了，跑 `pwsh -NoProfile -File ./scripts/validate-harness.ps1` 把输出贴给 agent |

### 也跑一次回归测试

```bash
pwsh -NoProfile -File ./scripts/tests/test-resolve-project-context.ps1
pwsh -NoProfile -File ./scripts/tests/test-resolve-profile-context.ps1
pwsh -NoProfile -File ./scripts/tests/test-portfolio-validation.ps1
pwsh -NoProfile -File ./scripts/tests/test-chat-knowledge-ingestion.ps1
```

每条都应该输出"passed"。任何一条失败 = Harness 文件损坏，把整段输出贴给 agent 让它定位。

---

## 5. 第一次运行的研究流程

`AGENTS.md` 第 2 节和 `WORKFLOW.md` 详细描述了完整流程；简单版：

1. 打开 Codex（或你的 agent），工作目录 = Harness 根目录
2. 上传 BP（同时可以上传访谈纪要、已有研究、财务/技术材料）
3. 对 agent 说：

   ```text
   开始研究这个项目，使用交互模式。
   ```

   或自动模式（不逐步确认）：

   ```text
   自动跑完行业细分、行业与项目深研、尽调设计，完成后一次性给我结果。
   ```

4. agent 会调用 `$project-setup` 自动识别公司、创建 `projects/<project_id>/` 目录、进入初始材料分析与行业定位
5. 后续每完成一个 Gate 会停下来等你确认（交互模式）或自动放行（自动模式）

详细的 sub-agent 任务包模板在 `scripts/templates/`：当你让 agent 派发 sub-agent 时，agent 会自动按这些模板预解析上下文，避免 sub-agent 重读整个 Harness 浪费 token。

---

## 6. 自定义（可选）

### 加自己的 Profile

`profiles/default/` 是空壳（仅一个 README）。如果你有自己的投资偏好（如特定的估值方法、不投某些赛道、特定的尽调要求）：

```bash
mkdir -p profiles/my-profile
cp profiles/INDEX.md profiles/my-profile/PROFILE.md   # 编辑里面的内容
```

然后告诉 agent：

```text
使用 my-profile 开始这个项目。以后估值和退出判断都按我这个 profile 的方法执行。
```

agent 会按 `profiles/my-profile/PROFILE.md` + `methodology.md` + `overrides/` 的覆盖规则调整行为。

### 修改 Wiki 沉淀的偏好

`wiki/INDEX.md` 顶部有"查找规则"。如果你想改（比如允许 fast swizzle 路径），改它并通知 agent "改 wiki 沉淀规则"。

### 修改 Skills

`evolution/runtime-skill-source/` 是可编辑的 Skills 发布源。修改后用：

```bash
pwsh -NoProfile -File ./scripts/sync-runtime-skills.ps1 -Apply -ConfirmNoActiveHarnessSession
```

把改动同步到 `.agents/skills/`。下一次新建 Codex session 生效。

---

## 7. 故障排查

### Python 找不到 PIL / docx

```bash
python3 -m pip install --force-reinstall python-docx Pillow openpyxl
```

### PowerShell 脚本说 "scripts/validate-xxx.ps1 not found"

确认你在 Harness 根目录（即包含 `AGENTS.md` 的目录）。`pwsh` 调用相对路径。

### agent 不认 `AGENTS.md`

- 确认工作目录就是 Harness 根目录
- Codex：检查 `~/.codex/config.toml` 或本目录 `.codex/config.toml` 的 `project_root_markers`
- Claude Code：把 `AGENTS.md` 路径明确告诉 agent，让它读取

### "按 SETUP.md 工作"

如果你是手动配置，按上面的 1-4 节依次执行。
如果你是让 agent 配置，把本 `SETUP.md` 全文发给 agent，并明确说：

> 请按本目录 `SETUP.md` 的全部 4 节要求完成配置（PowerShell 7、Python 依赖、agent 启动方式、validate-harness.ps1 验证），并在完成每一步后报告成功/失败。

---

## 8. 你拿到的是模板，不是完整数据

外发版**有意不带任何项目**——你的项目、BP、访谈、行业研究结论都是机密资产，不要放进外发版。外发版是 harness 的骨架，让别人复用你的方法论去研究他们自己的项目。

Harness 内已经积累的 **6 个 Wiki Topic**（光通信、AR Micro LED、AI 价值链、AI 自主算力、AI 光互联、前沿 AI）是公开来源支持、去项目化的行业共性知识——可以放心让接收方使用，但**不要再加你自有的项目 Wiki 沉淀**到外发版里。

---

完成 1-4 节后，整个 Harness 就可以正常工作。如果有任何步骤报错，把错误信息和执行命令一起贴给 agent 让它定位。