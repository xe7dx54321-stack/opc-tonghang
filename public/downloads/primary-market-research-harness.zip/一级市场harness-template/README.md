# 一级市场行业与项目研究 Harness

这是一个可直接作为 Codex workspace 使用的一级市场投研 Harness。

当前 Codex session 是主研究 Agent。它会读取 `AGENTS.md`，根据 `WORKFLOW.md` 推进研究，调用 repo Skills，并在需要时派发研究和审核 Sub-agent。

## 快速开始

1. 在 Codex 中打开本目录。
2. 上传 BP；也可以同时上传访谈纪要、已有研究、财务或技术材料，或把这些文件放进本目录并告诉 Codex 路径。
3. 直接说：

```text
开始研究这个项目，使用交互模式。
```

也可以说：

```text
自动跑完行业细分、行业研究和尽调清单，完成后一次性给我结果。
```

Codex 会根据当前 session 的材料选择或创建隔离的 `projects/<project_id>/`。新公司即使属于已经研究过的行业，也会创建独立项目，不继承旧项目的 Gate、证据或公司判断。

## 两种模式

- **交互模式**：在行业边界、大行业细分优选、深研核心判断、尽调清单、尽调结论和最终投资结论处停下来确认。
- **自动模式**：自动跑完前三阶段，记录所有假设和策略放行，完成后集中汇报。

先用 BP 和其他初始材料完成“初始材料分析与行业定位”，自上而下绘制具备投资属性的行业图谱；再做“细分筛选”，横向比较大行业全部同级可投资细分，直接呈现市场规模、增速、生命周期、拐点、竞争趋势和投资结论。用户确认细分筛选后，才进入“行业与项目深研”。尽调清单只在“尽调设计”环节生成。最终条款到达后，系统先形成行业研究与项目投资分析两篇最终版 Markdown 报告，再综合报告、最终尽调清单、证据和条款下达最终投资结论；两份 Word 正式版只在用户需要时生成。

相似项目不会直接读取旧项目目录。系统只通过 `wiki/` 复用公开、去项目化的行业成果；行业结论默认60天有效，过期或发生重大事件时先做快速增量更新。

对于前沿AI、机器人、芯片架构等技术驱动项目，系统会同时匹配两类知识：商业行业Topic负责市场、客户预算、产业链和竞争；`technology-landscape` Topic负责技术热点、演进趋势、全球/中国Mapping、替代路线和关键反证。技术版图只提供研究先验，进入项目证据矩阵前仍需打开公开原始来源。

## 聊天认知沉淀

日常ChatGPT或Codex会话中的高质量行业认知也可以沉淀。直接说：

```text
把名为“梳理大模型前沿论文”的会话中，技术热点、未来演进和全球/中国技术Mapping沉淀到Harness Wiki；排除具体项目分析。
```

系统会分页读取可访问会话，把公开事实候选、工作假设、技术Mapping、用户方法论和项目特定内容分开：

- 原始提炼记录进入 `knowledge-inbox/`；
- 经公开来源核验的事实进入Wiki `claims.md`；
- 尚未完全核验的趋势判断进入 `theses.md`，带置信度、证伪条件和来源状态；
- 全球/中国团队线索进入 `technology-map.md`，使用前按30天时效快速更新；
- BP、访谈、公司特定分析和项目去留结论不进入Wiki。

## 项目池择优

当本地已经积累多个项目，可以直接说：

```text
在半导体方向上，从我已经研究过的项目中选一个最值得进一步推进并最终投资的项目。使用标准预算，结合我的投资偏好。
```

系统不会完整重读所有项目。它先读取 `portfolio/INDEX.md` 和偏好中性的项目决策卡，做硬约束与投资上限过滤；只对 Top 3 定向重读关键报告、最终DD和决定性证据，再通过早期/中后期适配、两两对决、证伪结构和偏好敏感性选出第一优先级。

- `quick`：索引和卡片，适合长名单缩短；
- `standard`：卡片 + Top 3定向复核；用户没有明确指定预算档位时强制默认使用；
- `deep`：Top 2完整canonical成果，只有决定性冲突才读原始材料。

只有用户明确说 `quick` 或 `deep` 才切换档位；系统不会根据项目数量或token预算自行更改默认档位。

最终反馈只有一个综合投资优先级，同时说明从优先跟进到实际投资的差距。交给用户的一周验证任务每项目最多3项，必须能在七天内通过明确的人、材料、测试或公开来源获得相对客观的答案，并预设通过和失败后的投资动作。

## 多用户与个性化方法论

推荐每位用户使用本 Harness 的独立副本；如果必须共享同一目录，则为每位用户创建独立 `profiles/<profile_id>/`。新 session 可以直接说：

```text
使用 my-profile 开始这个项目。以后估值和退出判断都按我这个 profile 的方法执行。
```

用户对结果不满意时，可以直接指出哪里不对、希望以后怎么做。Agent 会按 `EVOLUTION.md` 判断这是当前项目纠正、该用户长期方法论，还是公共 Harness bug，并把规则、测试、版本和回退方式落盘。Profile override 只影响该用户，禁止读取或污染其他用户 Profile。

公共 Runtime Skills 采用发布机制：可编辑源位于 `evolution/runtime-skill-source/`，活动 Codex session 中 `.agents/skills/` 可能被锁定。验证并经用户批准后，在关闭使用本 Harness 的 Codex session 后运行：

```powershell
# Windows
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\sync-runtime-skills.ps1 -Apply -ConfirmNoActiveHarnessSession

# macOS / Linux（脚本会自动选用 pwsh）
pwsh -NoProfile -File ./scripts/sync-runtime-skills.ps1 -Apply -ConfirmNoActiveHarnessSession
```

脚本会先备份旧 Skills，再同步并校验；下一次新建 Codex session 后生效。普通用户个性化不需要改 Runtime Skills，Profile override 可直接生效。

## 核心目录

```text
AGENTS.md                 主控规则
WORKFLOW.md               从项目初始化到最终投资结论及可选 Word 正式报告的完整流程
.codex/agents/            三个稳定 Sub-agent
.agents/skills/           项目、行业Wiki、研究、尽调和判断 Skills
knowledge-inbox/          聊天等二次研究材料的提炼与Promotion审计记录
portfolio/                偏好中性项目决策卡与跨项目择优运行记录
profiles/                 各用户隔离的方法论、反馈与Skill覆盖层
evolution/                Evolution提案、可编辑Skill发布源、release与backup
references/               研究、证据和结论方法
templates/                项目和阶段产物模板
projects/                 真实研究项目
wiki/                     跨项目公开行业知识库
docs/plans/               设计与实施文档
```

## 第一版设计边界

当前版本刻意保持轻量：

- 使用 Markdown 保存状态和证据；
- 不依赖数据库；
- 不要求复杂 JSON Schema；
- 暂不使用 Hooks 强制流程；
- 先通过真实案例调优各阶段方法，再决定哪些规则需要程序化。

## 验证 Harness

该 Harness 已经在 Windows 和 macOS 上统一通过 PowerShell 7 (pwsh) 验证；其他 PowerShell 验证脚本共用 `scripts/_harness_helpers.ps1`，会根据当前平台自动选用 `pwsh` 或 `powershell` 启动子脚本，所以 Windows PowerShell 5.1 用户和 PowerShell 7 用户都能直接运行。

### Windows (PowerShell 5.1 / PowerShell 7)

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\validate-harness.ps1
```

### macOS / Linux (PowerShell 7)

1. 首次运行前安装 PowerShell 7：

   ```bash
   brew install --cask powershell        # macOS
   # 或参见 https://aka.ms/install-powershell
   ```

2. 运行 Harness 验证（路径以 Harness 根目录为基准）：

   ```bash
   pwsh -NoProfile -File ./scripts/validate-harness.ps1
   ```

   或者先 `cd` 到 Harness 根目录后用相对路径：

   ```bash
   pwsh -NoProfile -File scripts/validate-harness.ps1
   ```

该脚本检查 15 个 Runtime Skills、3 个自定义 Agent、项目/Profile隔离、项目池、行业/技术 Wiki、聊天认知入口、Evolution发布源、必需模板和Skill元数据。

阶段完成时对单个项目运行：

```bash
# Windows
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\validate-evidence.ps1 -ProjectId <project_id>

# macOS / Linux
pwsh -NoProfile -File ./scripts/validate-evidence.ps1 -ProjectId <project_id>
```

该脚本检查该项目证据引用的可解析性、编号重复、报告引用图片存在性，以及 03 行业深研报告的章节与核心结论完整性。

### 全量验证

```bash
# Windows
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\validate-all.ps1

# macOS / Linux
pwsh -NoProfile -File ./scripts/validate-all.ps1
```

### Python 脚本（图表 / Word 报告 / 图片处理）

`scripts/build-final-report-charts.py` 与 `scripts/build-image-contact-sheet.py` 已经在 `scripts/font_utils.py` 中封装了跨平台 CJK 字体解析：

- Windows：优先 `C:\Windows\Fonts\msyh.ttc`、`msyhbd.ttc`；
- macOS：优先 `/System/Library/Fonts/STHeiti Medium.ttc`，其次 `STHeiti Light.ttc`、`PingFang.ttc`、`Hiragino Sans GB.ttc`、`Songti.ttc`；
- Linux：自动回落 `/usr/share/fonts` 下的 Noto/WenQuanYi。

因此同一套脚本可以直接在 Windows 与 macOS 上生成视觉一致的报告图。依赖：

```bash
python3 -m pip install python-docx Pillow openpyxl
```

## 注意

本 Harness 用于提高研究效率和证据透明度，不替代法律、会计、税务、技术或其他专业尽调。投资决策应由有权人员结合完整材料作出。
