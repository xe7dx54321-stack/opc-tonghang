---
name: investment-verdict
description: Produce an evidence-calibrated DD conclusion and investment advice (A/B/C evidence sufficiency) with probability/odds judgment, entry-timing, core bet, and term-sheet/closing-condition recommendations. Use for 证据闭环与尽调结论 after supplemental diligence or when the user asks for the final view. When the user has not yet provided final investment terms, output a DD conclusion plus investment advice, NOT a final investment verdict.
---

# Investment Verdict（尽调结论与投资建议）

## 边界：尽调结论 ≠ 最终投资结论

- 用户未提供最终投资条款（估值、份额、交易结构、交割条件）时，**禁止输出"最终投资结论"**；本阶段交付 =「尽调结论（证据充分度 A/B/C）+ 投资建议（概率/赔率、出手时点、核心 bet、条款设计与交割先决条件）」；
- 用户提供最终条款后，再在本文件基础上更新为最终投资结论（接受 / 有条件接受 / 拒绝，并给出条款级判断）；
- 证据充分度等级不因"给不出最终条款"而上调或下调，两者是不同维度。

## Required Reading

- 全部 canonical 产物（含补充材料分析、尽调设计、要素表）
- `evidence/evidence-matrix.md` 与 `evidence/source-index.md`
- `references/evidence-standard.md`、`references/investment-rubric.md`
- `templates/05-verdict.md`

## Procedure

1. **先做线索驱动追证**（配合 `$material-analysis` 模式 B）：把尽调材料中的每个关键条目当线索（专利、客户/订单、产能/设备、融资/估值、技术路线），对能改变 P0/P1 判断的线索做定向外部检索，逐条记录"检索动作 + 结果（新证据 / 与口径冲突 / 检索无果）"；**检索无果本身是结论的一部分**，不得用"未验证"一带而过。
2. Review every fatal and critical question before aggregate coverage（Q-xx 逐项过一遍）。
3. Summarize bull case, bear case, and the few assumptions that drive the outcome。
4. Identify unsupported leaps, conflicting evidence, and sensitivity to price or financing。
5. 给出证据充分度：A / B / C（`references/investment-rubric.md` 规则不变：fatal 未解决 → C；不得因后续条款建议而上调）。
6. **概率/赔率判断（VC know-how，必做）**：
   - 对每条决定结论的核心判断（量产成功、客户转化、放量时点、资金闭环、合规整改等）给出**概率区间**与**依据强度（强/中/弱）**，并写出反证方向；
   - 最终 A/B/C 或 Bull/Base/Bear 分支必须**相互排斥且完全覆盖**，写清联合概率、条件概率和相关性；同一客户或同一量产事件不得在两个分支重复计入；
   - 用估值隐含回报反推"隐含要求成功率"，与估计概率对比 → 判断**赔率是否对等**；公司退出估值÷入口投后估值只能作为未稀释毛回报，不能直接当基金回报；
   - **稀释与跟投（必做）**：列出至少 0% / 15% / 30% 累计稀释情景，或用明确的后续融资规模、估值与持股公式推导；分别计算不跟投的持股稀释，以及行使优先认购权所需追加资本。基金口径倍数的分母必须包含已承诺跟投资金；优先认购权不等于已预留预算；
   - 若后续融资口径缺失，必须把回报写成敏感性区间并撤回精确的"可投估值上限"，不得用最近完成轮价格自动推出赔率对等；
   - **出手时点判断**：早鸟（高赔率、高不确定）vs 量产确认后（低赔率、低不确定），说明哪个时点对 LP 回报更优及理由——"等量产落地再投"通常意味着高估值低回报，可能把项目投成鸡肋；
   - **核心 bet**：哪 1-2 个判断是超额收益来源，兑现路径与可证伪信号；
   - 禁止用"未验证/无法判断"回避概率结论；概率必须有推导依据并标注强度。
7. **条款设计建议**（研究建议，须由交易团队与律师落地）：
   - 估值锚定：最近完成轮 vs 拟议轮，拒绝无依据跳涨，说明合理估值区间；
   - 里程碑分期与估值调整触发条件；
   - **交割先决条件（CP）**：把未闭环证据转化为 CP（出资凭证、客户文件、良率批次、资金计划、合规整改等）；
   - 保护条款：顺位、反稀释、回购、优先清算、最惠、实控人兜底；
   - 跟投资金：明确是否行使优先认购权、基金追加资本上限，以及不跟投时的稀释后回报；
   - 治理与信息权：董事席位、保留事项、财务/经营信息权；
   - 法律、税务、会计与交易条款须专业复核。
8. State what would upgrade or downgrade the conclusion（外部信号，非新尽调请求）。
9. Write `outputs/investment/01-verdict.md`（标题=尽调结论与投资建议；后续条款到达后更新为最终投资结论）。

## Loop Control

仅在"具体、可获得、能实质改变决策"的证据请求仍存在时返回 `$material-analysis`；用户已用完尽调预算时，缺失项如实列入并转化为概率影响与条款/交割保护，不再追加尽调请求。连续两轮关键问题覆盖无实质提升，提示"信息获取能力本身是风险"。默认最多三轮。

## Independent Review and Gate

- 主 Agent 必须 spawn `investment_reviewer` 并调用 `$evidence-review` 独立复核（投资结论确认前）；
- reviewer 通过前不 finalize；
- reviewer 必须复算互斥概率树、未稀释回报、累计稀释、跟投资金分母和隐含成功率；任一项不可复算即 FAIL；
- 复核后停在"请用户确认尽调结论与投资建议（或提供最终条款后形成最终投资结论）"。
