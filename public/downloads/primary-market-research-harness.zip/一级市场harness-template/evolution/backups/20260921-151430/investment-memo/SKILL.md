---
name: investment-memo
description: Assemble approved segment, industry, project, diligence, evidence, and verdict artifacts into a coherent investment-committee memo. Use for the optional investment-report step after the investment conclusion is approved, or when the user asks for an investment report. Do not introduce new facts, sources, or stronger conclusions merely to improve the narrative.
---

# Investment Memo

Assemble, do not reinvent.

## Inputs

- Approved `PROJECT.md`
- canonical artifacts under `outputs/industry/`, `outputs/project/`, and `outputs/investment/01-verdict.md`
- source index and evidence matrix
- investment-conclusion review
- `templates/06-investment-memo.md`

## Procedure

1. Confirm the investment conclusion is approved or clearly marked as a draft requested by the user.
2. Build the memo from canonical artifacts:
   - executive decision;
   - company and financing;
   - market definition;
   - industry and competition;
   - product and technology;
   - business model and GTM;
   - operating and financial quality;
   - team;
   - risks and counter-thesis;
   - valuation, conditions, and next steps;
   - evidence limitations.
3. In the Markdown research version, preserve evidence IDs beside material factual claims.
4. Preserve uncertainty and contrary evidence.
5. If a required section lacks evidence, say so instead of filling it with generic text.
6. Write `outputs/investment/02-investment-memo.md`.
7. Create the Word submission version as a separate editorial render, not a direct format conversion:
   - remove evidence/source/process codes, internal filenames, and harness terms such as reviewer, Gate, canonical, evidence matrix, and Wiki;
   - translate provenance into human language such as public information, management interviews, financial diligence, and legal documents;
   - omit the internal evidence index while preserving uncertainty, counter-evidence, and scope limitations;
   - inspect every visual; use deterministic charts for exact numbers and image-2 only for conceptual visuals, then verify text and layout;
   - audit both document text and embedded media for internal codes; use submission-only visual paths or hashes so an old coded chart cannot silently return;
   - fully de-project the industry Word report by removing the target project's non-public customers, orders, patents, yields, finances, financing, valuation, funding gaps, terms, and project-relative comparison columns;
   - keep all facts, assumptions, probabilities, terms, and conclusions identical to the Markdown version.
8. Write the submission-ready `.docx` and audit it for residual internal codes and system language.

## Review

Ask `investment_reviewer` to perform a final integrity review:

- no new unsupported facts;
- verdict and memo agree;
- material risks remain visible;
- citations resolve to the evidence matrix and source index.
- the Word version is readable by an investment committee, contains no internal codes, and remains substantively consistent with Markdown;
- all Word visuals are legible, correctly proportioned, and free of internal evidence labels.

Mark the memo final only after resolving or disclosing review findings.
