---
name: material-analysis
description: Analyze supplemental diligence materials, datasets, and interview notes, then incrementally update sources, evidence, contradictions, and affected project judgments. Use for 补充材料与访谈分析 whenever new files or interviews arrive. Supports two input modes: 增量模式 (in-session feedback, no user document) and 终局模式 (all materials + final conclusion report). Do not rerun or rewrite unaffected research sections.
---

# Material Analysis

Process new evidence without losing provenance or rewriting the whole case.

## Inputs

- New files registered under the selected project's categorized `inputs/` directories
- Existing `PROJECT.md`, `inputs/manifest.md`, source index, evidence matrix, `outputs/project/02-dd-checklist.md`, industry research, and project assessment
- `references/evidence-standard.md`
- `templates/04-material-update.md`（内部核对底稿，仅终局模式或 agent 自用时可选使用；增量模式不产出用户文档）

## 输入模式（两套兼容方案）

先判定模式，再执行。判定规则：

- **模式 B（终局）**：用户明确表达收尾信号，如"这是所有材料 / 材料齐了 / 没有更多材料了 / 直接给我最终结论"。或用户已完成全部尽调并进入投资判断 Gate。
- **模式 A（增量，默认）**：其余一切情况。用户只发材料、未声明收尾 → 模式 A；上一轮模式 A 反馈后，用户回复"没有了，给我最终结论吧"等 → 切换模式 B。

## 线索驱动追证（Active Evidence Pursuit）

尽调材料中的每个关键条目都应视为**线索（起点），不是终点**。不得只做"材料→checklist 对照"后直接给结论；在形成尽调结论前，对能改变 P0/P1 判断的线索执行定向外部追证：

- **专利线索**：逐项检索专利状态（已授权 / 审中 / 公开）、技术内容、权利要求覆盖范围、与量产卡点的对应关系；"拥有 N 项专利"必须区分"已授权"与"申请中"，授权率与 FTO 单独判断；
- **客户/订单线索**：公开报道、工商/供应链交叉、可验证的 PO/回款迹象；
- **产能/设备/产线线索**：公开信息、设备商/园区/地方报道交叉；
- **融资/估值线索**：工商变更、公告、媒体交叉（最近完成轮 vs 拟议轮必须区分）；
- **技术与路线线索**：论文/专利/竞对公开资料，判断路线可行性证据链；
- 每条追证记录"检索动作 + 结果（新证据 / 与口径冲突 / 检索无果）"；**检索无果本身是结论的一部分**（降低该线索的置信度），不得用"未验证"一带而过；
- 追证预算按"能否改变决策"分配，优先 P0/P1 线索。

## 模式 A：增量分析（session 内反馈，不生成用户文档）

1. 登记新文件至 `evidence/source-index.md`（内部必需，稳定 SRC ID）。
2. 提取事实、管理层口径、观点、数字、日期、定义与局限；统一公司名、产品、期间、币种、单位、客户别名与指标口径。
3. 链接证据到现有 `Q-xx`、主张和 `DD-xxx`；仅当材料揭示真正的新决策问题时才新建问题。
4. 更新 `evidence/evidence-matrix.md` 受影响行与矛盾清单（内部必需，照常；只改受影响行，不重跑未受影响章节）。
5. 核对 DD 清单（DD-001~DD-010 及后续新增）：逐项标注 `完成` / `部分确认` / `缺失`，写明证据缺口与口径冲突。
6. 在 session 内直接反馈（**不创建 03-material-update.md**）：
   - 本轮收到什么（材料 → DD 对应关系）；
   - DD 核对结果表（完成 / 部分确认 / 缺失）；
   - 判断变化摘要（被加强的判断、被削弱或推翻的判断、新出现的风险）；
   - 下一步最小补证建议（按决策影响排序的 1-3 项 + 获取方式）；
   - 询问用户是否还有额外材料：有 → 继续模式 A；没有 → 引导用户说"没有了，给我最终结论吧"进入模式 B。

## 模式 B：终局分析（生成最终报告文档）

1. 全量核对 DD 清单与全部材料：`完成 / 部分确认 / 缺失` 逐项落表（内部核对底稿可复用 04 模板，不作为用户文档）。
2. **先执行线索驱动追证**：对 P0/P1 线索（专利状态、客户/订单、产能/设备、融资/估值、技术路线）做定向外部检索与交叉验证，把"检索无果"也计入结论。
3. 更新 `evidence/evidence-matrix.md` 与矛盾清单（照常）。
4. 调用 `$investment-verdict` 输出**尽调结论与投资建议**（A/B/C 证据充分度 + 概率/赔率判断 + 出手时点 + 核心 bet + 条款设计与交割先决条件建议），并由 `investment_reviewer` 独立复核（投资结论确认前）。
5. 输出 `outputs/investment/01-verdict.md`（可选追加 `02-investment-memo.md`）。
6. **不再追加尽调请求**——用户已用完尽调预算；未验证/缺失项如实列入，并转化为"对概率判断的影响 + 条款/交割保护方向"。

## Interview Discipline

- Separate what the interviewee observed from what they inferred.
- Record role, relationship, date, possible bias, and whether identity is confidential.
- Do not treat a single interview as market prevalence.
- Keep important wording short; do not reproduce long copyrighted or confidential passages.

## Handoff

- 模式 A：反馈后等待用户继续投料，或用户声明收尾（"没有了，给我最终结论吧"）后切换模式 B；
- 模式 B：输出"尽调结论与投资建议"（证据充分度 A/B/C + 概率/赔率 + 出手时点 + 核心 bet + 条款设计与交割先决条件），经用户确认后进入可选投资报告；用户提供最终投资条款后，再更新为最终投资结论（接受/有条件接受/拒绝）。任何模式都不得把另一项目的材料放入本项目。
