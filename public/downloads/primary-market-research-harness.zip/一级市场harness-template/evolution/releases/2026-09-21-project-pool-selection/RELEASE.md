# Release 2026-09-21：项目池择优层

- 状态：`Runtime Synced / Awaiting New-session Smoke Test`
- 批准来源：用户确认项目池横向择优方案，并明确要求开始施工优化当前Harness
- 发布范围：Core
- Runtime backup：`evolution/backups/20260921-151430/`

## 业务变化

1. 新增独立“项目池择优”工作流，不改变现有单项目研究流程和Gate。
2. 统一回答“哪个项目最值得优先配置投资决策资源并最终下注”，不再建立割裂的跟进榜与投资榜。
3. 先做投资上限测试：即使核心叙述全部成立仍不够好的项目不消耗验证预算。
4. 早期项目采用价值重估、证伪、现金和退出四个时钟；中后期项目采用收入质量、上市/并购、锁定期和公开市场估值逻辑。
5. 叙述分为已证伪、一周可验证、当前未证明但未来可阶段性证伪、长期缺乏客观标准；最后一类在满足条件时一票否决。
6. 用户行动清单限定为每项目最多3项、七天内可执行、有客观阈值并明确映射投资动作。
7. 用户当次指令与Profile偏好叠加到项目池运行，不写回偏好中性的项目决策卡。
8. 预算档位采用硬默认：用户未明确指定时必须使用`standard`；只有用户明确要求`quick`或`deep`才能切换，系统不得自行推断升降档。

## 新增组件

- Skills：`project-decision-card`、`project-pool-selection`
- Agent：`portfolio_reviewer`
- 目录：`portfolio/INDEX.md`、`portfolio/cards/`、`portfolio/runs/`
- 模板：项目决策卡、项目池任务书、项目池择优报告
- 方法论：`references/portfolio-selection-framework.md`
- 验证：`validate-portfolio.ps1`、`test-portfolio-validation.ps1`

## 验证结果

- skill-creator quick validation：2个新Skill均PASS
- portfolio validator：PASS
- portfolio validator regression：PASS（Windows PowerShell与PowerShell 7）
- Harness structure：PASS（14 Skills / 3 custom agents / 13 projects / 3 Wiki topics）
- Evolution source/runtime hash：PASS，7个发布源无drift
- 微玖光电既有闭环回归：PASS（evidence、workbook、final conclusion及全Harness校验）
- 真实卡片冒烟：从微玖光电冻结的canonical产物生成首张偏好中性卡片，未读取原始材料；结构校验PASS，并正确因融资/客户/良率时效将卡片标记为`stale`

## 新Session冒烟

新开Codex session后确认以下Skill可被发现：

- `$project-decision-card`
- `$project-pool-selection`

然后用一个已闭环项目生成首张决策卡，再用至少两个同范围项目运行一次`quick`或`standard`择优。冒烟通过后把状态改为`Released`。

## Rollback

如运行时Skills需要回退，使用：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\sync-runtime-skills.ps1 -RestoreFrom .\evolution\backups\20260921-151430 -ConfirmNoActiveHarnessSession
```

新增项目池文件不覆盖任何单项目canonical资产，回退Skill不会改变既有项目结论。
