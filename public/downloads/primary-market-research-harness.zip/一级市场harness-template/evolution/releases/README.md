# Evolution Releases

每次发布记录：版本、批准人、受影响Profiles/Skills、测试结果、运行时同步时间、新session冒烟结果和backup路径。

未完成用户确认、验证或runtime同步的版本不得标记Released。

## 版本

- `2026-09-21-chat-knowledge-ingestion/`：聊天认知沉淀、技术版图Wiki和项目双轴知识匹配。
