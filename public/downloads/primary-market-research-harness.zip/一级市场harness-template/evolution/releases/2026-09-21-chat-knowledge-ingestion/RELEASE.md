# Chat Knowledge Ingestion & Technology Landscape Wiki

- 日期：2026-09-21
- 状态：Implemented；Runtime快照已同步；待下一次新session自然冒烟
- 用户批准：已明确要求把会话中的技术热点、演进趋势与全球/中国Mapping落地到Harness，并排除具体项目分析

## 变更

1. 新增 `$chat-knowledge-ingestion` Runtime Skill及发布源；
2. 新增 `knowledge-inbox/`，保存会话读取完整度、纳入范围、排除边界和Promotion记录；
3. Wiki新增 `technology-landscape` Topic类型、`theses.md` 与 `technology-map.md`；
4. 新增 `frontier-ai-technology-landscape`，沉淀前沿AI技术主线、演进假设和全球/中国团队检索入口；
5. 项目启动、行业定位、细分筛选和深研同时支持商业行业Topic与技术版图Topic；
6. 工作假设不得作为项目证据；`partial/unverified`和`review_due`强制快速更新；
7. 技术热点/团队Mapping默认30天freshness，商业行业Topic继续按各自时效执行。

## 隔离与证据边界

- 会话中的两个具体项目、BP/附件内容和项目是否值得跟进的判断没有进入Wiki；
- 会话被登记为认知来源，不替代论文、官网、官方Benchmark或原始融资披露；
- 未来项目使用Mapping前必须打开原始公开来源并分配项目本地Evidence ID。

## 验证结果

- Skill quick validation：source与runtime均通过；
- `scripts/validate-evolution.ps1 -RequireRuntimeSync`：通过，8个source Skills与runtime一致；
- `scripts/validate-harness.ps1`：通过，15个Runtime Skills、4个Wiki Topics；
- `scripts/tests/test-chat-knowledge-ingestion.ps1`：通过；
- freshness正反例：通过。partial/review_due Topic返回`quick_update_required`，verified/fresh Topic返回`fresh`，过期Topic返回`quick_update_required`。

## 全量工作区基线

`scripts/validate-all.ps1`已执行。本次新增的Harness结构、Evolution同步、Profile、项目解析、项目池和聊天认知回归均通过；全量结果仍被若干历史项目的证据ID、旧工作簿Checks页、缺失review/图片及workspace hygiene问题阻塞。这些问题早于本release且不由本功能引入，为避免改写用户历史项目，本release未批量修复。

## 回退

删除新增Skill、knowledge-inbox和前沿AI Topic，并恢复本release涉及的AGENTS、WORKFLOW、README、templates与验证脚本。项目目录与既有行业Topic不受影响。
