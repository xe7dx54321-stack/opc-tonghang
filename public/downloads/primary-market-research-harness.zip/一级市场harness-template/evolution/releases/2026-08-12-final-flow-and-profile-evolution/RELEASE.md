# Release 2026-08-12：终局流程与多用户方法论演进

- 状态：`Approved / Awaiting Runtime Sync`
- 批准来源：用户明确要求终局顺序调整、允许Skill更新，并要求支持多用户千人千面演进
- 发布范围：Core

## 变化

1. 终局顺序固定为“两篇最终版Markdown报告 → 终局DD/证据/条款一致性 → 最终投资结论 → 可选两份Word”。
2. `final-investment-decision`、`investment-memo`、`investment-verdict`、`material-analysis`形成一致的handoff边界。
3. 新增`harness-evolution`，支持Project/Profile/Core三层反馈分流。
4. 新增session级Profile选择、用户隔离、Skill override、测试、版本与rollback规则。
5. 新增Profile/Evolution验证、runtime Skill备份同步和恢复脚本。

## 验证

- `validate-profiles.ps1`：PASS
- `test-resolve-profile-context.ps1`：PASS（default、explicit、unknown、traversal）
- `validate-evolution.ps1`：source PASS；runtime drift待同步
- skill-creator `quick_validate.py`：5个source Skills全部PASS
- 微玖光电终局联合复核：PASS；P0/P1/P2=0
- 微玖光电final-conclusion/evidence/workbook：PASS

## Runtime 发布

活动session的`.agents/skills/`被Codex静态锁定，宿主ACL临时放行也不能改变该边界；所有临时ACL已恢复。

关闭使用本Harness的Codex session后运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\sync-runtime-skills.ps1 -Apply -ConfirmNoActiveHarnessSession
```

同步脚本会在`evolution/backups/<timestamp>/`备份旧Skills。随后新开session运行`validate-all.ps1`；通过后将本release状态改为`Released`。

## Rollback

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\sync-runtime-skills.ps1 -RestoreFrom <backup-path> -ConfirmNoActiveHarnessSession
```
