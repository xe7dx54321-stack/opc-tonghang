# Evolution Proposals

每个提案使用 `templates/evolution-proposal.md`，目录命名建议：`YYYY-MM-DD-<profile>-<topic>/`。

提案禁止包含BP、访谈原文、客户名单、财务明细或交易机密；测试fixture必须去敏。
