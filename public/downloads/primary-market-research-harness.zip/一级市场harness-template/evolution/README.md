# Evolution Workspace

本目录承载可编辑的演进资产，不存放任何项目机密。

- `runtime-skill-source/`：下一版运行时Skills的可编辑发布源；
- `proposals/`：项目/Profile/Core变更提案；
- `releases/`：已批准版本、测试结果与迁移说明；
- `backups/`：同步脚本运行时生成的Skill快照（不提交项目材料）。

活动Codex session可能锁定`.agents/skills/`。业务个性化优先写入`profiles/<profile_id>/overrides/`并立即生效；公共Skill只通过source→验证→用户确认→session外同步→新session回归发布。
