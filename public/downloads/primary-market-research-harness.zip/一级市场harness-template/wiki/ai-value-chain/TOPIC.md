# 人工智能价值链定位

## Metadata

- industry_id：`ai-value-chain`
- topic_kind：`industry`
- aliases：人工智能产业、AI价值链
- scope：全球人工智能产业四层定位；不含正式排名、规模加总或项目判断
- geography：全球
- last_verified_at：`2026-09-14`
- source_cutoff：`2026-09-14`
- freshness_days：`60`
- next_review_due：`2026-11-13`
- status：`fresh`
- volatility：`high`
- source_verification：`verified`

## 可复用范围

包含：算力、数据工具、模型供给、应用四层定义。不同层预算不可直接相加或统一排名。不包含任何目标公司信息、项目结论或未确认的细分排序。来源为已打开企业官网，仅支持分类。

## 文件

- taxonomy.md
- conclusions.md
- claims.md
- source-index.md
- updates/
