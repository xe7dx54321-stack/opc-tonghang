# AR/智能眼镜 Micro LED 图像源器件

## Metadata

- industry_id：`ar-microled-image-source`
- topic_kind：`industry`
- aliases：LEDoS、Micro LED微显示、AR微显示图像源、硅基Micro LED
- scope：面向AR/智能眼镜整机品牌或光机集成商的Micro LED芯片、微显示屏体与图像源器件；客户预算位于近眼显示器件层
- geography：中国商业化与供应链为主，全球技术路线、终端采用和竞争格局为参照
- last_verified_at：`2026-08-10`
- source_cutoff：`2026-08-10`
- freshness_days：`60`
- next_review_due：`2026-10-09`
- status：`fresh`
- volatility：`high`
- source_verification：`verified`

## 可复用范围

- 包含：Micro LED近眼微显示器件定义、技术路线、市场情景、生命周期、价值链、竞争、关键成功因素、替代威胁和公开可比公司。
- 不包含：AR整机、波导/光机整体价值、车载像素照明、直显大屏、通用LED、Micro LED光互连，以及任何项目的非公开客户、良率、财务、融资和投资判断。
- 相邻但不可直接复用：Micro OLED、LCoS可作为同一客户任务的替代路线参照；AI光互连属于不同客户预算和价值池，必须另建Topic。

## 文件

- `taxonomy.md`
- `conclusions.md`
- `claims.md`
- `source-index.md`
- `updates/`
