# AR/智能眼镜 Micro LED 图像源器件 · Claims

| Claim ID | Reusable claim | Type | Status | Confidence | Volatility | Evidence | Last verified | Review due | Counterevidence |
|---|---|---|---|---|---|---|---|---|---|
| W-C-001 | 本Topic的正式经济边界是AR/智能眼镜图像源器件，不含整机、波导和完整光机价值 | definition | Supported | high | low | W-SRC-001,W-SRC-002 | 2026-08-10 | 2026-10-09 | 供应商可能同时交付屏体和光机，测算时仍须拆分价值量 |
| W-C-002 | Micro LED近眼显示仍处导入期，单色已有交付、全彩规模化尚未确认 | lifecycle | Supported | medium | high | W-SRC-001,W-SRC-005,W-SRC-010,W-SRC-011 | 2026-08-10 | 2026-10-09 | 部分厂商宣称量产级全彩或堆叠产品已经出货，但缺少同口径行业数据 |
| W-C-003 | 智能眼镜总量增长不能直接推出带显示AR或Micro LED器件同步放量 | market | Supported | high | high | W-SRC-003,W-SRC-004 | 2026-08-10 | 头部品牌若集中发布带显示产品，转换比例可能快速提升 |
| W-C-004 | 2030年器件TAM应由带显示出货×路线渗透×器件ASP推导，现阶段不宜采用单点权威数字 | market | Partial | medium | high | W-SRC-002,W-SRC-003,W-SRC-004,W-SRC-006 | 2026-08-10 | TrendForce给出LEDoS终端/渗透预测，但仍不是器件采购额 |
| W-C-005 | 三色合光是近期工程化路线，单片全彩是中长期重要收敛方向 | technology | Partial | medium | high | W-SRC-001,W-SRC-007,W-SRC-011 | 2026-08-10 | 堆叠、量子点与多波长路线的量产时间仍存在显著分歧 |
| W-C-006 | 红光效率、键合/全彩良率和完全成本是Micro LED近眼显示的核心技术经济瓶颈 | technology | Supported | medium | high | W-SRC-001,W-SRC-007 | 2026-08-10 | 厂商公布的单项性能或专利不能替代连续批次数据 |
| W-C-007 | JBD具有公开商业化先发优势，但大型面板/LED企业和多条替代路线仍可能改变格局 | competition | Supported | medium | high | W-SRC-005,W-SRC-010,W-SRC-012,W-SRC-013 | 2026-08-10 | 公开出货、客户和盈利数据仍不完整 |
| W-C-008 | Micro OLED与LCoS必须作为同一客户任务的替代路线持续跟踪 | substitution | Supported | high | high | W-SRC-001,W-SRC-006,W-SRC-008,W-SRC-009 | 2026-08-10 | Micro LED若在亮度、功耗和成本同时突破，可能显著提高路线份额 |
| W-C-009 | 行业关键成功因素是量产良率×完全成本、头部客户闭环、垂直整合迭代和资本/产能节奏 | investment inference | Partial | medium | high | W-SRC-001,W-SRC-005,W-SRC-010,W-SRC-013 | 2026-08-10 | 企业商业模式、外协程度和客户结构不同，需项目级验证 |
| W-C-010 | 当前公开市场与政策环境改善硬科技退出可选性，但高风险偏好估值不能视为跨周期常态 | valuation environment | Supported | medium | high | W-SRC-008,W-SRC-009,W-SRC-014,W-SRC-015 | 2026-08-10 | 资本市场估值、IPO节奏和并购政策可能快速变化 |
