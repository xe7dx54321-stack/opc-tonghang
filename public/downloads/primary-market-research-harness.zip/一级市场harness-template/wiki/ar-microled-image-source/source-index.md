# AR/智能眼镜 Micro LED 图像源器件 · Public Sources

| Source ID | 来源 | 日期 | URL | 用途 | 局限 |
|---|---|---|---|---|---|
| W-SRC-001 | TrendForce《玻璃基與矽基 Micro LED：群雄逐鹿》 | 2025-12-04 | https://www.trendforce.com.tw/insights/glass-silicon-based-micro-led | LEDoS竞争、出货预测、路线演进 | 机构预测，终端/技术口径不是器件采购额 |
| W-SRC-002 | TrendForce《AR显示技术竞争…2030 LEDoS渗透率65%》 | 2025-11-26 | https://www.trendforce.com.tw/presscenter/news/20251126-12797.html | 路线渗透率 | 预测会随品牌路线变化 |
| W-SRC-003 | Counterpoint智能眼镜2025H1数据（智通财经转引） | 2025-08-14 | https://www.zhitongcaijing.com/content/detail/1329352.html | 智能眼镜增长 | 含无显示音频眼镜，非器件口径 |
| W-SRC-004 | IDC智能眼镜2025H1数据（C114转引） | 2025-10-21 | https://www.c114.com.cn/4app/3542/a1299068.html | 全球/中国出货、AR细分差异 | 二手转引，分类口径需持续核对 |
| W-SRC-005 | JBD完成超10亿元B2轮融资 | 2025-10 | https://www.jb-display.com.cn/newsdetails/71.html | 先发企业资本与扩产强度 | 未披露估值和盈利 |
| W-SRC-006 | Himax/AUO LCoS AR方案 | 2025-12-30 | https://www.nasdaq.com/press-release/himax-and-auo-partner-unveil-ultra-slim-high-brightness-lcos-microdisplay-ces-2026 | LCoS替代路线 | 厂商性能口径 |
| W-SRC-007 | 南京大学RGB全氮化镓全彩Micro LED原型 | 2024-12-03 | https://m.ledinside.cn/knowledge/20241203-58519.html | 单片全彩技术进展 | 学术原型不等于量产 |
| W-SRC-008 | 视涯科技上市公告 | 2026-03-24 | https://www.sse.com.cn/disclosure/announcement/listing/ipo/c/c_20260324_10812805.shtml | Micro OLED上市可比与退出路径 | 不同技术路线和成熟度 |
| W-SRC-009 | 视涯科技2025年度业绩预计 | 2025-12-14 | https://static.sse.com.cn/stock/disclosure/announcement/c/202512/002094_20251214_4FN8.pdf | 收入和亏损参照 | 业绩预计非最终审计数 |
| W-SRC-010 | 京东方华灿Micro LED投资者交流（TrendForce整理） | 2026-07-13 | https://www.trendforce.cn/industry-news/optoelectronics/20260713-6394.html | 单色交付、全彩Demo、光互连进度 | 公司披露口径 |
| W-SRC-011 | PlayNitride堆叠与单片全彩进展 | 2026-06-27 | https://www.microled-info.com/playnitride-discusses-its-latest-financials-starts-shipping-its-tandem-stacked | 堆叠/全彩路线进展 | 第三方博客且作者披露持股 |
| W-SRC-012 | JBD合肥Micro LED二期项目进度 | 2026-07-20 | https://www.fpdisplay.com/mobile/news/show-212858.html | 先发企业扩产 | 地方发布口径转引 |
| W-SRC-013 | 2025年Micro OLED行业规模与份额 | 2026-01-14 | https://www.chyxx.com/industry/1249149.html | 相邻器件池与替代路线 | 第三方咨询估算 |
| W-SRC-014 | 沪市市场运行情况 | 2026-07 | https://www.sse.com.cn/aboutus/mediacenter/conference/c/10824350/files/e126b71d44414f5b99310a443bb9ff07.pdf | 硬科技估值周期 | P/E不能直接套用早期项目 |
| W-SRC-015 | 证监会“科创板八条” | 2024-06-19 | https://www.csrc.gov.cn/csrc/c100028/c7487997/content.shtml | 未盈利硬科技IPO/M&A政策 | 政策支持不保证个案退出 |
