# AI集群光互联产业链

## Metadata

- industry_id：`ai-cluster-optical-interconnect`
- topic_kind：`industry`
- aliases：光互联、AI光互联、数据中心光互联、光模块、800G、1.6T、3.2T、硅光、SiPh、薄膜铌酸锂、TFLN、MRM、LPO、LRO、NPO、CPO、OIO、Optical I/O、OCS、Optical Fabric、ELS、PD、GeSi PD、FAU、Fiber Shuffle、FMU
- scope：面向AI数据中心和算力集群的数据中心内、Scale-out、Scale-up、机柜/板级、封装内与芯片旁光互联；覆盖材料、发射光源、接收探测、PIC、电芯片、无源/光纤连接、光电封装与测试、模块/近封装/共封装、OIO和OCS；不含AR微显示、激光雷达、消费光学和传统长途骨干网的完整市场
- geography：中国商业化与供应链为主；全球产品形态、标准与技术路线作参照
- last_verified_at：`2026-09-21`
- source_cutoff：`2026-09-21`
- freshness_days：`30`
- next_review_due：`2026-10-21`
- status：`review_due`
- volatility：`high`
- source_verification：`partial`

## 可复用范围

用于光互联项目的行业定位、产业链拆分、技术路线比较、公司检索和里程碑设计。当前只完成用户材料提炼，未对产品代际、市场规模、公司量产/客户状态和路线时间表做公开原始来源重建；项目使用前必须快速更新。

## 文件

- taxonomy.md
- conclusions.md
- theses.md
- company-leads.md
- verification-priorities.md
- claims.md
- source-index.md
- updates/
