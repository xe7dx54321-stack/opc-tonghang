# 行业主张

| Claim ID | Reusable claim | Type | Status | Confidence | Volatility | Evidence | Last verified | Review due | Counterevidence |
|---|---|---|---|---|---|---|---|---|---|
| W-C-001 | AI集群光互联可按材料/晶圆、发射光源与接收探测、PIC、电芯片、无源/光纤、封装、测试、模块、NPO/CPO、OIO和OCS建立十二层母表 | 分类框架 | Partial | 高 | medium | W-SRC-001、W-SRC-002、W-SRC-005 | 2026-09-21 | 2026-10-21 | 不同架构会合并或拆分部分层级，分类不等于各层均有独立价值池 |
| W-C-002 | 光互联产品应按信号处理、光引擎位置和接口密度三个维度比较，并另行评估OCS拓扑层 | 技术框架 | Partial | 高 | high | W-SRC-001、W-SRC-002、W-SRC-003、W-SRC-005 | 2026-09-21 | 2026-10-21 | 具体优劣取决于距离、速率、系统和产品代际，不能给统一排序 |
| W-C-003 | 光引擎靠近ASIC/XPU后，封装测试、ELS、PM Fiber、FAU和Fiber Management需要纳入价值链分析 | 产业结构 | Partial | 中高 | high | W-SRC-001、W-SRC-002、W-SRC-003 | 2026-09-21 | 2026-10-21 | 若架构长期停留在可插拔，新增节点的市场形成会推迟 |
| W-C-004 | TFLN、MRM、MicroLED和OIO当前应按工作假设与里程碑管理，而非仅凭器件性能给出商业化结论 | 投资方法 | Supported | 高 | medium | W-SRC-002、W-SRC-003 | 2026-09-21 | 2026-10-21 | 获得标准、客户量产和可复现系统收益后，具体路线可升级为事实性判断 |
| W-C-005 | 材料中的公司池只构成检索入口，不证明供应关系、量产、客户或投资优先级 | 来源限制 | Supported | 高 | low | W-SRC-001、W-SRC-002、W-SRC-003 | 2026-09-21 | 2026-10-21 | 取得一手公开披露后，可升级单家公司事实 |
| W-C-006 | FRO/LRO/LPO、Pluggable/NPO/CPO/OIO和OSFP/QSFP/XPO属于三个不同维度，OCS属于网络拓扑层 | 分类框架 | Supported | 高 | medium | W-SRC-005 | 2026-09-21 | 2026-10-21 | 特定产品可能跨维度命名，但比较时仍需拆成信号处理、位置和接口密度 |
| W-C-007 | AI光互联母表应同时覆盖发射光源和高速接收探测器，并区分数据链与控制链电芯片 | 分类框架 | Partial | 高 | medium | W-SRC-005 | 2026-09-21 | 2026-10-21 | 某些集成产品会将功能合并，但底层功能不能遗漏 |
| W-C-008 | Foundry、PIC Die、EIC/PIC集成、Optical Engine和模块/系统是不同能力与商业层级 | 产业结构 | Supported | 高 | medium | W-SRC-005 | 2026-09-21 | 2026-10-21 | IDM或垂直整合厂商可跨层，但需分别核验能力与收入来源 |
| W-C-009 | 光子技术相关性不能单独证明公司属于AI数据中心光互联产业链 | 来源限制 | Supported | 高 | low | W-SRC-005 | 2026-09-21 | 2026-10-21 | 获得明确数据中心产品、客户和预算证据后可入池 |
