# AI集群光互联分类

## 十二层产业链

| 层级 | 核心产品/能力 | 关键投资问题 |
|---|---|---|
| 1. 光学材料/晶圆 | InP衬底/外延、TFLN/LNOI、硅光Foundry、光纤/保偏光纤 | 材料一致性、晶圆尺寸/良率、扩产周期、是否形成独立认证与利润池 |
| 2. 发射光源与接收探测 | DFB/DML、EML、CW Laser、VCSEL、频梳、多波长光源、ELS/ELSFP；高速PIN PD、APD、200G/lane GeSi PD、MPD | 发射端关注功率、线宽/噪声、寿命和ELS可维护性；接收端关注响应度、带宽、暗电流、饱和与工艺集成 |
| 3. PIC | SiPh、TFLN、SiPh-TFLN异质、MRM与OIO PIC | 带宽、VπL/驱动、电损耗、热敏感、面积、工艺兼容和量产良率 |
| 4. 高速电芯片 | DSP/CDR、Driver/TIA、Linear EIC、控制AFE、TEC/PMIC | 200G/lane信号完整性、是否去DSP、功耗、线性度和配套控制 |
| 5. 磁光/WDM/微光学 | 隔离器、环形器、AWG、TFF/Z-Block、Lens/PBS | 插损、尺寸、通道数、自动化装配和单模块价值量 |
| 6. FAU/Fiber/Connector | 1D/2D/PM FAU、MT/MPO/VSFF、PM Fiber、Fiber Shuffle/FMU | 高密耦合、插损、一致性、光纤管理、可维护性与自动化 |
| 7. 光电封装 | Laser/PIC/EIC/FAU、Optical Engine、CPO异构集成 | 光电热协同、主动对准、封装良率、返修与可靠性 |
| 8. 封装与测试设备 | Die/CoC/Wafer Test、贴装、主动对准、BERT、老化/AOI | KGD、晶圆级/系统级测试覆盖、节拍、精度和测试成本 |
| 9. Pluggable/LRO/LPO/XPO | 可插拔模块与线性/高密产品形态 | 功耗、成熟度、互操作、可维护性和供应链完备度 |
| 10. NPO/CPO | 光引擎靠近ASIC或与ASIC共封装，配套ELS与光纤管理 | 电走线缩短带来的收益是否覆盖封装、热、良率与维修成本 |
| 11. OIO | XPU旁Optical I/O Chiplet/Engine | 接口标准、封装集成、光源、良率和客户架构导入时点 |
| 12. OCS/Optical Fabric | MEMS、SiPh/SiN、AWGR和Topology Control | 端口数、插损、切换速度、调度软件、网络利用率和故障恢复 |

## 产品形态的三个正交维度

| 维度 | 演进/选项 | 主要问题 |
|---|---|---|
| 信号处理 | FRO → LRO → LPO | 模块侧DSP保留程度、功耗、主机端信号完整性、互操作与链路责任 |
| 光引擎位置 | Pluggable → NPO → CPO → OIO | 电走线距离、封装集成、热、良率、测试、维修和标准生态 |
| 模块/接口密度 | OSFP/QSFP → XPO | 面板密度、连接器/光纤管理、散热、可维护性和标准成熟度 |

OCS/Optical Fabric属于网络拓扑与调度层，不是模块演进线上的下一站。三个维度可交叉组合，也不是必然单向替代；距离、速率、成本、散热、互操作、可靠性和维护方式共同决定并存边界。

## 研究底表的关键拆分

- **SiPh链：** Foundry/工艺平台 → PIC设计与Die → EIC/PIC集成 → Optical Engine。
- **TFLN链：** 材料/LNOI → 工艺或IDM → 纯TFLN PIC → SiPh-TFLN混合集成。
- **MRM链：** 微环器件 → 热/波长控制 → Driver/EIC → WDM与激光 → OIO Engine。
- **高速电芯片：** 数据链为DSP/CDR/Driver/TIA/Linear EIC；控制链为EML/SiPh/ELS控制AFE、TEC Controller与Optical PMIC。
- **光纤连接：** 区分PM Fiber/PM FAU、1D/MT/90°/2D FAU、Fiber Shuffle与完整FMU；可拆卸/无源对准Fiber-to-PIC接口作为观察节点。
- **测试链：** Wafer-level → PIC/EIC/OE → CPO封装 → CPO系统级测试，覆盖KGD、主动对准、Burn-in与光学热管理。
