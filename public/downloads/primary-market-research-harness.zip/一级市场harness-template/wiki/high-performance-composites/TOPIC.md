# 高端制造用高性能复合材料

## Metadata

- industry_id：`high-performance-composites`
- topic_kind：`industry`
- aliases：高性能复合材料、航空复合材料、CFRP、CMC、AlSiC、结构铝基复材、光伏热场C/C
- scope：中国商业化与需求为主，全球技术和竞争作参照；正式方向按独立客户预算、终端用途、认证体系和利润池拆分
- geography：中国大陆需求与商业化；全球技术与竞争对标
- last_verified_at：`2026-08-02`
- source_cutoff：`2026-08-02`
- freshness_days：`60`
- next_review_due：`2026-10-01`
- status：`fresh`
- volatility：`high`
- source_verification：`verified`

## 可复用范围

- 包含：高端/航空级CFRP、航空发动机CMC、热管理AlSiC、结构/耐磨铝基复材、光伏热场C/C的行业级比较。
- 不包含：任何具体未上市项目的技术、客户、产能、团队、财务或投资结论。
- 相邻但不可直接复用：通用工业CFRP、航空制动C/C、航天热结构C/C、钛/镁/铜/镍基复材，需重建各自客户预算和竞争边界。

## 文件

- `taxonomy.md`
- `conclusions.md`
- `claims.md`
- `source-index.md`
- `updates/`
