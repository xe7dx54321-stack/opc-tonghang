# Wiki Source Index

| Source ID | 标题 | 机构 | 日期 | 链接 | 等级 | 用途 | 局限 |
|---|---|---|---|---|---|---|---|
| W-SRC-001 | 2024全球碳纤维复合材料市场报告 | 广州赛奥碳纤维/复材网 | 2025 | https://www.cnfrp.com/mobile/news/show-80296.html | B | 中国CFRP父行业数量与金额 | 行业估算，非官方统计 |
| W-SRC-002 | 2025全球碳纤维复合材料市场报告 | 广州赛奥碳纤维/复材网 | 2026 | https://www.cnfrp.com/quote/show.php?itemid=69753 | B | 中国CFRP数量变化 | 未取得同口径金额 |
| W-SRC-003 | 中简科技2025年年度报告 | 中简科技/巨潮资讯 | 2026-07-02 | https://static.cninfo.com.cn/finalpage/2026-07-02/1225405726.PDF | A | 高端碳纤维及织物毛利和认证 | 单一高端公司样本 |
| W-SRC-004 | 中复神鹰2025年年度报告 | 中复神鹰 | 2026-03-25 | https://pdf.dfcfw.com/pdf/H2_AN202603251820748615_1.pdf | B | 工业碳纤维毛利与供给压力 | 镜像链接；单一公司样本 |
| W-SRC-005 | 重点新材料首批次应用示范指导目录（2024年版） | 工业和信息化部 | 2023-12-22 | https://www.miit.gov.cn/cms_files/filemanager/1226211233/attach/202311/986ca73a44a047bdb744050ac2d36c97.pdf | A | CFRP和CMC政策相对支持 | 目录不代表订单 |
| W-SRC-006 | 火炬电子2025年年度报告 | 火炬电子/巨潮资讯 | 2026-03-31 | https://static.cninfo.com.cn/finalpage/2026-03-31/1225055912.PDF | A | CMC市场代理及陶瓷材料利润 | 陶瓷材料口径宽于CMC构件 |
| W-SRC-007 | GE Aerospace 2025 manufacturing investment | GE Aerospace | 2025-03-12 | https://www.geaerospace.com/news/press-releases/ge-aerospace-invest-nearly-1b-us-manufacturing-2025 | B | 全球CMC产业化与OEM投入 | 公司公告；非中国市场 |
| W-SRC-008 | Energy and AI | International Energy Agency | 2025-04-10 | https://www.iea.org/reports/energy-and-ai/energy-demand-from-ai | B | 高热流密度需求代理 | 不是AlSiC材料市场 |
| W-SRC-009 | 金博股份2025年年度报告 | 金博股份 | 2026-04-29 | https://vip.stock.finance.sina.com.cn/corp/view/vCB_AllBulletinDetail.php?id=12260712&stockid=688598 | B | 光伏热场C/C利润与减值 | 镜像入口；公司组合不等于行业 |
| W-SRC-010 | 天宜上佳2025年前三季度监管回复 | 天宜上佳/上交所 | 2025-11-29 | https://big5.sse.com.cn/site/cht/www.sse.com.cn/disclosure/listedinfo/announcement/c/new/2025-11-29/688033_20251129_LJ7O.pdf | A | 光伏碳碳收入、利用率和毛利 | 单一困境公司样本 |
