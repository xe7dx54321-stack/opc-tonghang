# Wiki Claims

| Claim ID | Reusable claim | Type | Status | Confidence | Volatility | Evidence | Last verified | Review due | Counterevidence |
|---|---|---|---|---|---|---|---|---|---|
| W-C-001 | 全部中国CFRP宽口径只能作为高端/航空级CFRP的父行业上限，不能直接作为其TAM | 事实+口径判断 | Supported | 中 | high | W-SRC-001,W-SRC-002 | 2026-08-02 | 2026-10-01 | 未来若出现独立高端应用统计可替代父行业代理 |
| W-C-002 | 高端资格型与通用工业型碳纤维利润池显著分化 | 事实+比较判断 | Partial | 中 | high | W-SRC-003,W-SRC-004 | 2026-08-02 | 仅为公司样本，不是行业平均 |
| W-C-003 | CMC已具备航空发动机产业化路径，但中国市场规模和独立供应商价值捕获仍不透明 | 判断 | Partial | 中低 | high | W-SRC-005,W-SRC-006,W-SRC-007 | 2026-08-02 | OEM可能捕获主要价值；陶瓷材料口径宽于CMC构件 |
| W-C-004 | 热管理AlSiC的需求逻辑成立，但下游算力或半导体增长不能直接换算材料渗透和TAM | 判断 | Partial | 中 | high | W-SRC-008 | 2026-08-02 | 真实design-in、材料价值量和替代路线胜率仍缺 |
| W-C-005 | 光伏热场C/C公开利润池已受价格战、低利用率和减值破坏 | 事实+判断 | Supported | 中高 | high | W-SRC-009,W-SRC-010 | 2026-08-02 | 航空制动及航天C/C不属于本Claim范围 |
