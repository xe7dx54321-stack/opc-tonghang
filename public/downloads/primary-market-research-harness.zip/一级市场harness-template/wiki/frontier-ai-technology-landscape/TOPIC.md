# 前沿AI技术演进与团队版图

## Metadata

- industry_id：`frontier-ai-technology-landscape`
- topic_kind：`technology-landscape`
- aliases：大模型前沿技术、Frontier AI、Agent技术、Agent Runtime、Sandbox、Agent Environment、持续学习、Experience Learning、RL Environment、World Model、VLA、Computer-use、AI Scientist、模型新架构
- scope：全球与中国前沿AI技术主线、热度迁移、未来演进、创业机会和团队Mapping；用于AI相关项目的技术方向定位，不用于替代具体行业市场、客户预算或项目判断
- geography：全球；中国单列
- last_verified_at：`2026-09-21`
- source_cutoff：`2026-09-21`
- freshness_days：`30`
- next_review_due：`2026-10-21`
- status：`review_due`
- volatility：`high`
- source_verification：`partial`

## 可复用范围

- 包含：前沿技术分类、技术演进关系、热度和创业窗口工作假设、全球/中国团队检索入口、关键反证与里程碑。
- 不包含：任何具体项目BP、访谈、经营数据、项目是否值得跟进的结论；不替代具体细分行业的市场规模、客户预算、竞争排名和项目证据。
- 相邻但不可直接复用：普通AI应用市场、算力产业链、机器人整机、语音客服、传感器等仍需匹配各自商业行业Topic。

## 使用规则

本Topic当前来自已提炼的研究会话，公开原始来源尚未逐项重建。可用于提出假设、识别替代路线和确定检索对象；团队进展、论文、融资、Benchmark和排序在进入项目证据矩阵前必须快速更新并打开原始来源。

## 文件

- `taxonomy.md`
- `conclusions.md`
- `theses.md`
- `technology-map.md`
- `claims.md`
- `source-index.md`
- `updates/`
