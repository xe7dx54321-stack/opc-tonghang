# 工作假设与证伪条件

| Thesis ID | 工作假设 | 当前置信度 | 关键证伪条件 | 项目研究含义 | 外部核验 |
|---|---|---|---|---|---|
| W-T-001 | 下一阶段主轴将从“能行动的Agent”迁移到“能从行动中学习的Agent” | 中高 | 大规模真实部署仍无法稳定产生Policy/Weight提升，或持续学习成本长期高于价值 | 重点检查Experience→Learning曲线，而非只看Agent Demo | partial |
| W-T-002 | 高价值RL Environment、Trajectory、Verifier可能成为Agent时代的数据基础设施 | 中高 | Frontier Labs全部内部构建且跨客户复用价值低，或AI生成环境完全替代第三方环境 | 检查环境真实性、可验证性、独占数据和客户复用 | partial |
| W-T-003 | Memory的长期价值会从存储/检索迁移到Skill、Policy和Weight Update | 中 | Memory长期只能改善上下文，无法稳定改变行为或学习 | 区分Vector DB包装与真正Learning Infrastructure | partial |
| W-T-004 | Agent Security/Identity/Governance将随Agent权限提升形成独立预算 | 中高 | Agent长期停留在只读辅助，企业不开放交易和生产权限 | 检查是否绑定现有安全预算和强制合规接口 | partial |
| W-T-005 | World Model估值将从生成质量转向Action-conditioned、长期一致性和Sim-to-Real | 高 | 视频生成指标持续主导采购，Policy提升难以独立复现 | 必须要求Policy uplift和现实任务闭环证据 | partial |
| W-T-006 | Open-ended Curriculum可能成为Environment的长期上层，而不是人工题库无限扩张 | 中低 | 自动生成任务缺乏真实性或出现Reward hacking，无法跨领域迁移 | 将Curriculum Engine作为远期期权，不提前当作成熟商业模式 | partial |
| W-T-007 | 中国的结构性机会更集中于Environment、Physical AI、World Model和工程闭环 | 中 | 缺少持续公开技术兑现，或核心能力仍依赖海外闭源模型和数据 | 区分大厂研究影响力与独立可投资项目供给 | partial |
| W-T-008 | Agent Runtime/Sandbox可能先于Continual Learning成为可独立采购的商业基础设施层 | 中 | Runtime能力被云平台或模型API免费吸收，企业不为隔离、工具执行和环境复现单独付费 | 区分商业产品、模型内部环境和研究Benchmark，核验生产调用与收费边界 | partial |

工作假设可以指导检索和尽调，但不得被复制为项目事实或评分证据。
