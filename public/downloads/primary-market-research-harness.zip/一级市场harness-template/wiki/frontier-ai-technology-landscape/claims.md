# 已验证事实与待核验主张

当前Topic尚未逐项重建公开原始来源，故不把会话中的论文、团队、融资或Benchmark写成“Supported”事实。下面只登记需要后续快速更新的主张边界。

| Claim ID | Reusable claim | Type | Status | Confidence | Volatility | Evidence | Last verified | Review due | Counterevidence |
|---|---|---|---|---|---|---|---|---|---|
| W-C-001 | 前沿AI研究可按八条技术主线形成投资研究分类 | classification | Partial | Medium | medium | W-SRC-001（仅认知来源） | 2026-09-21 | 立即补公开来源 | 技术边界持续融合，分类不可用于市场加总 |
| W-C-002 | 全球与中国团队可按 `technology-map.md` 建立首轮检索池 | mapping lead | Partial | Medium | high | W-SRC-001（仅认知来源） | 2026-09-21 | 立即补公开来源 | 团队归属、进展、融资和项目状态可能变化 |
| W-C-003 | Agent基础设施可按商业Runtime、模型内部Environment、研究Benchmark、Trajectory Data和Continual Learning分层 | classification | Partial | Medium-High | high | W-SRC-002（仅认知来源） | 2026-09-21 | 立即补公开来源 | 层级会融合，单一平台可能跨层；商业状态必须逐项核验 |

公开事实完成核验后，新增独立 `W-SRC-xxx` 并将对应Claim更新为 `Supported / Partial / Contradicted / Retired`。
