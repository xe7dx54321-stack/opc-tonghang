# 技术分类与演进框架

## 技术演进主轴

| 阶段 | 代表关键词 | 核心问题 | 下一阶段产生的新瓶颈 |
|---|---|---|---|
| Pretraining阶段 | Scaling、MoE、Long Context、RAG | 模型如何知道更多 | 知识并不等于推理和行动能力 |
| Reasoning阶段 | RLVR、Long CoT、Test-time Compute | 模型如何想得更深 | 推理长度不等于有效搜索，成本快速上升 |
| Agent阶段 | Tool Use、Computer-use、Memory、Workflow | 模型如何完成真实工作 | 长程可靠性、环境反馈、权限和经验浪费 |
| Learning Agent阶段 | Experience、Environment、Continual Learning、Trust | 模型如何从工作中持续变强 | Reward、遗忘、安全、开放环境与可验证性 |

## 八条前沿技术主线

| 优先级 | 技术主线 | 解决的问题 | 投资研究关注点 |
|---:|---|---|---|
| 1 | Experience-native / Continual Learning | 部署后模型冻结，真实交互经验被浪费 | Experience能否稳定转化为能力提升，旧能力是否退化 |
| 2 | Automated AI Research / Self-Improvement | AI研发仍依赖人类串行提出和验证实验 | 是否形成可复现的新算法/架构，而非只自动调参 |
| 3 | RL Environment / Experience Data / Verifier | Agent缺少可交互、可重置、可验证的训练场 | 环境真实性、任务生成、Reward、Verifier和数据闭环 |
| 4 | World Model / Action Model / Physical AI | 模型缺乏物理状态、未来演化和行动后果理解 | Action-conditioned、长期一致性、Sim-to-Real |
| 5 | Computer-use Specialist Model | 通用模型缺少专业软件和真实工作轨迹 | 专业轨迹数据、长任务成功率和企业工作流闭环 |
| 6 | Memory → Skill → Learning | Memory停留在检索和摘要，不能改变策略 | Episodic Memory能否沉淀为技能、Policy或权重更新 |
| 7 | New Reasoning Paradigm | 更多Token不等于更有效计算 | Adaptive Compute、Latent Reasoning、Recurrent Depth、搜索效率 |
| 8 | Data / Compute Efficiency & New Model Form | Frontier能力成本和架构路径受限 | Diffusion、低比特、稀疏路由、专用小模型与真实成本优势 |

## 远期弱信号

- Learning-to-Learn / Learned Adaptation Policy；
- Open-ended Curriculum / Generator–Solver co-evolution；
- Latent Agent Communication / Neural Agent Bus；
- Recurrent Depth / Dynamic Neural Computation；
- Proof-carrying Agent / Formal Verification；
- Agent Economy / Machine Markets。
