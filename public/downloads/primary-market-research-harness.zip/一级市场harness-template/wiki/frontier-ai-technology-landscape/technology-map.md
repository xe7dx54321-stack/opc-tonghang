# 全球与中国技术 Mapping

> 以下团队用于建立检索入口，来源于会话提炼，未在本次Promotion中逐项重建公开来源。任何公司状态、论文、融资、Benchmark、团队归属和优先级在项目使用前必须刷新。

## 全球 Mapping

| 技术主线 | 重点跟踪团队/项目 | 当前研究问题 | Mapping状态 |
|---|---|---|---|
| Experience / Continual Learning | Ineffable Intelligence、Oak Lab、Trajectory、River AI | 持续学习曲线、遗忘、Reward和生产Experience闭环 | 待公开来源复核 |
| Automated AI Research | Recursive Superintelligence、Core Automation、Discovery Loop、Aster | 自动提出、执行、验证实验及产生原创方法 | 待公开来源复核 |
| Environment / Experience Data | Mechanize、Markov、Prentis、CueBench、EdotEnv、Anchorhead | 高价值环境、专业轨迹、Verifier、任务生成 | 待公开来源复核 |
| Agent Runtime / Sandbox | 商业Runtime、隔离执行与环境编排厂商按项目重新检索 | 工具权限、隔离、环境复现、调用可靠性、生产规模和收费边界 | 待公开来源复核 |
| World / Action Model | General Intuition、AMI Labs及相关Physical AI团队 | Action-conditioned、长期一致性、Policy uplift | 待公开来源复核 |
| Alternative Architecture | Ndea、PrismML、Logical Intelligence、Elorian等 | Program Synthesis、低比特、EBM、视觉/Latent推理 | 待公开来源复核 |

## 中国 Mapping

| 技术主线 | 重点跟踪团队/项目 | 当前定位线索 | Mapping状态 |
|---|---|---|---|
| Experience / Agent Learning | ByteDance Seed、微软亚洲研究院、MemTensor | Experience Scaling、在线经验回流、Memory→Learning | 待公开来源复核 |
| RL Environment | Qwen、复旦AgentGym、ByteDance Seed | Environment Model、交互环境和Self-evolving Agent | 待公开来源复核 |
| Agent Runtime / Sandbox | 腾讯相关商业产品、阿里AgentRun、Kimi AgentEnv | 商业Runtime、模型内部环境和开源能力必须分层；生产规模与独立收费待核验 | 待公开来源复核 |
| Automated Research | 上海AI实验室InternScience、ByteDance Seed | Generation→Verification→Evolution和实验闭环 | 待公开来源复核 |
| World Model / Physical AI | 智元、流形空间、星海图、灵初、清华相关团队 | World Simulator、VLA/Action Model、Sim-to-Real | 待公开来源复核 |
| New Model Architecture | 人大高瓴/蚂蚁LLaDA、ByteDance Seed、微软亚洲研究院 | Diffusion LM、低比特、Latent Model | 待公开来源复核 |
| Computer-use | ByteDance UI-TARS及专业工作流团队 | Native GUI Model和真实交互轨迹 | 待公开来源复核 |
| Reasoning / Efficiency | DeepSeek及头部模型实验室 | Reasoning RL、Adaptive Compute、Agent Harness | 待公开来源复核 |

## 中国潜在机会空白

1. 独立Continual Learning / Experience-native Lab；
2. 独立Automated AI Research创业公司；
3. 专业Computer-use Experience Data；
4. 可面向多家模型公司的垂直RL Environment；
5. Memory → Skill → Policy/Weight Update的完整基础设施。

## 成熟度分层

| 层级 | 代表形态 | 不可直接外推的事项 |
|---|---|---|
| 商业Runtime/Sandbox | 面向客户的隔离执行、工具调用和环境编排产品 | 有产品不等于独立收费、规模部署或高留存 |
| 模型公司内部Environment | AgentEnv、内部工具环境和训练/评测基础设施 | 内部使用不等于可服务第三方市场 |
| 研究Environment/Benchmark | AgentWorld、AgentGym等研究或开源项目 | 论文/开源活跃不等于公司或商业产品 |
| Trajectory/Experience Data | 任务轨迹、反馈、Verifier与数据服务 | 数据量不等于可用于持续学习的质量、权利和复利 |
| Continual Learning | 经验进入Skill、Policy或Weight Update | 离线实验收益不等于线上稳定学习与经济价值 |

## 研究使用顺序

先用本表确定技术主线和候选团队，再打开论文、官网、代码仓库、官方Benchmark和融资原始披露完成更新；不得把本表直接转换为项目证据或公司排名。
