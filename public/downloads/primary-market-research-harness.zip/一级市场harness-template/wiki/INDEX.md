# 行业与技术知识库索引

> Wiki 沉淀公开来源支持、去项目化的行业共性结论，以及清晰标记来源、置信度和证伪条件的技术工作假设。项目 BP、访谈、客户名单、财务数据、融资信息和项目判断不得进入本目录；工作假设不得作为项目证据。

| Topic ID | 类型 | 主题 | 主要别名 | Scope 摘要 | Last verified | Source status | Freshness | Next review | Volatility | 路径 |
|---|---|---|---|---|---|---|---:|---|---|---|
| high-performance-composites | industry | 高端制造用高性能复合材料 | CFRP、CMC、AlSiC、结构铝基复材、光伏热场C/C | 中国商业化与需求为主；全球技术竞争参照；按独立客户预算拆分 | 2026-08-02 | verified | 60天 | 2026-10-01 | high | `wiki/high-performance-composites/` |
| ar-microled-image-source | industry | AR/智能眼镜 Micro LED 图像源器件 | LEDoS、Micro LED微显示、AR微显示图像源 | 图像源器件层；中国商业化与供应链为主，全球路线/终端/竞争参照；不含整机、波导、车载和光互连 | 2026-08-10 | verified | 60天 | 2026-10-09 | high | `wiki/ar-microled-image-source/` |
| ai-value-chain | industry | 人工智能价值链定位 | AI产业、模型供给 | 全球四层分类；不含正式排名、市场规模加总或项目判断 | 2026-09-14 | verified | 60天 | 2026-11-13 | high | `wiki/ai-value-chain/` |
| frontier-ai-technology-landscape | technology-landscape | 前沿AI技术演进与团队版图 | 大模型前沿、Agent、Agent Runtime、Sandbox、持续学习、RL Environment、World Model、VLA、Computer-use、AI Scientist | 全球/中国技术热点、演进、创业机会与团队Mapping；不替代具体商业行业分析 | 2026-09-21 | partial | 30天 | 2026-10-21 | high | `wiki/frontier-ai-technology-landscape/` |
| china-autonomous-ai-compute-stack | industry | 中国自主AI算力基础设施栈 | 国产AI算力、华为AI产业链、昇腾生态、DeepSeek×华为、SuperPoD、Scale-out、UBoE、HBM、CXL、Grid-to-Chip、全栈可观测 | 中国AI数据中心/超节点；从工作负载到计算、Memory/Data、Scale-up/Scale-out、整机、供电、液冷、系统软件与RAS；不等同于固定华为BOM | 2026-09-21 | partial | 30天 | 2026-10-21 | high | `wiki/china-autonomous-ai-compute-stack/` |
| ai-cluster-optical-interconnect | industry | AI集群光互联产业链 | 光互联、800G、1.6T、3.2T、SiPh、TFLN、MRM、LPO、NPO、CPO、OIO、OCS、ELS、PD、FAU、FMU | AI数据中心内Scale-out/Scale-up、机柜/板级、封装内和芯片旁光互联；含发射/接收、数据/控制链；不含AR微显示、激光雷达与完整骨干网市场 | 2026-09-21 | partial | 30天 | 2026-10-21 | high | `wiki/ai-cluster-optical-interconnect/` |

## 查找规则

- 每个项目先匹配商业行业Topic；前沿科技项目再按技术路线和学习/部署功能并行匹配technology-landscape Topic。
- 商业行业Topic用于市场、客户预算、产业链和竞争；技术版图Topic用于技术方向、替代路线、全球/中国Mapping和研究假设，不能互相替代。
- 按各Topic自己的Freshness检查；`partial/unverified`或`review_due`必须先快速补原始来源再用于事实判断，重大事件可提前触发。
- 找不到同 Scope 主题时创建新 Topic，不得为了复用而扩大旧主题边界。

