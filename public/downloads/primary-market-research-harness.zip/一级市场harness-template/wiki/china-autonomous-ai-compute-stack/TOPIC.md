# 中国自主AI算力基础设施栈

## Metadata

- industry_id：`china-autonomous-ai-compute-stack`
- topic_kind：`industry`
- aliases：中国自主算力产业链、国产AI算力产业链、华为AI产业链、昇腾生态、DeepSeek×华为算力、AI超节点、SuperPoD、灵衢、UnifiedBus、UBoE、Scale-out、HBM、Memory Hierarchy、CXL、Grid-to-Chip、Chip-to-Outdoor、全栈可观测
- scope：以中国AI数据中心和超节点为终端用途，从模型/Agent工作负载向计算、内存、数据基础设施、板级电互联、Scale-up/Scale-out网络、SuperPoD整机、光互联、供电、液冷、系统软件与全栈可观测传导；半导体侧覆盖EDA/IP、HBM/存储、先进封装、高速电芯片与电源半导体；不等同于完整晶圆制造/半导体设备行业，也不把华为某代产品BOM视为全行业固定BOM
- geography：中国商业化与供应链为主；全球技术路线与标准作参照
- last_verified_at：`2026-09-21`
- source_cutoff：`2026-09-21`
- freshness_days：`30`
- next_review_due：`2026-10-21`
- status：`review_due`
- volatility：`high`
- source_verification：`partial`

## 可复用范围

用于新项目的行业定位、价值链拆分、工作负载到基础设施的需求传导、相邻方向识别和公开来源检索规划。材料中的具体供应商、产品参数、市场份额、产能、客户关系和路线时间表未经本次逐项公开源核验，不能直接作为项目事实、评分证据或投资结论。

光互联的详细产业链见 `../ai-cluster-optical-interconnect/`；Agent/Learning Infrastructure的技术演进见 `../frontier-ai-technology-landscape/`。

## 文件

- taxonomy.md
- workload-transmission-map.md
- conclusions.md
- theses.md
- company-leads.md
- verification-priorities.md
- claims.md
- source-index.md
- updates/
