# 来源索引

| ID | 标题 | 发布者/来源 | 日期 | 纳入日期 | 定位 | 等级 | 限制 |
|---|---|---|---|---|---|---|---|
| W-SRC-001 | 华为AI产业链初步研究报告 | 用户提供的基金研究材料 | 未标明 | 2026-09-21 | 原始文件SHA256见Knowledge Inbox | D | 二次研究；具体份额、BOM、供应商和会议口径未逐项给出可打开原始来源 |
| W-SRC-002 | DeepSeek × 华为自主算力产业链阶段性研究汇总 | 用户提供的阶段性研究材料 | 2026-09-12 | 2026-09-21 | 原始文件SHA256见Knowledge Inbox | C/D | 分类完整，但大量事实只汇总引用“官网/年报/产业活动”，缺少逐条链接；公司状态需刷新 |
| W-SRC-003 | 半导体与光技术研究材料提炼 | Harness Knowledge Inbox | 2026-09-21 | 2026-09-21 | `knowledge-inbox/research-materials/2026-09-21-semiconductor-optics/distillation.md` | D | 去项目化提炼，不是外部证据 |
| W-SRC-004 | DeepSeek华为产业链图谱 | 用户与ChatGPT研究会话 | 截至2026-09-21 | 2026-09-21 | `knowledge-inbox/chat-sessions/6aa4be88-04c8-83ea-a78b-b1d4a99ec985/` | D | 分页闭合但至少6条超长回复局部截断；引用原文无法完整恢复；只允许用于分类、方法、工作假设和检索线索 |

公开事实复用前，应补华为/Ascend/UnifiedBus/OceanStor/CANN等官方资料、产业标准、公司公告和产品手册，并在本表新增来源。
