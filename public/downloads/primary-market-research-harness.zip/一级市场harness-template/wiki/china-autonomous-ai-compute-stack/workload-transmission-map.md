# 工作负载到基础设施的传导图

| 工作负载变化 | 一阶系统压力 | 优先映射的基础设施 | 关键反向力量 |
|---|---|---|---|
| MoE与Expert Parallel | All-to-All通信、负载不均 | HBM、Scale-up、UnifiedBus/灵衢、Scale-out、光互联 | 稀疏激活、路由优化与通信压缩可能降低单Token通信量 |
| 推理调用量与低API价格 | Token吞吐、集群规模、峰谷调度 | NPU/XPU、供电、液冷、网络、推理平台 | 单Token效率和利用率改善降低单位资源消耗 |
| 长上下文 | KV容量、带宽、复用和时延 | HBM、DDR/MRDIMM、CXL、SSD、KV Cache基础设施 | 压缩、稀疏注意力、分层缓存降低单位上下文成本 |
| Agent长任务 | 持续上下文、状态保存、工具调用和故障恢复 | Agent Memory、存储、Sandbox/Runtime、可观测与RAS | 更强模型、工具编排和缓存复用缩短任务链 |
| Coding/Computer-use | 大量工具调用、隔离执行和环境复现 | Sandbox、Environment、Runtime、镜像/存储、Telemetry | 端侧执行或平台集成压缩独立基础设施价值 |
| 私有部署与国产适配 | 异构迁移、兼容和性能损失 | CANN/编译器、Kernel、集合通信、调度、MaaS | 标准化接口和模型压缩降低迁移工作量 |
| Continual/Experience Learning | 轨迹留存、Verifier、训练回流 | Memory、Trajectory Data、RL Infrastructure、存储与训练平台 | 高质量经验稀缺、回流收益不稳定或合规限制 |

## 使用规则

需求预测应比较“单位任务资源消耗下降”与“任务数量、时长、并发和复杂度增长”的净效应；不得用单一效率改进直接推出总需求下降，也不得用Token增长直接推出所有硬件同步增长。

