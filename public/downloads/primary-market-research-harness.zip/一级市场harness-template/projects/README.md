# Projects

真实研究项目由 `$project-setup` 创建在本目录下。

不要直接修改或删除用户放入 `inputs/` 的原始材料。每个项目使用自己的 `PROJECT.md`、输入、输出、证据和审核目录，不同项目之间不得共享 Gate、证据状态或管理层口径。`INDEX.md` 只用于实体发现，不是全局 active project。

示例：

```text
projects/acme-ai/
├─ PROJECT.md
├─ inputs/
│  ├─ bp/
│  ├─ research/
│  ├─ interviews/
│  ├─ financial/
│  ├─ commercial/
│  ├─ technical/
│  ├─ legal-ip/
│  └─ other/
├─ outputs/
│  ├─ industry/
│  ├─ project/
│  └─ investment/
├─ evidence/
├─ reviews/
└─ notes/
```

新 session 只读取 `projects/INDEX.md`。只有当前对话根据上传材料或明确项目名选定项目后，才读取该项目正文。跨项目行业复用只能通过 `wiki/`。
