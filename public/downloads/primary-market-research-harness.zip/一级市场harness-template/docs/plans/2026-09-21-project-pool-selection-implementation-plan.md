# 项目池择优功能实施计划

**目标：** 在不改变现有单项目研究流程的前提下，增加低预算、偏好感知、可审计的跨项目择优能力。

**架构：** 单项目流程在重要 Gate 后生成一张偏好中性的标准项目决策卡；项目池择优任务先读取索引和卡片完成投资上限筛选，再只对 Top-K 定向重读关键报告和证据。择优结论由独立 reviewer 检查候选完整性、阶段适配、证伪逻辑、用户偏好和一周验证任务。

**技术栈：** Markdown、Codex Skills、TOML Agent 配置、PowerShell 验证脚本。

---

## 任务一：定义项目池数据契约

- 新增 `portfolio/INDEX.md`、`portfolio/cards/`、`portfolio/runs/`。
- 新增项目决策卡、决策任务书、项目池择优报告模板。
- 新增项目池择优方法论，固化投资上限测试、早期/中后期分流、证伪时间结构、一票否决和一周验证规则。

验证：模板和索引存在，字段能覆盖不同研究成熟度的项目。

## 任务二：增加两个 Skills

- 新增系统 Skill：`project-decision-card`。
- 新增业务 Skill：`project-pool-selection`。
- 同步写入 `evolution/runtime-skill-source/` 与 `.agents/skills/`。
- 更新 Evolution 校验和 Runtime 同步名单。

验证：使用 skill-creator quick validator 检查两个 Skill；Evolution source 与 Runtime 无 drift。

## 任务三：增加独立复核

- 新增 `.codex/agents/portfolio-reviewer.toml`。
- 复核候选漏选、阶段错配、乐观上限滥用、不可证伪叙事、一票否决、用户偏好和验证问题可执行性。

验证：Harness 结构校验识别第三个自定义 Agent。

## 任务四：接入主流程

- 更新 `AGENTS.md`：增加项目池模式、跨项目读取白名单、Skill 路由、输出和质量门。
- 更新 `WORKFLOW.md`：增加独立的项目池择优工作流，不把它串成单项目的新阶段。
- 更新 `README.md`：增加自然语言入口、预算模式和目录说明。

验证：原单项目流程顺序不变，项目池模式只在用户明确要求横向择优时触发。

## 任务五：增加验证与回归

- 新增 `scripts/validate-portfolio.ps1`。
- 新增 `scripts/tests/test-portfolio-validation.ps1`，覆盖有效卡片、缺字段卡片和索引不一致。
- 更新 `validate-harness.ps1`、`validate-all.ps1`、`validate-evolution.ps1` 和 `sync-runtime-skills.ps1`。

验证：项目池测试、Harness 校验、Evolution 校验及现有项目回归全部通过。
