# Lightweight Primary-Market Research Harness Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a repo-native Codex harness that starts from an uploaded BP, guides interactive or autonomous research, delegates bounded work to two sub-agents, and produces evidence-traceable Markdown artifacts.

**Architecture:** The active Codex session is the orchestrator. Durable behavior lives in `AGENTS.md`, stage methods live in eight repo Skills, two project-scoped custom agents provide parallel research and independent review, and human-readable Markdown files hold project state and evidence.

**Tech Stack:** Codex `AGENTS.md`, `.codex/config.toml`, project-scoped agent TOML, repo Skills under `.agents/skills`, Markdown templates.

---

### Task 1: Root orchestration

**Files:**
- Create: `AGENTS.md`
- Create: `WORKFLOW.md`
- Create: `README.md`
- Create: `.codex/config.toml`

**Steps:**
1. Define the active Codex session as the research director.
2. Define S0-S6 workflow, interactive gates, Goal behavior, evidence rules, and canonical file ownership.
3. Keep the startup path usable from a newly opened Codex session.
4. Verify all stage and output paths agree.

### Task 2: Custom agents

**Files:**
- Create: `.codex/agents/research-worker.toml`
- Create: `.codex/agents/investment-reviewer.toml`

**Steps:**
1. Use the current top-level custom-agent schema.
2. Make both roles read-only and narrow.
3. Require structured returns to the parent; prohibit direct canonical writes.
4. Verify required `name`, `description`, and `developer_instructions` fields.

### Task 3: Repo Skills

**Files:**
- Create: `.agents/skills/<skill>/SKILL.md`
- Create: `.agents/skills/<skill>/agents/openai.yaml`

**Skills:**
- `project-setup`
- `bp-segment-screen`
- `industry-project-research`
- `diligence-design`
- `material-analysis`
- `investment-verdict`
- `investment-memo`
- `evidence-review`

**Steps:**
1. Initialize every Skill using the system skill initializer.
2. Replace boilerplate with concise imperative workflows.
3. Give every description clear positive triggers and scope boundaries.
4. Verify frontmatter and UI metadata.

### Task 4: Methods and templates

**Files:**
- Create: `references/research-framework.md`
- Create: `references/evidence-standard.md`
- Create: `references/investment-rubric.md`
- Create: `templates/PROJECT.md`
- Create: `templates/01-segment-map.md`
- Create: `templates/02-industry-research.md`
- Create: `templates/03-dd-checklist.md`
- Create: `templates/04-material-update.md`
- Create: `templates/05-verdict.md`
- Create: `templates/06-investment-memo.md`
- Create: `templates/evidence-matrix.md`
- Create: `templates/source-index.md`
- Create: `projects/README.md`

**Steps:**
1. Keep detailed business rubrics outside `AGENTS.md`.
2. Use stable IDs for questions, claims, evidence, sources, and requests.
3. Make every template useful to humans without JSON tooling.
4. Verify every Skill points to real references and templates.

### Task 5: Validation and smoke test

**Steps:**
1. Run the bundled Skill validator on all eight Skills.
2. Parse both custom-agent TOML files.
3. Parse `.codex/config.toml`.
4. Search for TODO placeholders and broken relative paths.
5. Compare the implemented tree with the documented tree.
6. Simulate the startup decision for an empty `projects/` directory.

