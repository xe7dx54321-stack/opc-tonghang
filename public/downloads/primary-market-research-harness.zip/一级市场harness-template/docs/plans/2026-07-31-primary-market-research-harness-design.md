# 一级市场行业与项目研究 Harness：架构设计与实施路线图

> **状态说明：** 本文保留为长期完整版架构参考。当前已采用轻量 v0.2 实现，运行入口和实际文件结构以根目录 `README.md`、`AGENTS.md`、`WORKFLOW.md` 及 `2026-07-31-lightweight-harness-implementation-plan.md` 为准。完整版中的大量 Agent、Skills、Schema 和 Hooks 不属于当前 MVP。

> 版本：v0.1  
> 日期：2026-07-31  
> 目标环境：Codex App / CLI / IDE，项目级 `AGENTS.md`、Skills、自定义 Sub-agents  
> 当前假设：先服务单个投资团队；本地文件为事实源；中文为主要输出语言；后续可接搜索、企业知识库和文档系统。

---

## 1. 结论先行

建议把这套 Harness 定义为一套“证据驱动、阶段门控制、可中断恢复”的投资研究操作系统，而不是一组串行 Prompt。

它由五层组成：

1. **Workflow 状态机**：定义 S0-S6 阶段、进入/退出条件、人工确认和自动 Goal 模式。
2. **Canonical Artifacts（标准工件）**：把项目范围、核心问题、主张、证据、矛盾、缺口、结论和用户确认写入结构化文件。
3. **Orchestrator + Sub-agents**：主 Agent 负责拆解、调度、阶段门和合并；Sub-agent 只做窄而独立的研究任务。
4. **Business Skills + System Skills**：业务 Skill 提供投资研究方法，系统 Skill 保证状态、证据、引用、版本和格式正确。
5. **Deterministic Scripts / Evals**：能用程序确定的事情不用模型猜，例如 Schema 校验、文件哈希、覆盖率计算、重复材料检测和报告渲染。

首版不建议直接做成复杂 Web 平台，也不建议为每个行业维度创建一个永久 Agent。先做 repo-native Harness：用户把材料放入 case 目录，在 Codex 中发起交互式流程或 Goal 流程，Codex 产出可审阅的 Markdown、YAML 和 JSONL 文件。等业务方法和模板稳定后，再封装为 Plugin，并通过 MCP 接外部数据库、文档库和投研系统。

## 2. 三种实现路径与推荐

| 路径 | 描述 | 优点 | 缺点 | 结论 |
|---|---|---|---|---|
| A. Prompt-centric | 一个主 Prompt 串行完成全部步骤 | 最快验证想法 | 难恢复、难追溯、易上下文漂移、无法严格记录确认 | 只用于概念验证 |
| B. Artifact-centric Harness | 状态机、工件、Skills、Sub-agents、校验脚本均在 repo 内 | 可审阅、可复跑、低基础设施成本、最适合 Codex | 需要先设计 Schema 和目录规范 | **推荐 MVP** |
| C. Service / Platform | Web UI、数据库、队列、权限、检索服务、审计后台 | 多人协作和治理能力强 | 过早平台化，开发和运维成本高 | 方法稳定后再做 |

推荐按 **B → B+Plugin/MCP → C** 演进。早期最大风险不是并发量，而是研究方法不稳定、结论不可追溯、Agent 之间口径不一致。文件型架构最适合快速迭代这些核心问题。

## 3. 设计原则

### 3.1 不可妥协原则

- **结论必须有证据**：最终报告中的事实性主张必须关联至少一个 `evidence_id`；没有证据必须标为假设、待验证或管理层口径。
- **区分事实、推断和判断**：三类内容在工件中分别标记，不能把推断写成事实。
- **不伪造用户确认**：交互模式必须取得用户确认；Goal 模式只能记录 `auto_approved_by_policy`，不能写成 `user_approved`。
- **输入材料只读**：原始 BP、补充材料、访谈纪要不得被覆盖；解析结果和衍生工件另存。
- **矛盾不能被平均掉**：冲突证据进入 contradiction register，由主 Agent 显式处理。
- **证据不足时降级**：不能为了“给答案”而补齐事实；必须降低结论等级并给出需要补证的条件。
- **Agent 不共享隐性记忆**：跨阶段状态只通过标准工件传递。
- **并行只用于独立任务**：相互依赖的判断按顺序执行；避免多个 Agent 同时写同一个 canonical 文件。

### 3.2 Agent、Skill、Script 的边界

| 概念 | 应负责 | 不应负责 |
|---|---|---|
| Agent | 角色、目标、任务拆分、研究判断、独立复核 | 保存唯一状态、承担所有确定性校验 |
| Skill | 可重复的方法、决策规则、输入输出约定、模板 | 长期持有项目状态、冒充外部数据源 |
| Script | Schema、哈希、评分、转换、索引、渲染等确定性操作 | 开放式行业判断和投资判断 |
| MCP / Connector | 外部实时数据、私有系统、权限受控动作 | 业务研究方法本身 |
| `AGENTS.md` | 仓库级永久规则、路由规则、验证要求 | 塞入所有行业知识和长篇模板 |

## 4. 完整 Workflow

### 4.1 状态机总览

```mermaid
flowchart TD
    U["用户上传 BP"] --> S0["S0 Intake：建档、解析、质量检查"]
    S0 --> S1["S1 细分筛选：行业图谱 → 项目定位"]
    S1 --> G1{"G1 用户确认<br/>细分、边界、比较集"}
    G1 -->|修改| S1
    G1 -->|通过| S2["S2 完整行业研究<br/>形成核心判断要素"]
    S2 --> G2{"G2 用户确认<br/>核心问题与初步判断"}
    G2 -->|修改| S2
    G2 -->|通过| S3["S3 尽调设计<br/>材料清单、访谈清单、后续建议"]
    S3 --> G3{"G3 用户确认<br/>尽调范围与优先级"}
    G3 -->|修改| S3
    G3 -->|通过| W["等待补充材料 / 访谈"]
    W --> S4["S4 增量材料摄取<br/>解析、去重、归档、映射"]
    S4 --> L["S5 小 Loop<br/>抽取→证据链接→冲突检查→覆盖率"]
    L --> Q{"关键判断要求是否满足？"}
    Q -->|否，仍可补证| R["生成最小补证请求<br/>下一轮材料/访谈问题"]
    R --> S4
    Q -->|否，已无法补证| D["降级结论<br/>风险 + 条件 + 条款建议"]
    Q -->|是| V["形成最终投资判断"]
    D --> G5{"G5 用户确认"}
    V --> G5
    G5 -->|要求复核| L
    G5 -->|通过| S6{"S6 是否出投资报告？"}
    S6 -->|是| M["IC / 投资报告"]
    S6 -->|否| END["归档研究包"]
    M --> END

    GOAL["Goal 模式：自动跑 S0-S3"] -.-> S0
    GOAL -. "中间门由策略自动放行<br/>最终明确披露假设" .-> S3
```

### 4.2 各阶段输入、动作、输出和 Gate

| 阶段 | 核心问题 | 主要动作 | 标准输出 | 退出条件 |
|---|---|---|---|---|
| S0 Intake | 材料是否可读、项目是什么、研究任务是什么 | 建 case、解析 BP、提取公司/产品/融资信息、标注解析问题 | `case.yaml`、`bp-extract.md`、`document-index.jsonl`、`intake-issues.md` | BP 可读；项目身份和研究目的有最小定义 |
| S1 细分筛选 | 项目究竟属于哪个细分市场，边界在哪里 | 大行业拆树、价值链定位、相邻赛道和替代方案映射、项目落点 | `sector-map.md`、`segment-candidates.yaml`、`project-positioning.md` | 选定 primary segment、adjacent segments、排除范围 |
| G1 | 用户是否认可研究边界 | 提供 2-3 个候选口径和影响 | `approvals/gate-01.yaml` | `approved` 或 Goal 策略放行 |
| S2 行业研究 | 哪些行业和项目要素决定投资结果 | 市场、增长、需求、价值链、竞争、技术、监管、商业模式、单位经济、退出环境研究 | `industry-thesis.md`、`core-questions.yaml`、`claim-register.jsonl`、`evidence-ledger.jsonl`、`risk-register.yaml` | 每个核心要素有状态、证据和待验证项 |
| G2 | 核心问题和初步判断是否对 | 展示结论、反证、低置信度点和建议聚焦项 | `approvals/gate-02.yaml` | 用户确认核心判断框架 |
| S3 尽调设计 | 最少补什么材料才能改变判断 | 从证据缺口反推材料、数据字段、访谈对象和问题；按决策价值排序 | `dd-checklist.md`、`material-request.md`、`interview-guide.md`、`next-step-recommendation.md` | 清单可执行且每一项关联核心问题 |
| G3 | 尽调投入和优先级是否合理 | 明确必须项、重要项、可选项 | `approvals/gate-03.yaml` | 用户确认或修改尽调范围 |
| S4 增量材料 | 新材料改变了哪些判断 | 文档解析、实体/口径归一、表格抽取、去重、版本比较、访谈观点抽取 | 更新 `document-index`、`evidence-ledger`、`claim-register`；生成 `delta-report.md` | 新证据已完成映射和质量评级 |
| S5 判断 Loop | 是否达到可下结论的证据标准 | 核心问题覆盖、冲突处理、压力测试、红队复核；生成最小补证集 | `coverage-report.md`、`contradictions.yaml`、`open-questions.md`、`verdict.md`、`terms.md` | 得出 A/B/C 级结论或进入下一轮 |
| G5 | 用户是否接受结论和剩余不确定性 | 展示结论、证据强度、尚未解决风险和敏感条款 | `approvals/gate-05.yaml` | 确认、退回或要求专题复核 |
| S6 可选报告 | 如何形成可投委会审阅的完整材料 | 组装项目摘要、行业、商业、财务、风险、估值、条款和附件 | `investment-memo.md` / `.docx` / `.pdf` | 全部重大主张通过引用校验 |

### 4.3 S1：大行业细分筛选的建议方法

细分不是从单一行业标签开始，而是并行使用五个维度：

1. **客户和使用场景**：谁购买、谁使用、解决什么任务。
2. **产品/技术形态**：软硬件、交付方式、关键技术路线。
3. **价值链位置**：上游要素、中游产品、下游渠道或服务。
4. **商业模式**：一次性、订阅、耗材、交易抽佣、项目制。
5. **竞争和预算来源**：客户从哪个预算池付款，真正替代的是什么。

输出至少三个口径：

- `primary_segment`：后续研究主边界；
- `adjacent_segments`：需要纳入竞争、增长或协同分析的相邻市场；
- `excluded_segments`：看似相近但经济模型不同的市场。

G1 不只问“行业分类对不对”，而要问：“如果采用这个口径，会比较哪些公司、使用哪些市场规模、忽略哪些需求？”这样用户确认的是研究边界及其后果。

### 4.4 S2：核心判断要素

默认核心要素建议为：

| 维度 | 典型判断问题 |
|---|---|
| 市场定义 | 市场边界是否和客户预算、购买行为一致？ |
| 需求真实性 | 痛点是否高频、刚性、付费且可验证？ |
| 市场规模与增长 | Bottom-up SAM 是否足够大；增长由什么驱动？ |
| 价值链与利润池 | 价值和利润集中在哪里，项目能否取得合理份额？ |
| 竞争与替代 | 直接、间接和潜在进入者是谁；竞争是否结构性恶化？ |
| 产品和技术 | 产品成熟度、性能边界、路线风险、量产/交付难度如何？ |
| 商业模式 | 收入确认、复购、毛利、回款和规模经济是否成立？ |
| GTM | 客户获取、销售周期、渠道依赖、交付成本是否可扩张？ |
| 护城河 | 数据、网络、品牌、渠道、成本、专利或监管壁垒是否真实？ |
| 团队和组织 | 创始团队是否与当前阶段匹配，关键人风险如何？ |
| 财务与单位经济 | 增长质量、贡献毛利、现金消耗、资金需求是否健康？ |
| 监管与合规 | 准入、数据、知识产权、环保、行业政策是否影响生存？ |
| 融资与估值 | 本轮价格、稀释、后续融资、退出路径是否合理？ |
| 下行情景 | 最关键假设失败时损失如何，是否有可保护的条款？ |

并非每个项目都要等权。S2 必须输出一个 `core-questions.yaml`，为每个问题标记：

- `criticality`: fatal / critical / important / optional
- `direction`: 支持什么、反对什么
- `decision_weight`: 0-100
- `current_status`: supported / partial / contradicted / missing
- `required_evidence`: 满足判断所需的证据类型
- `owner_stage`: 应在哪个阶段解决

### 4.5 S3：尽调清单不是通用 Checklist

尽调项必须由 `核心问题 → 当前证据 → 缺口 → 请求材料 → 可能改变的决策` 反向生成。

每个请求项至少包含：

```yaml
request_id: MR-012
question_id: CQ-07
priority: must_have
requested_item: 最近24个月按客户和产品拆分的月度收入及回款明细
why_it_matters: 验证收入集中度、复购和回款质量
expected_format: xlsx
acceptance_criteria:
  - 可与审计/银行流水抽样勾稽
  - 客户名称可匿名但需保持唯一标识
decision_if_missing: 将收入质量结论降为低置信度
```

优先级建议：

- **P0 / 必须项**：缺失会导致不能形成结论或触发否决风险；
- **P1 / 重要项**：显著改变估值、条款或持仓建议；
- **P2 / 增强项**：提高置信度，但不阻断判断。

### 4.6 Goal 自动模式

Goal 模式用于自动跑完 S0-S3，适合“先拿到行业要点、尽调清单和下一步建议”。建议使用 `goal.yaml` 明确边界：

```yaml
goal_id: goal-20260731-001
mode: auto_s0_s3
objective: 形成行业要点、项目定位、核心问题和尽调清单
case_id: demo-company
decision_context: A轮少数股权投资
geography: 中国
time_horizon_years: 5
source_cutoff: 2026-07-31
gate_policy:
  s1: auto_approve_with_assumptions
  s2: auto_approve_with_assumptions
  s3: stop_and_present
ambiguity_policy: choose_recommended_and_record_alternatives
quality:
  require_citations: true
  max_unresolved_fatal_questions: 0
outputs:
  - executive_sector_brief
  - core_questions
  - dd_checklist
  - next_step_recommendation
```

规则：

- 自动放行要写 `approved_by: policy`，并保存当时的 scope hash；
- 遇到公司身份不明、BP 不可读、核心行业口径会造成方向相反等重大歧义时仍应暂停；
- Goal 结束时单独输出 `assumptions-and-limitations.md`；
- 一键模式不应自动跨越 S3 去做最终投资结论，除非补充材料已存在且 Goal 明确授权。

## 5. 证据系统与降级判断

### 5.1 Claim–Evidence 模型

```mermaid
erDiagram
    CASE ||--o{ DOCUMENT : contains
    DOCUMENT ||--o{ EVIDENCE : yields
    CORE_QUESTION ||--o{ CLAIM : frames
    CLAIM }o--o{ EVIDENCE : supported_by
    CLAIM ||--o{ CONTRADICTION : may_have
    CORE_QUESTION ||--o{ DD_REQUEST : creates
    GATE ||--|| APPROVAL : records
    VERDICT ||--o{ CLAIM : relies_on

    EVIDENCE {
      string evidence_id
      string document_id
      string locator
      string evidence_type
      string source_tier
      string independence
      string freshness
      string directness
      string confidence
    }
    CLAIM {
      string claim_id
      string question_id
      string text
      string statement_type
      string status
      string materiality
      string confidence
    }
```

### 5.2 证据分层

| 层级 | 例子 | 默认权重 |
|---|---|---:|
| A：原始、可核验、相对独立 | 审计报告、合同与回款、监管文件、原始客户数据、专利/检测报告 | 1.0 |
| B：高质量二手或外部佐证 | 公司公告、行业协会、权威数据库、专家/客户交叉访谈 | 0.8 |
| C：管理层材料或单一访谈 | BP、管理层口径、内部预测、未交叉验证的客户说法 | 0.5 |
| D：弱信号或推断 | 媒体转述、营销材料、匿名网络信息、模型估计 | 0.2 |

证据质量还需分别考虑：

- **Directness**：是否直接回答该 Claim；
- **Independence**：是否独立于项目方；
- **Freshness**：是否仍适用于当前市场；
- **Consistency**：是否与其他证据一致；
- **Coverage**：样本或时间范围是否足够。

总分只能辅助排序，不能替代一票否决项。核心问题的证据质量必须单独展示。

### 5.3 结论等级

建议采用可配置的三级结论，而非简单“投/不投”：

| 等级 | 默认门槛 | 允许输出 |
|---|---|---|
| A：Evidence-supported | critical 问题覆盖率 ≥ 80%，整体加权覆盖 ≥ 70%，无未解决 fatal red flag | 明确的倾向性结论、关键条件、主要敏感性 |
| B：Conditional / Provisional | critical 覆盖 50%-79%，或关键证据主要来自非独立来源 | 条件性结论；列明补证条件、价格/结构约束和保护条款 |
| C：Insufficient evidence | critical 覆盖 < 50%，或存在未解决 fatal 冲突 | 不形成强结论；只给风险边界、待补证和“若必须推进”的条款建议 |

默认阈值只是 Harness 的研究治理规则，应在 `config/rubrics/evidence-thresholds.yaml` 中按机构策略调整。条款建议必须提示由专业律师和交易团队复核。

### 5.4 S5 小 Loop

每轮固定执行：

1. **Ingest**：登记新文档、版本和访问日期；
2. **Extract**：抽取事实、数字、观点和限定条件；
3. **Normalize**：统一公司、产品、时间、币种、客户和指标口径；
4. **Link**：把新证据关联到 Claim 和核心问题；
5. **Challenge**：寻找反证、矛盾、样本偏差和管理层叙事漏洞；
6. **Score**：重新计算覆盖率，但保留重大问题的人工判断；
7. **Decide**：达到门槛则出结论，否则生成“最小补证集”；
8. **Gate**：用户确认继续补证、接受降级结论或停止。

建议默认最多 3 轮；超过 3 轮仍没有显著提高关键问题覆盖率时，提示“信息获取能力本身可能构成风险”，避免无限循环。

## 6. Sub-agent 规划

### 6.1 主 Agent

主线程角色：`research_director`，通常不需要定义成 Sub-agent 文件，而由根 `AGENTS.md` 和主 Skill 驱动。

职责：

- 读取 `case.yaml` 和 `state.yaml`；
- 选择工作模式，拆分任务和分配 Agent；
- 决定哪些任务可以并行；
- 合并草稿为 canonical artifacts；
- 执行 Gate、记录用户选择；
- 处理 Agent 分歧；
- 保证最终结论满足证据和引用要求。

### 6.2 推荐的项目级自定义 Agent

首版建议 8 个核心 Agent，3 个可选 Agent。不要一次全部启动，而是按阶段调度。

| Agent | 核心职责 | 运行阶段 | 权限建议 | 主要产物 |
|---|---|---|---|---|
| `bp_intake_analyst` | 解析 BP、提取项目事实、发现缺页和口径问题 | S0 | read-only | intake 草稿、实体和指标抽取 |
| `segment_mapper` | 行业树、价值链、项目定位、比较集和边界候选 | S1 | read-only | segment candidates、sector map 草稿 |
| `sector_researcher` | 对指定研究包进行外部行业研究，可并行多实例 | S2 | read-only + web/MCP | 市场、需求、竞争、技术、监管研究包 |
| `project_underwriter` | 把行业规律映射到项目业务、GTM、单位经济和融资风险 | S2/S5 | read-only | 项目判断和敏感性草稿 |
| `diligence_planner` | 从核心问题和证据缺口反推材料/访谈请求 | S3 | read-only | DD 清单和优先级 |
| `materials_analyst` | 解析增量材料、访谈纪要、数字和口径差异 | S4 | read-only | evidence candidates、delta 草稿 |
| `evidence_auditor` | 检查来源、引用、矛盾、覆盖率和过度推断 | S2-S6 | read-only | audit findings、contradictions |
| `investment_synthesizer` | 综合形成 A/B/C 结论、条件和关键风险 | S5 | read-only | verdict 草稿 |
| `red_team`（可选） | 从失败路径、反方和欺诈/偏差视角挑战投资逻辑 | S2/S5 | read-only | bear case、fatal risks |
| `terms_specialist`（可选） | 将未消除风险映射到交割条件和保护性条款 | S5 | read-only | terms 草稿 |
| `memo_writer`（可选） | 只基于已批准工件组装投资报告，不新增事实 | S6 | workspace-write，仅写 draft | memo 草稿 |

### 6.3 各阶段调度

```mermaid
flowchart LR
    RD["Research Director"] --> S0A["S0 bp_intake_analyst"]
    RD --> S1A["S1 segment_mapper"]
    RD --> S2P["S2 并行研究包"]
    S2P --> SR1["sector_researcher<br/>市场与需求"]
    S2P --> SR2["sector_researcher<br/>竞争与价值链"]
    S2P --> SR3["sector_researcher<br/>技术与监管"]
    S2P --> PU["project_underwriter"]
    SR1 --> EA["evidence_auditor"]
    SR2 --> EA
    SR3 --> EA
    PU --> EA
    EA --> RD
    RD --> DP["S3 diligence_planner"]
    RD --> MA["S4 materials_analyst"]
    MA --> EA2["S5 evidence_auditor"]
    EA2 --> RT["red_team"]
    RT --> IS["investment_synthesizer"]
    IS --> TS["terms_specialist"]
    TS --> RD
    RD --> MW["S6 memo_writer"]
```

并发规则：

- S2 的外部研究包可并行；每个 Agent 得到明确边界和统一输出 Schema；
- `project_underwriter` 需先读取 S1 已确认的研究范围；
- `evidence_auditor` 在研究 Agent 完成后运行，不与其争写同一文件；
- 所有 Sub-agent 只写 `workbench/agent-runs/<run_id>/`，主 Agent 才能更新 `artifacts/`；
- 默认并发 3-4 个，避免成本和结果合并复杂度失控；
- 同一结论至少由“研究者”和“审计者”两个角色经过，重大结论可再加 red team。

## 7. Skills 规划

### 7.1 业务 Skills

Skill 目录全部直接放在 `.agents/skills/` 下，用 `biz-` 前缀分类，确保 Codex 容易发现。

| Skill | 作用 | 关键输入 | 标准输出 |
|---|---|---|---|
| `biz-bp-intake` | BP 解析和项目建档 | 原始 BP | 项目事实、指标、缺失和疑点 |
| `biz-segment-mapping` | 行业分类、细分树、价值链落点 | BP 摘要、行业候选 | 行业图谱和边界候选 |
| `biz-market-sizing` | Top-down / bottom-up / comparable 三角验证 | 市场定义、客户、价格 | TAM/SAM/SOM、假设和敏感性 |
| `biz-demand-validation` | 客户、痛点、预算、采购和留存判断 | 客户数据/访谈/外部研究 | 需求证据矩阵 |
| `biz-value-chain-profit-pool` | 价值链、议价权和利润池 | 行业材料 | 价值链和经济利益分配 |
| `biz-competition-moat` | 竞争集、替代品、潜在进入者和护城河 | 比较集、客户行为 | 竞争地图和 moat test |
| `biz-technology-product` | 技术路线、成熟度、性能边界、量产/交付风险 | 技术材料 | 技术判断与验证需求 |
| `biz-regulatory-risk` | 准入、合规、政策、数据、知识产权风险 | 行业/公司材料 | 监管风险和触发条件 |
| `biz-business-model-unit-economics` | 收入质量、毛利、回款、CAC/LTV、规模经济 | 经营/财务数据 | 单位经济和敏感性 |
| `biz-core-question-design` | 将行业研究转成项目核心判断问题 | S1/S2 工件 | `core-questions.yaml` |
| `biz-dd-gap-analysis` | 从证据缺口生成最小尽调请求 | Claims/Evidence | DD 清单和访谈指南 |
| `biz-interview-analysis` | 处理访谈纪要、观点、事实和反证 | 纪要 | 可引用证据和跟进问题 |
| `biz-investment-verdict` | 形成 A/B/C 结论与条件 | 完整证据矩阵 | verdict 草稿 |
| `biz-downside-terms` | 把残余风险映射到条件和条款 | 风险、融资方案 | 条款建议和适用边界 |
| `biz-ic-memo` | 组装投委会报告 | 已批准工件 | 投资报告 |

### 7.2 系统 Skills

| Skill | 作用 | 备注 |
|---|---|---|
| `sys-case-init` | 新建 case、生成 ID、初始化目录和状态 | 调用确定性脚本 |
| `sys-document-ingest` | 登记文件、哈希、解析、OCR/表格路由 | 原件只读 |
| `sys-workflow-router` | 根据 `state.yaml` 选择下一阶段和 Agent | 防止跳阶段 |
| `sys-gate-manager` | 生成 Gate 摘要、记录批准/修改/自动策略 | 防止伪造确认 |
| `sys-evidence-ledger` | 创建和更新 Claim/Evidence 链接 | 强制 locator 和来源 |
| `sys-citation-research` | 外部搜索、打开原文、记录日期和引用 | 网络或 MCP 可用时 |
| `sys-coverage-evaluator` | 计算覆盖率并应用降级阈值 | 分数不覆盖 fatal 规则 |
| `sys-contradiction-check` | 找出数字、口径、时间和叙事冲突 | 输出可审阅 register |
| `sys-delta-update` | 新材料到达后只更新受影响的工件 | 避免全量重跑 |
| `sys-artifact-validator` | 校验 Schema、必填字段、孤立引用、状态迁移 | 应有 CLI 脚本 |
| `sys-run-resume` | 中断后从上次成功 checkpoint 恢复 | 根据 manifest |
| `sys-report-export` | 从 Markdown 生成 docx/pdf，检查引用和附件 | S6 使用 |
| `sys-privacy-redaction` | 识别并处理敏感个人/客户信息 | 可选脱敏副本 |
| `sys-goal-runner` | 按 `goal.yaml` 自动执行 S0-S3 | 明确停止条件 |

### 7.3 哪些能力不应写成 Skill

以下更适合脚本：

- 生成 UUID、文件哈希、重复文件检测；
- JSON/YAML Schema 校验；
- 加权覆盖率和阈值计算；
- currency/date/percentage 正规化；
- 引用 ID 是否存在、报告中是否有孤立主张；
- Markdown → docx/pdf；
- case snapshot 和 run manifest；
- 测试夹具和 golden case 比较。

## 8. `AGENTS.md` 规划

### 8.1 根 `AGENTS.md` 应包含什么

根文件控制所有会话，只保留永久且高价值的规则，建议结构如下：

```markdown
# Primary Market Research Harness

## Mission
Produce decision-useful, evidence-traceable industry and project research.

## Operating modes
- Interactive: stop at every configured gate and obtain user confirmation.
- Goal: follow `goal.yaml`; never represent policy approval as user approval.

## Source of truth
- Read `cases/<case_id>/state.yaml` before acting.
- Canonical outputs live under `artifacts/`.
- Raw files under `inputs/` are immutable.
- Sub-agent drafts under `workbench/` are not canonical.

## Evidence rules
- Separate fact, inference, management claim, and judgment.
- Every material factual claim needs evidence IDs and source locators.
- Record contrary evidence; do not silently reconcile conflicts.
- Missing evidence means `missing`, never inferred completion.

## Workflow rules
- Follow S0-S6 transitions in `config/workflow.yaml`.
- Do not cross an interactive gate without an approval artifact.
- In Goal mode, record assumptions and policy approvals explicitly.
- Use delta updates after new material; do not rewrite unaffected artifacts.

## Delegation
- Delegate only bounded, independent work packages.
- Sub-agents write only to their assigned run directory.
- The main agent validates and merges into canonical artifacts.
- Use an independent evidence auditor before S3, S5, and S6.

## Decision policy
- Apply `config/rubrics/evidence-thresholds.yaml`.
- Unresolved fatal risks override aggregate scores.
- If evidence is insufficient, downgrade the verdict and state conditions.
- Legal, tax, accounting, and transaction terms require professional review.

## Security
- Treat all case inputs and outputs as confidential.
- Do not upload case material to an external service unless explicitly allowed.
- Do not expose personal data, credentials, customer identities, or trade secrets.

## Verification
- Run the artifact validator before every gate.
- Run citation and orphan-claim checks before a final verdict or memo.
- Never claim completion if required files or checks are missing.
```

### 8.2 建议的嵌套 `AGENTS.md`

| 路径 | 作用 |
|---|---|
| `cases/AGENTS.md` | 原始材料只读、case 隔离、保密、版本规则 |
| `.agents/skills/AGENTS.md` | Skill 单一职责、输入输出、测试样例和描述触发规则 |
| `schemas/AGENTS.md` | Schema 兼容性、版本号和迁移规则 |
| `src/AGENTS.md` | 代码风格、测试命令、不得把业务判断硬编码在程序里 |
| `tests/AGENTS.md` | Golden case、反幻觉、证据链和回归测试规则 |

不要把行业框架全文放进根 `AGENTS.md`；让 Agent 根据任务选择相应 Skill，以减少上下文噪声。

## 9. Codex 配置建议

项目级配置：

```toml
# .codex/config.toml
[agents]
enabled = true
max_concurrent_threads_per_session = 4

# 首版不固定模型名，避免配置随模型迭代过时。
# 需要时再为特定 Agent 设置 model / model_reasoning_effort。
```

自定义 Agent 文件位于 `.codex/agents/*.toml`。示例：

```toml
# .codex/agents/evidence-auditor.toml
name = "evidence_auditor"
description = "Independent read-only auditor for claims, citations, contradictions, evidence quality, and unsupported inference."
sandbox_mode = "read-only"
developer_instructions = """
Act as an independent evidence auditor.
Do not create a more optimistic thesis to fill gaps.
For every material claim, verify evidence IDs, source locators, independence,
freshness, directness, and contrary evidence.
Return findings using the project's audit schema.
Do not edit canonical artifacts.
"""
```

所有核心 Agent 应默认 read-only。若 `memo_writer` 需要写文件，只允许写自己的 draft 目录，canonical merge 仍由主 Agent 完成。

## 10. Harness 架构图

```mermaid
flowchart TB
    UI["Codex App / CLI / IDE<br/>用户、Goal、Gate 确认"]
    ORCH["Research Director<br/>Workflow Orchestrator"]
    STATE["State & Policy<br/>state.yaml / goal.yaml / workflow.yaml"]
    BUS["Business Skills<br/>行业、项目、尽调、结论"]
    SYS["System Skills<br/>摄取、证据、Gate、校验、恢复"]
    AG["Custom Sub-agents<br/>研究 / 审计 / 综合 / 写作"]
    SCRIPTS["Deterministic Scripts<br/>Schema / Hash / Score / Export"]
    INPUT["Immutable Inputs<br/>BP / 补充材料 / 访谈"]
    ART["Canonical Artifacts<br/>Claims / Evidence / DD / Verdict"]
    WB["Agent Workbench<br/>独立草稿与运行日志"]
    EXT["External Sources<br/>Web / MCP / 数据库 / 企业知识库"]
    EVAL["Validators & Evals<br/>引用、覆盖、回归、红队"]

    UI --> ORCH
    ORCH <--> STATE
    ORCH --> BUS
    ORCH --> SYS
    ORCH --> AG
    SYS --> SCRIPTS
    INPUT --> SYS
    AG --> WB
    WB --> ORCH
    BUS --> ART
    SYS --> ART
    ORCH --> ART
    AG <--> EXT
    SYS <--> EXT
    ART --> EVAL
    EVAL --> ORCH
    ORCH --> UI
```

### 10.1 数据流

```mermaid
sequenceDiagram
    actor User
    participant O as Research Director
    participant W as Workflow State
    participant A as Sub-agents
    participant V as Validator
    participant C as Canonical Artifacts

    User->>O: 上传 BP / 启动 Goal
    O->>W: 初始化 case 与 S0
    O->>A: 分配窄任务
    A-->>O: 返回结构化草稿
    O->>V: 校验 Schema、引用、证据覆盖
    V-->>O: 通过或问题清单
    O->>C: 合并标准工件
    O->>W: 写 checkpoint / gate candidate
    O-->>User: 展示摘要、分歧、假设和选择
    User->>O: 批准 / 修改 / 补材料
    O->>W: 记录不可混淆的 approval 类型
    O->>A: 进入下一阶段或增量 Loop
```

## 11. 文件结构图

```text
primary-market-research-harness/
├─ AGENTS.md
├─ README.md
├─ .codex/
│  ├─ config.toml
│  └─ agents/
│     ├─ bp-intake-analyst.toml
│     ├─ segment-mapper.toml
│     ├─ sector-researcher.toml
│     ├─ project-underwriter.toml
│     ├─ diligence-planner.toml
│     ├─ materials-analyst.toml
│     ├─ evidence-auditor.toml
│     ├─ investment-synthesizer.toml
│     ├─ red-team.toml
│     ├─ terms-specialist.toml
│     └─ memo-writer.toml
├─ .agents/
│  └─ skills/
│     ├─ AGENTS.md
│     ├─ biz-bp-intake/
│     │  ├─ SKILL.md
│     │  ├─ references/
│     │  └─ templates/
│     ├─ biz-segment-mapping/
│     ├─ biz-market-sizing/
│     ├─ biz-demand-validation/
│     ├─ biz-value-chain-profit-pool/
│     ├─ biz-competition-moat/
│     ├─ biz-technology-product/
│     ├─ biz-regulatory-risk/
│     ├─ biz-business-model-unit-economics/
│     ├─ biz-core-question-design/
│     ├─ biz-dd-gap-analysis/
│     ├─ biz-interview-analysis/
│     ├─ biz-investment-verdict/
│     ├─ biz-downside-terms/
│     ├─ biz-ic-memo/
│     ├─ sys-case-init/
│     ├─ sys-document-ingest/
│     ├─ sys-workflow-router/
│     ├─ sys-gate-manager/
│     ├─ sys-evidence-ledger/
│     ├─ sys-citation-research/
│     ├─ sys-coverage-evaluator/
│     ├─ sys-contradiction-check/
│     ├─ sys-delta-update/
│     ├─ sys-artifact-validator/
│     ├─ sys-run-resume/
│     ├─ sys-report-export/
│     ├─ sys-privacy-redaction/
│     └─ sys-goal-runner/
├─ config/
│  ├─ workflow.yaml
│  ├─ source-policy.yaml
│  ├─ research-dimensions.yaml
│  └─ rubrics/
│     ├─ evidence-thresholds.yaml
│     ├─ question-criticality.yaml
│     └─ source-quality.yaml
├─ schemas/
│  ├─ case.schema.json
│  ├─ state.schema.json
│  ├─ goal.schema.json
│  ├─ approval.schema.json
│  ├─ core-question.schema.json
│  ├─ claim.schema.json
│  ├─ evidence.schema.json
│  ├─ contradiction.schema.json
│  └─ dd-request.schema.json
├─ templates/
│  ├─ gates/
│  ├─ industry/
│  ├─ diligence/
│  ├─ verdict/
│  └─ memo/
├─ scripts/
│  ├─ init-case.*
│  ├─ validate-artifacts.*
│  ├─ compute-coverage.*
│  ├─ check-citations.*
│  ├─ diff-materials.*
│  └─ export-report.*
├─ cases/
│  ├─ AGENTS.md
│  └─ <case_id>/
│     ├─ case.yaml
│     ├─ goal.yaml
│     ├─ state.yaml
│     ├─ inputs/
│     │  ├─ bp/
│     │  ├─ supplements/
│     │  └─ interviews/
│     ├─ derived/
│     │  ├─ text/
│     │  ├─ tables/
│     │  └─ document-index.jsonl
│     ├─ artifacts/
│     │  ├─ 01-intake/
│     │  ├─ 02-segment/
│     │  ├─ 03-industry/
│     │  ├─ 04-diligence/
│     │  ├─ 05-evidence/
│     │  ├─ 06-verdict/
│     │  └─ 07-memo/
│     ├─ approvals/
│     ├─ workbench/
│     │  └─ agent-runs/
│     ├─ reports/
│     └─ logs/
├─ tests/
│  ├─ schemas/
│  ├─ skills/
│  ├─ workflow/
│  ├─ golden-cases/
│  └─ adversarial/
└─ docs/
   ├─ architecture/
   ├─ adr/
   ├─ methodology/
   ├─ plans/
   └─ operations/
```

## 12. 核心状态文件建议

`state.yaml` 是恢复和防止乱序的关键：

```yaml
schema_version: 1
case_id: demo-company
mode: interactive
current_stage: S2
status: awaiting_gate
scope_hash: sha256:...
last_successful_checkpoint: S2-research-validated
completed_stages:
  - S0
  - S1
gates:
  G1:
    status: approved
    approved_by: user
    approval_file: approvals/gate-01.yaml
  G2:
    status: pending
active_run_ids: []
artifact_versions:
  core_questions: 2
  claim_register: 3
blocking_issues: []
```

每次阶段完成：

1. Agent 返回草稿；
2. 主 Agent 合并；
3. 校验器通过；
4. 更新 `artifact_versions`；
5. 写 checkpoint；
6. 才能生成 Gate。

## 13. 失败模式与恢复策略

| 失败模式 | 风险 | 策略 |
|---|---|---|
| BP 扫描件不可读 | 错误提取项目事实 | 标记低 OCR 质量，要求原文件；不进入 S1 |
| 项目/产品名称混淆 | 证据错配 | 实体表和 alias 表；人工确认主体 |
| 外部网络不可用 | 行业证据不足 | 明确离线模式，只用本地材料，结论降级 |
| 付费墙/二手转述 | 无法核实 | 保留二手来源等级，不声称已读原文 |
| 多 Agent 数字不同 | 错误平均 | 进入 contradiction register，比较口径和日期 |
| Agent 同时写同一文件 | 覆盖和丢失 | Sub-agent 只写独立 run 目录，主 Agent 单写 canonical |
| 用户长时间不确认 | 状态不清 | 停在 gate；不自动假装批准 |
| 新材料只影响局部 | 重跑导致漂移 | delta dependency map，仅重算受影响问题 |
| 管理层材料极完整但无外部证据 | 虚假高覆盖 | independence 单独评分，不能被材料数量稀释 |
| 结论与报告脱节 | 报告出现新事实 | memo writer 禁止新增事实，final citation check |
| 无限补材料循环 | 时间和成本失控 | 默认 3 轮；边际信息价值过低时终止并降级 |

## 14. 非功能要求

### 安全与隐私

- Case 之间目录隔离；默认不将 BP 或客户数据发送到未经授权的外部服务；
- 网络研究优先使用公开信息，私有数据源通过受控 Connector/MCP；
- 敏感材料应支持脱敏副本和访问日志；
- 原始输入、引用片段和输出报告均应视为机密；
- 若后续多人使用，再增加 RBAC、审计日志、密钥管理和数据留存策略。

### 可靠性

- 每个阶段有 checkpoint，可从最后一次成功状态恢复；
- Schema 版本化，重要工件可 Git 管理或做内容哈希快照；
- canonical artifacts 单写者原则；
- 验证失败不能标记阶段完成。

### 成本与性能

- 并发只用于 S2 等独立研究包；
- 小模型/低推理可用于解析、格式转换和初筛，高推理用于核心判断、冲突处理和红队；
- 增量材料使用 delta update，避免全量重跑；
- Goal 支持 timebox、source limit、并发上限和最大研究轮次。

### 可维护性

- 行业方法放 Skill/reference，不硬编码在 Orchestrator；
- 机构阈值放 YAML 配置；
- 输出 Schema 稳定，Prompt/Skill 可迭代；
- 每个 Skill 有正向、负向和边界触发测试。

## 15. 测试与 Evals

### 15.1 必测能力

1. **Workflow**：未批准 G1 时不能进入 S2；Goal 策略审批不能记录为用户审批。
2. **Evidence**：最终重大事实 100% 有 evidence ID 和 locator。
3. **Hallucination**：缺失材料时输出 missing，不自行补齐数字。
4. **Contradiction**：相同指标不同口径必须被发现。
5. **Delta**：新增一份访谈只更新关联问题，不重写无关结论。
6. **Downgrade**：关键覆盖不足时正确进入 B/C 等级。
7. **Agent isolation**：Sub-agent 不直接修改 canonical artifacts。
8. **Memo integrity**：报告不能出现证据库中不存在的新事实。

### 15.2 Golden Cases

至少准备五类脱敏案例：

- B2B SaaS：复购、销售效率、收入质量；
- 硬科技/制造：技术、量产、良率、供应链；
- 生物医药：临床、监管、专利、里程碑；
- 消费：渠道、品牌、复购、库存；
- 强监管行业：牌照、合规和政策依赖。

### 15.3 核心指标

- Material claim traceability：目标 100%；
- Critical question evidence coverage；
- Unsupported assertion rate；
- Contradiction detection recall；
- Gate integrity violations：目标 0；
- Human correction rate by stage；
- 新材料到结论更新的 lead time；
- 每个结论等级的人类复核一致率。

## 16. 关键 ADR

### ADR-001：采用文件工件驱动，而非仅依赖对话上下文

- **状态**：Proposed
- **决定**：所有跨阶段状态写入 YAML/JSONL/Markdown canonical artifacts。
- **收益**：可恢复、可审计、可 Git 版本化、易人工审阅。
- **代价**：需要维护 Schema 和迁移。
- **替代方案**：纯 Prompt；数据库优先平台。

### ADR-002：主 Agent 单写 canonical artifacts

- **状态**：Proposed
- **决定**：Sub-agent 只输出独立草稿，主 Agent 校验后合并。
- **收益**：避免并发覆盖和口径漂移。
- **代价**：增加合并步骤，主 Agent 成为协调瓶颈。

### ADR-003：分数不能覆盖 Fatal 规则

- **状态**：Proposed
- **决定**：总体覆盖率用于排序，但 unresolved fatal risk 一票阻断 A 级结论。
- **收益**：避免大量弱证据稀释关键风险。
- **代价**：需要机构定义 fatal 问题分类。

### ADR-004：先做 Repo Harness，后做 Plugin/MCP

- **状态**：Proposed
- **决定**：MVP 采用 repo-scoped Skills、自定义 Agent 和文件工件。
- **收益**：快速验证方法，低基础设施成本。
- **代价**：早期多人权限、实时协作和检索体验有限。

## 17. 分阶段实施路线图

### Phase 0：方法和 Schema 验证（1-2 周）

只实现一条窄路径：

- S0 BP Intake；
- S1 行业细分；
- S2 核心问题；
- S3 尽调清单；
- 手工 Gate；
- 1 个脱敏案例端到端。

交付：根 `AGENTS.md`、5 个核心 Schema、4 个 Skills、3 个 Agent、基本校验脚本。

### Phase 1：可用 MVP（2-4 周）

- 完整 S0-S5；
- Evidence ledger、contradiction register、coverage evaluator；
- Goal 自动跑 S0-S3；
- 增量材料和访谈 Loop；
- A/B/C 降级判断；
- 5 类 golden cases。

交付：可在 Codex 中稳定运行的本地 Harness。

### Phase 2：报告和团队化（2-4 周）

- S6 投资报告；
- docx/pdf 导出；
- 机构自定义 rubric；
- case 快照、审计日志、脱敏；
- Skills 和 Agent 配置稳定化。

### Phase 3：Plugin / MCP（视需要）

- 将 Skills 打包为可分发 Plugin；
- MCP 接企业文档库、项目管理系统、财务数据源或内部研究库；
- 外部工具按读取/写入和权限风险拆分；
- 增加多人权限、队列和集中索引。

### Phase 4：平台化（验证后）

只有在下列条件成立时再做：

- 月度 case 数量和多人协作已经显著；
- 业务 Schema 至少稳定两个版本；
- 人工 Gate 和降级逻辑已经被团队接受；
- 本地文件搜索/版本控制成为真实瓶颈。

## 18. MVP 最小集建议

第一版不要一次实现 29 个 Skills 和 11 个 Agent。最小可用组合：

### Agents

1. `segment_mapper`
2. `sector_researcher`
3. `evidence_auditor`
4. `diligence_planner`
5. `investment_synthesizer`

### Business Skills

1. `biz-bp-intake`
2. `biz-segment-mapping`
3. `biz-core-question-design`
4. `biz-dd-gap-analysis`
5. `biz-investment-verdict`

### System Skills

1. `sys-case-init`
2. `sys-workflow-router`
3. `sys-gate-manager`
4. `sys-evidence-ledger`
5. `sys-artifact-validator`
6. `sys-goal-runner`

### Schemas

1. `case`
2. `state`
3. `approval`
4. `core-question`
5. `claim`
6. `evidence`
7. `dd-request`

先用这套组合跑 2-3 个真实脱敏案例，再决定是否拆出技术、监管、单位经济和条款专用 Skill。

## 19. 需要用户下一轮确认的设计问题

v0.1 已做了合理默认，但实施前需要依次确认：

1. 首批重点行业是否集中，例如硬科技、企业服务、消费或医疗；这会影响 rubric 和模板。
2. 用户希望结论的最终颗粒度：仅“继续/暂停/放弃”，还是包含投资额度、估值和条款。
3. 默认外部数据边界：只允许公开 Web，还是会接内部数据库和付费数据库。
4. Case 的保密等级和是否允许将原始材料发送到任何外部 MCP/Connector。
5. 机构现有投委会模板、否决项、证据门槛和术语。
6. Goal 模式的 timebox、最大成本和自动放行策略。

## 20. 官方 Codex 能力映射

本设计使用的 Codex 原生机制：

- Repo 级永久规则：根或嵌套 `AGENTS.md`；
- Repo Skills：`.agents/skills/<skill>/SKILL.md`；
- 项目级自定义 Agent：`.codex/agents/<agent>.toml`；
- 多 Agent 全局/项目设置：`.codex/config.toml` 的 `[agents]`；
- Skills 负责可重复工作流，MCP/Connector 负责实时外部数据和受控动作；
- Sub-agent 适合独立、噪声大、可并行的窄任务；最终由主线程合并结果。

参考：

- [Codex 自定义 AGENTS.md](https://learn.chatgpt.com/docs/agent-configuration/agents-md)
- [Codex Subagents](https://learn.chatgpt.com/docs/agent-configuration/subagents)
- [Codex Skills](https://learn.chatgpt.com/docs/build-skills)
- [Codex 配置](https://learn.chatgpt.com/docs/config-file/config-basic)
