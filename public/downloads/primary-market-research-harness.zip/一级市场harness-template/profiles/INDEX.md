# 用户方法论 Profiles

新 session 只读取本索引；选中 profile 后才能读取对应目录。

| Profile ID | 名称 | 状态 | 适用场景 | 最后更新 | 路径 |
|---|---|---|---|---|---|
| default | 公共默认方法论 | Active | 未指定用户方法论时使用 | 2026-08-12 | `profiles/default/` |

禁止通过本索引推断或读取其他 Profile 正文。新增用户时从 `templates/user-profile.md` 初始化独立目录。
