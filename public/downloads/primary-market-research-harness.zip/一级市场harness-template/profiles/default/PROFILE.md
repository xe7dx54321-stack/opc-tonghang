# Default Profile

- Profile ID：`default`
- 名称：公共默认方法论
- 状态：`Active`
- 所有者：Harness baseline
- 创建日期：`2026-08-12`
- 最后更新：`2026-08-12`
- 适用项目：未指定其他Profile的全部项目
- 数据共享：禁止自动向其他Profile共享

## 读取规则

先执行公共 `AGENTS.md`、`WORKFLOW.md` 和 Skills；本 Profile 只承载业务方法差异，不覆盖系统安全、证据、项目隔离和 reviewer 底线。
