# Skill Overrides

每个公共 Skill 可有一个同名差异文件，例如 `investment-verdict.md`。只写与公共 Skill 不同的规则，并使用 `templates/methodology-override.md`。

不存在 override 时完整使用公共 Skill。禁止在这里复制其他用户 Profile 的内容。
