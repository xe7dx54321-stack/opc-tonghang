---
name: final-investment-decision
description: Form the final invest, conditional-invest, or reject decision only after the two final Markdown reports are complete. Use when final or user-authorized assumed terms are available. Reconcile the reports, final DD checklist, evidence, cap table, and agreements; model the terms and require independent joint review. Do not use before final reports or to overwrite the DD verdict.
---

# Final Investment Decision

本 Skill 只负责终局交易决策，不覆盖 `01-verdict.md`，也不负责生成Word。

## Hard preconditions

必须存在并通过前置复核：`04-industry-research-final.md`、`02-investment-memo.md`、终局状态的`02-dd-checklist.md`、`01-verdict.md`、证据矩阵、最终协议或用户授权假设条款、`investment-memo-review.md`。缺少任一最终报告或report reviewer未通过时不得决策。

## Procedure

1. 冻结并记录全部输入版本/哈希；条款标记`已签署/已谈妥待签/用户情景假设/缺失`。
2. 建立“最终报告—尽调清单—证据—条款一致性矩阵”，覆盖P0/P1、Fatal和不可豁免Gate；`部分确认/缺失`必须落入概率、折价、分期、CP、拒绝或残余风险；未解释冲突阻断发布。
3. 风险和A/B/C等级只因新证据改变，不因低价或强条款上调。
4. 执行五层估值：绝对回报、私募可比、上市/并购可比、市场周期、条款后有效价格，并做成熟度、收入质量、流动性与控制权折价。
5. 逐轮还原cap table、实缴本金、顺位、参与范围和未付股利；把清算、回购、反稀释、分期、CP和治理权转成各终局状态的可实现现金流并按可执行性折扣。
6. 测试融资额、0%/15%/30%稀释、估值收缩/基准/扩张，计算MOIC、3/5/7年IRR、不跟投及追加资本后的基金回报。
7. 反推目标回报所需成功概率、退出价值、入口价格或首笔风险资本，并与最终报告概率/退出路径对照。
8. 输出`投资/有条件投资/拒绝`，同时说清风险、价格、条款、组合和时点；条件必须协议可执行、交割前可验证。
9. 写入`outputs/investment/02-final-decision.md`；同步摘要回项目报告时不得改变模型，且须重算哈希。

## Independent joint review

`investment_reviewer`必须联合复核两篇最终Markdown、终局DD清单、证据、协议、cap table与最终决策，签署一致性矩阵并复算现金流、概率、稀释、MOIC/IRR和顺位。记录哈希与PASS到`reviews/final-investment-decision-review.md`。FAIL不得提交，条件须先关闭。

## Handoff

通过后停在“请确认最终投资结论”。用户确认后完成项目闭环；Word仅在用户需要时调用`$investment-memo`正式报告模式。
