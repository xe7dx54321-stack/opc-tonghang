---
name: industry-project-research
description: Conduct deep industry and project research only for a segment selected through broad-industry opportunity ranking. Use after the user confirms the segment-screening result or policy release. Includes market, demand, lifecycle, value chain, competition, barriers, substitution, key success factors, industry risks, business model, unit economics, financing, and downside analysis. Do not use immediately after industry positioning or before the target segment has won research priority.
---

# Industry and Project Research

Research the market and convert findings into project-level judgments.

## Required Reading

- `projects/<project_id>/PROJECT.md`
- `inputs/manifest.md`
- `outputs/industry/01-segment-map.md`
- `outputs/industry/02-segment-priority.md`
- `references/research-framework.md`
- `references/evidence-standard.md`
- `templates/03-industry-research.md`
- `templates/01-project-assessment.md`
- All matched commercial-industry and technology-landscape Wiki topics and update logs recorded in the project

## Plan the Research

1. Verify that the user approved the target segment and project for deep research. If segment screening is pending, stop and call `$industry-opportunity-screen` instead.
2. Confirm geography, time horizon, business model, and comparison set.
3. Select only material research dimensions from the framework.
4. Use `$industry-wiki` to reuse fresh public industry work or complete the required quick update. For a matched technology-landscape topic, read its taxonomy, conclusions, theses, and technology map; refresh relevant teams, papers and benchmarks before factual use. Research from scratch only for unmatched or missing scope.
5. Keep the roles separate: commercial-industry Wiki supports market, customer, value-chain and competition claims; technology-landscape Wiki supplies hypotheses about technical direction, alternatives, global/China mapping, counters and milestones. Neither a working thesis nor a mapping lead is project evidence until its primary source is opened and assigned a project-local ID.
6. Continue the `evidence/evidence-matrix.md` initialized during segment screening; preserve stable IDs.
7. Define 8-15 deep-research core questions with stable `Q-xx` IDs and criticality. Convert relevant project claims from any registered input into evidence records only when they bear on those questions; preserve material type and provenance.
8. Identify which work packages are independent.

## Delegate When Useful

For independent packages, explicitly delegate up to three parallel tasks to the custom `research_worker` agent. Typical packages:

- market size, growth, and demand;
- value chain, competition, and substitutes;
- technology, supply chain, regulation, and policy.
- competitive companies and comparable targets (customer traction, public financing, route differences, head-to-head and differentiation).

For light/fast-path projects (short-cycle opportunity capture or well-covered Wiki topics with fast-swizzle), reduce to 1-2 workers or skip sub-agents entirely; for hard-tech / fresh-industry research, use the full 3 workers.

**Task package (mandatory)** — Before spawning each `research_worker`, write a complete task package to `.agent-inbox/research-worker-<topic>.md` using [`scripts/templates/research-worker-task-package.md`](../../scripts/templates/research-worker-task-package.md). The package must include:

- Resolved project context (company, industry segment, Wiki Topic, available inputs)
- Forbidden paths (other projects, AGENTS.md, templates/, other SKILL.md)
- Readable paths with one-line purpose per path
- Already-completed E-ID / SRC-ID / Q-ID range + assigned new range for this worker
- Embedded sub-skill sections the worker needs (do NOT make the worker re-read the original SKILL.md)
- Embedded sub-template sections (do NOT make the worker re-read templates/)
- Time budget, stop conditions, completion checklist

**Worker must not re-read AGENTS.md, other SKILL.md files, or templates/.** The package's embedded sections are authoritative. This avoids the sub-agent context reload that previously cost multiple iterations of dispatching and re-deliberating.

Give each worker the case path, confirmed boundary, question IDs, source requirements, date cutoff, and return format. Do not delegate tightly coupled synthesis.

## Integrate

1. Triangulate material market-size claims with bottom-up, top-down, or comparable methods.
2. Separate industry facts from company claims.
3. Map industry structure to product, customers, GTM, revenue quality, unit economics, moat, team, finance, valuation, exit, and downside.
4. Record supporting and contrary evidence in the matrix.
5. Expose source conflicts and explain unresolved differences.
6. Write reusable public industry analysis to `outputs/industry/03-industry-research.md`.
7. Build the internal element map `outputs/project/01-project-element-map.md` first (internal working table, not for the user): map every key project element one-by-one against the industry conclusions (chapters / KSFs / risks / window), classify each as confirmed / needs-more-evidence / needs-deeper-argument / falsified, and derive due-diligence inputs. Then write the user-facing preliminary project report `outputs/project/01-project-assessment.md` with exactly three body chapters: 1) product & business introduction (technology, product status, business progress, milestone plan), 2) core advantages (opportunity capture, competitive winning, KSF-by-KSF, with completeness judgment), 3) core risks (key weaknesses, risk-response capability, due-diligence alert list). Include competitor benchmarking (head-to-head overlap, differentiation, whitespace) inside the advantages chapter.
8. Update source index and evidence matrix. Do not place project claims in the industry file merely for narrative convenience.

## Report Structure (human-readable, evidence-backed)

Follow `templates/03-industry-research.md` chapter order. The industry report is written for a human investor who may lack background in the field, so the narrative must be continuous and clean; AI/process constraints belong at the end, not the front.

**Structural hard rules** (enforced by `scripts/validate-evidence.ps1`; violating any of these fails the gate):

1. **必须按模板的 `### N.M` 子节结构逐一展开**。模板当前共有 44 个 `###` 子节，报告必须出现每一个子节，且子节标题前缀必须与模板一致（章节号 + 章节号后的主标题主干，忽略末尾括号内的修饰语差异）。**禁止合并、跳过、把子节折叠成段落、或者改写成别的子节名**。
2. **图片引用必须使用相对路径**（相对于 `.md` 文件所在目录），例如 `assets/ch1-product-chain.png`。**禁止使用绝对路径**（如 `/Users/apple/.../ch1-product-chain.png` 或 `C:\...\ch1.png`），绝对路径在跨平台/跨机器复制时会断链。
3. **核心结论必须用 `- **章节名**：一句话` 的 markdown bold 格式**，每章一行 + 整体判断一行。例如 `- **行业概述**：...`、`- **整体判断**：...`。`validate-evidence.ps1` 按章节名前缀宽松匹配，但仍要求 bold 格式。
4. **章节 6.2 必须包含论文/专利检索证据**（仅适用于硬科技项目）：检索论文、专利、主要厂商公开资料，回答核心难点、专利集中度、被绕开空间、大厂技术储备。这是 AGENTS.md 第 201 行明确要求的硬科技重点；非硬科技项目（如纯软件、纯服务）可以放宽。
5. **图表尺寸必须按章节内容设计**——时间轴用 4:1 左右横向，矩阵/格局图用 3:4 纵向，禁止把全部 10 张图统一成 16:9（这是 AGENTS.md 第 146 行明文禁止的"凑比例"做法）。

**深度与预算原则**（AGENTS.md 第 622 行"章节与核心结论齐全"，未规定统一行数/E-ID 下限）：

- 内容深度由 AGENTS.md 第 622 行的"信息密度"原则决定，**不规定统一行数下限**。
- 短周期机会捕获或已有充分 Wiki 沉淀的项目（参考 `industry-wiki` SKILL 的 fast swizzle），深度可以更轻；硬科技、未沉淀的新兴行业必须有充分论证。
- E-xxx 证据 ID 数量按项目复杂度匹配——硬科技行业需要论文/专利/量产能力三角验证，轻量级产业研究证据密度自然较低；**禁止为了凑数量编造证据 ID，但也不允许该给证据的事实无 ID**。
- 不允许为了凑长度注水。`###` 子节必须实际承载论证或结论；写 3 行有说服力的内容好过写 30 行废话。
- 整体报告长度不是合规判据；投资人能完整读懂、有判断价值即可。

**章节内容要求**：

1. **Core conclusions** (front, concise): one sentence for the overall judgment and one sentence for each body chapter's final conclusion; update after the full body is finalized. Must use `- **章节名**：...` bold format.
2. **Industry overview** (chapter 1): teach the basics in a layered way that serves later argumentation, not as a rigid dimension checklist. Cover at minimum: product definition and market boundary; technology principle and product form; core process/flow and where difficulty and moats live; key performance and value metrics and their trade-offs; an explicit "how this overview supports later chapters" table. Every claim that later chapters lean on must be stated here or clearly marked as deferred.
3. **Market size and growth** (chapter 2): even when no authoritative third-party number exists, produce a reasoned, auditable, trackable conclusion. Always render the full chain: boundary and scope statement → demand logic (why the market exists) → explicit assumptions with evidence strength → indirect data and proxies with conversion logic → scenario derivation (conservative/base/optimistic with stated formulas) → post-investment tracking ruler (falsifiable indicators, over/under-expectation thresholds, and the resulting decision). Never invent precise numbers without an audit trail; when data is missing, say so and keep the assumption visible.
4. Then the industry lifecycle and technology maturity cycle (chapter 3): locate the technology on a Gartner-style curve (emergence / peak of inflated expectations / trough of disillusionment / slope of enlightenment / plateau) with evidence for the placement — when hype peaked and its markers, why the trough happened, what is currently over- or under-estimated, what is still missing before maturity, and how many years remain; refine the industry lifecycle (introduction/growth/maturity/decline) and state the inflection point logic (before the inflection: expected timing, drivers, leading indicators; after the inflection: when and why it was established, and how many more years of high growth remain, benchmarked against comparable penetration curves). Conclude with investment timing, holding-period fit, and revaluation triggers.
5. Then the industry chain and value chain (chapter 4): map upstream (materials/equipment/key components) → midstream → downstream (integrators/brands/end customers) with core players from public sources; explain how value flows, where value and profit concentrate, which links gain or lose share; identify the likely bottleneck link in the next 3-5 years and whether it helps or hurts the invested link; analyze upstream/downstream bargaining power (concentration, substitutability, switching costs, multi-sourcing) and conclude on the profit cushion of the invested link, vertical-integration necessity, and supply-chain risks.
6. Then customer demand and purchasing behavior (chapter 5): list key customers and volumes (public sources first, management claims labeled); build a requirement table (performance, mass-production capability, price, delivery lead time and responsiveness) separating must-haves (gates to enter large customers / what sustains repeat orders) from soft differentiators; describe the buying process (sampling → PO → NRE → qualification → volume), multi-source vs single-source strategy, switching costs, and purchasing cyclicality. Conclude on revenue visibility, customer-concentration risk, validation-cycle impact on holding period, pricing power, and customer-side signals to track.
7. Then barriers to entry (chapter 6): identify the 3-5 core barriers that actually block new entrants (technology, industry window, brand/channel, qualification/security clearance, customer certification, capital/capacity — industry-specific, not a rigid checklist). Technology barrier is a heavy-budget item for hard tech: search papers/patents and major-company public materials to answer the hardest unsolved points, patent concentration and workaround space, how hard it is for a new team to overturn years of accumulated know-how, and whether large listed companies have the technical reserves to enter mid-growth. Judge whether the customer qualification window is permanently open or a limited window (when it closes, markers such as certification lock-in, multi-source to single-source, generation lock-in), and conclude on whether incumbents' leads are durable.
8. Then substitution threats (chapter 7): comprehensively identify candidate substitute technologies competing for the same customer task/budget (one-line principle, maturity, main players), verify latest progress via papers/patents rather than media claims; build a substitution-cycle table (theoretical advantage / obstacles overcome / remaining key obstacles / <5y, 5-10y, >10y / evidence), distinguishing complementary coexistence from substantive disruption. Conclude on how long the current route's window remains and whether a <5-year substitute would break the investment thesis.
9. Then competitive analysis (chapter 8): spend most budget on company leads — enumerate as many participants as possible (startups, incumbents, overseas players) with business, product/route, stage, public financing/capacity/customers (if any), and overlap with the project; mark confirmed vs lead/pending-verification. Compare only the core barriers and key capabilities confirmed in earlier chapters, qualitative only (leading/close/lagging), no exhaustive scoring. Use analogous-industry history for structure outlook (e.g., smartphone/display supply-chain evolution mapped to AR eyewear supply chains; optical-module history mapped to interconnect evolution) with explicit applicability boundaries. Conclude on first-mover vs later-entrant positioning, share logic under multi-sourcing, valuation/term implications, and the competitor interview/due-diligence list.
10. Then industry key success factors (chapter 9): condense the industry core into 3-4 measurable KSFs, not a generic checklist; derive each from two angles: customer preference (beyond basic needs, evidenced by brand choices / penetration shifts) and long-term competitive winning (route-convergence window, yield/cost curves, certification lock-in); give due-diligence-verifiable metrics per KSF and conclude on how to measure the project and what makes a future leader.
11. Then industry risk review (chapter 10): pick the 3-4 highest-impact potential risks, each with one-line description, impact path, evidence, tracking signals, and decision implications; analyze whether risks share a common source or hedge each other; the report body ends here.
12. Research scope, Wiki reuse, and promotable Wiki candidates are merged into the final chapter (chapter 11), placed at the end because they are AI/process constraints rather than investment conclusions.
13. Every chapter must include 1-2 visuals (image files rendered and embedded, or a chart) that crystallize that chapter's core analysis; generate images programmatically with **chapter-appropriate dimensions** (time axes want 4:1, matrices want 3:4, do NOT default all chapters to 16:9) and verify they render (Chinese font, no clipping, correct aspect) before finalizing.

Use clear, concise language per chapter: no long-winded prose, but do not drop key information or core evidence. Every material fact carries an evidence ID. The "concise" requirement means tighten paragraphs and remove filler; it does **NOT** mean collapse `###` subsections, skip bullets required by the template, or substitute relative paths with absolute paths.

## Review and Gate

Explicitly ask the main agent to spawn `investment_reviewer` for an independent core-judgment review using `$evidence-review`. Save the merged review to `reviews/core-judgment-review.md`.

In interactive mode, stop for the user to confirm the core judgment. In automatic mode, record policy release and proceed to diligence design.

After confirmation or policy release, invoke `$industry-wiki` to promote only the public, de-identified industry portion and preserve the project analysis exclusively in the case directory.
