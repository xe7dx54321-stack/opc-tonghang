---
name: investment-memo
description: Build the two final Markdown research reports before the final investment decision, or render their optional Word submission versions after that decision is confirmed. Use when final or assumed terms are available and the case needs decision-ready industry and project reports, or when the user later requests formal Word reports. Never use Word rendering to add research or change a conclusion.
---

# Investment Memo

## Mode selection

- **最终版Markdown分析模式（强制）**：最终/假设条款到达后，先生成行业与项目两篇最终报告，再交`$final-investment-decision`。
- **Word正式报告模式（可选）**：用户确认最终投资结论后，只做编辑渲染。

## Final Markdown mode

1. 读取行业深研、项目分析、终局DD清单、`01-verdict.md`、证据、矛盾、条款和两份最终报告模板。
2. 更新行业研究，不从零重研；尽调后改变边界、规模、周期、竞争、KSF、风险或时点的证据必须进入最终版，行业报告去项目机密。
3. 从证据独立构建项目历史、业务、优势风险、保守/中性/乐观财务桥、交易方案、两套退出、稀释跟投、MOIC/IRR和里程碑概率。
4. 不复制`01-verdict.md`或旧决策的终局概率；模型输出追溯到证据或显式假设。
5. 将每个P0/P1和不可豁免Gate的完成/部分确认/缺失映射进报告及决策影响。
6. 写`04-industry-research-final.md`和`02-investment-memo.md`；正文/模型完成后才写核心结论，最终交易决策尚未下达时不得伪装为已批准事实。
7. `investment_reviewer`复核两篇报告、模型、DD映射和反证，写`investment-memo-review.md`；通过后把报告、哈希和限制交给`$final-investment-decision`。

## Word mode

1. 前提：最终结论已确认，两篇Markdown和最终决策已联合复核并冻结哈希。
2. 不联网、不增证据、不重建模型、不改判断；独立编辑为人类投委会语言，去内部编码和系统术语，保留不确定性。
3. 行业Word彻底去项目化；精确数字图程序化，概念图可用image-2并逐字核对；正文和嵌图都做编码扫描。
4. 输出两份`*-submission.docx`并与冻结Markdown/决策核对。发现实质冲突立即停止并重开最终结论联合复核。
