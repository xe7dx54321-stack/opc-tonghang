---
name: material-analysis
description: Analyze supplemental diligence files and interview notes, update only affected sources, evidence, contradictions, DD status, and project judgments, and hand off to the DD verdict when the user declares diligence complete. Use whenever new diligence material arrives. Supports incremental in-session feedback and terminal evidence closeout; never generate the final reports or final investment decision here.
---

# Material Analysis

## Required reading

- 当前项目新文件及 `inputs/manifest.md`
- `PROJECT.md`、source index、evidence matrix、矛盾清单
- `outputs/project/02-dd-checklist.md`、行业研究、项目要素表与项目分析
- `references/evidence-standard.md`

## Mode selection

- **模式A（默认，增量）**：用户只投料、没有明确收尾；更新内部真相源并在session反馈，不生成用户文档。
- **模式B（终局）**：用户明确说材料齐了、没有更多或直接给尽调结论；全量核对、追证并调用 `$investment-verdict`。

## Active evidence pursuit

关键材料条目是线索起点而非终点。对能改变P0/P1的专利、客户/订单、产能/设备、融资/估值和技术路线做定向公开追证；逐条记录检索动作与新证据、冲突或无果。不得只做材料到checklist对照。

## Mode A

1. 登记稳定SRC ID，提取事实、口径、数字、日期、定义与限制。
2. 链接现有Q、主张和DD项；仅真实新决策问题才新增编号。
3. 只更新受影响的evidence matrix行、矛盾和项目要素状态。
4. 对DD逐项标`完成/部分确认/缺失`。
5. session反馈：材料→DD对应、DD状态、被加强/削弱/推翻的判断、新风险、1-3项最小补证建议，并询问是否还有材料。
6. 不创建`03-material-update.md`，不重跑未受影响章节。

## Mode B

1. 全量核对DD与材料，执行P0/P1线索驱动追证并更新证据单一真相源。
2. 调用 `$investment-verdict` 输出 `outputs/investment/01-verdict.md`，由`investment_reviewer`独立复核。
3. 不提前追加 `02-investment-memo.md`，不输出最终投资决策，不再追加尽调请求；缺口转为概率、估值和条款影响。

## Handoff

用户确认尽调结论并提供最终或假设条款后，依次进入 `$investment-memo` 最终Markdown模式和 `$final-investment-decision`。任何模式都不得读取或混入另一项目材料。
