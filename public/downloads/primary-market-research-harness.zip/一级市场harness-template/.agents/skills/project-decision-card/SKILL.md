---
name: project-decision-card
description: Create or refresh a compact, preference-neutral investment decision card from one project's approved canonical artifacts for later cross-project comparison. Use after a meaningful project Gate, when a portfolio comparison needs a missing or stale card, or when conclusions, evidence, milestones, valuation, or terms materially change. Do not reread all raw inputs by default and do not alter the source project's conclusion.
---

# Project Decision Card

Compress one project's current investment state into a comparable card without re-running the research.

## Required reading

- `templates/project-decision-card.md`
- the selected project's `PROJECT.md`;
- the latest approved stage artifact relevant to the current state;
- `outputs/project/02-dd-checklist.md`, `evidence/evidence-matrix.md`, and investment outputs only when they already exist;
- the matching industry Wiki summary when the project declares one.

Do not read raw BP, interview, financial, legal, customer, or technical files by default. Open a raw source only when a canonical artifact contains a decision-changing contradiction that cannot be localized, and disclose the extra read.

## Neutrality

The card is `profile_scope: neutral`. Record facts, stage-calibrated conclusions, uncertainty, evidence strength, economics and source pointers. Do not encode one user's sector taste, risk appetite, target return, preferred exit, or report style in the card; those belong in a portfolio run.

## Build sequence

1. Identify the latest completed/approved research stage and source update date. Never present an earlier Gate as current.
2. Apply the investment-ceiling test: if management's decisive narratives all hold, state whether the project could reach a genuinely attractive investment outcome and why.
3. Route by company stage:
   - early: record the next value-repricing event, likely next-round buyer/strategic acquirer, value-repricing clock, falsification clock, cash clock and exit clock;
   - middle/late: record revenue and cash-flow quality, listing/acquisition feasibility, remediation, filing/lock-up horizon and public-market valuation space.
4. Classify each decisive narrative as confirmed, unproven but not falsified, partially contradicted, falsified, or lacking an objective test.
5. Preserve existing probability, dilution, MOIC/IRR and term conclusions when available; mark missing inputs instead of inventing comparability.
6. Identify fatal risks. A risk is a veto only when it determines success, lacks objective resolution, will remain a dispute after more work, and cannot be priced or protected by terms.
7. Keep at most three seven-day verification tasks. Each must have a feasible route, objective threshold and a stated investment action for pass/fail. Broad know-how questions are not tasks.
8. Link every compressed conclusion to a canonical file/section or evidence identifier.
9. Write `portfolio/cards/<project_id>.md` and update exactly one row in `portfolio/INDEX.md`.

## Freshness

Refresh affected blocks when the project stage or recommendation changes, DD evidence alters a core bet, a milestone is reached/missed, or valuation/terms change. Treat valuation and financing as fast-moving, customer/competition/policy as medium-moving, and technical fundamentals as slower-moving; record freshness per block rather than declaring the entire project current without support.

If `source_project_updated_at` is later than the card or a decisive field is stale, set `card_status: stale` until refreshed. Do not refresh unrelated blocks.

## Budget discipline

Use the smallest sufficient source set. A card is a compressed index, not a new report. Target roughly 1,500–3,000 tokens (usually about 2,500–5,000 Chinese characters), keep one level of causal reasoning, and avoid copying narrative background already available in Wiki.

## Handoff

Return the card path, source stage, freshness limitations, decisive missing fields and whether it is safe for `quick`, `standard`, or only directional portfolio comparison.
