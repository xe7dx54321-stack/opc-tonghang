---
name: project-pool-selection
description: Compare a user-bounded pool of previously researched private-market projects and select the highest investment priority under limited reading budget and user preferences. Use when the user asks to choose, rank, shortlist, or allocate attention among multiple projects. Start with decision cards, eliminate projects whose fully realized thesis is still unattractive, selectively deepen only Top-K candidates, and return one integrated recommendation with bounded seven-day verification tasks.
---

# Project Pool Selection

Answer one question: under the user's current mandate and preferences, which project most deserves investment decision resources and ultimately the investment?

Do not create separate competing “follow-up” and “investment” rankings. Follow-up is justified only for a project whose investment ceiling is already high; disclose the remaining gap to investment inside the integrated recommendation.

## Required reading

- `references/portfolio-selection-framework.md`
- `templates/portfolio-decision-brief.md`
- `templates/portfolio-selection-report.md`
- `projects/INDEX.md`, `portfolio/INDEX.md`, and `wiki/INDEX.md`
- the selected session Profile and relevant Skill override, if any.

Read candidate cards only after resolving the user's boundary. A portfolio request explicitly authorizes cross-project comparison for the selected candidate set, but not indiscriminate access to every project or raw input.

## Resolve the mandate

Translate natural language into `portfolio/runs/<run_id>/01-decision-brief.md`:

- candidate universe, industry/theme, geography and company stage;
- one integrated decision objective and number of selections;
- hard constraints;
- soft preferences: stage, upside, certainty, holding period, exit path, capital use and concentration;
- cutoff date and `quick / standard / deep` budget.

If the user does not explicitly name a budget mode, always set `budget_mode: standard`. Only an explicit user request for `quick` or `deep` may change it; do not infer a different mode from candidate count, urgency, time, token cost, or your own judgment. Under the default, use Top-K = 3 and one final selection when the user asks to choose one. State harmless assumptions and proceed; pause only when an ambiguity could reverse the candidate set or result.

## Candidate discovery and cards

1. Filter `projects/INDEX.md` and `portfolio/INDEX.md` using hard scope before opening cards.
2. Exclude hard-constraint failures with explicit reasons.
3. For in-scope projects with missing/stale cards, invoke `$project-decision-card` only for those projects. Do not backfill the whole repository.
4. Read a shared industry Wiki once per common topic, then compare each project's delta to the same KSF; do not repeatedly regenerate common industry analysis.

## Investment-ceiling gate

Before spending deep-read budget, assume each project's decisive management narratives all hold. Exclude it if market position, economics, dilution and exit still fail the user's priority threshold. Do not promote a low-ceiling project because its evidence is complete or its remaining question is easy to answer.

## Stage-specific comparison

- Early projects: evaluate next value-repricing event, who will pay the next valuation, narrative durability, the four clocks, financing relay, dilution and the risk that falsification arrives before repricing.
- Middle/late projects: evaluate revenue/cash-flow quality, listing or acquisition feasibility, remediation, filing/lock-up/liquidity and realizable public-market value.
- Mixed stages: first apply the appropriate lens, then compare at fund-utility level using probability-weighted return, capital duration, follow-on needs, downside, liquidity and profile fit.

Classify decisive narratives as already falsified, seven-day verifiable, currently unproven but time-bounded falsifiable, or persistently non-objective. A success-critical, non-objective dispute that cannot be priced or protected is a veto, not an endless diligence item.

## Budget ladder

- `quick`: indexes and all in-scope cards; produce a directional shortlist.
- `standard`: cards, then Top 3 canonical reports, final DD states and decisive evidence excerpts.
- `deep`: Top 2 full canonical outputs; open raw materials only for a localized decision-changing conflict.

Never reread every project's complete source package merely to appear thorough. Record what was and was not reopened.

## Ranking and challenge

Lead with facts and causal judgments. Scores are secondary audit aids. Compare industry opportunity, KSF fit, repricing path, falsification structure, price/return, capital burden, evidence strength, veto risks and profile fit.

For Top candidates:

1. conduct pairwise choices and state the winner, asymmetric advantage, extra risk and reversal condition;
2. test valuation, evidence downgrade, milestone delay, dilution and user-preference sensitivity;
3. distinguish the preference-neutral result from changes caused by the selected Profile;
4. identify one winner and a fallback unless evidence is genuinely insufficient, in which case state the narrow fact that blocks selection.

## Seven-day verification

For the winner and only necessary fallback, keep at most three tasks per project. Each must be answerable within seven days through a named person, document, test, expert or public source; define pass/partial/fail thresholds before verification and map each outcome to invest, negotiate, switch, pause or reject.

Do not send the user broad questions about long-term leadership, future market growth, generic execution quality or other open-ended know-how. Convert them to observable proxies; otherwise retain them as priced core bets or apply the veto rule.

## Output and review

Write `portfolio/runs/<run_id>/02-selection-report.md` from the template. The report must contain the final priority, remaining investment gap, exclusions, Top comparisons, accepted core bets, vetoes, preference effects, reversal conditions and one-week action plan.

Ask `portfolio_reviewer` to audit the candidate set, stage routing, investment-ceiling gate, source freshness, pairwise logic, preference effects and verification feasibility. Save the result as `03-portfolio-review.md`. Do not call a result final when the reviewer returns `FAIL`.

Do not modify source-project conclusions during comparison. If comparison exposes a real contradiction, mark the affected card stale and route a separate project update.
