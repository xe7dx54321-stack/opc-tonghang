---
name: project-setup
description: Initialize or safely resume one isolated primary-market research case from a BP, interview notes, user research, financial or technical files, or a request to start a project. Use whenever a new session receives project materials or the user names a project. Resolve entity identity before reading case files, create a new project for a different company even in the same industry, and never inherit another project's state.
---

# Project Setup

Select exactly one session project and initialize its isolated workspace without analyzing the investment thesis.

## Required Reading

- Root `AGENTS.md` and `WORKFLOW.md`
- `projects/INDEX.md`
- `templates/PROJECT.md`
- `templates/input-manifest.md`

Do not read any existing project's `PROJECT.md`, inputs, evidence, outputs, reviews, or notes until the entity-selection step identifies that project for this session.

## Select New or Existing

1. Inventory only the current session's uploaded files, paths, explicit project name, and conversation context.
2. Build an entity fingerprint from legal entity, brand, website domain, product owner, and other identity markers visible in current inputs.
3. Run `scripts/resolve-project-context.ps1` when company or brand identity is available, then apply the rules below; the script is read-only and never activates a project.
4. Compare the fingerprint with `projects/INDEX.md`:
   - different entity: always create a new project;
   - exact same entity plus explicit continuation or clearly supplemental materials: resume the existing project;
   - same industry or technology only: create a new project;
   - unresolved identity: create a neutral date-based isolated project and record ambiguity rather than reading a similar old case.
5. If two existing entities are plausible and the choice would materially change state, stop for user confirmation.
6. Record the selection basis in `inputs/manifest.md`. Never use or create a global active-project marker.

## Initialize the Case

1. Derive a stable lowercase ASCII hyphenated `project_id`; never overwrite an existing directory.
2. Create:

```text
projects/<project_id>/
├─ PROJECT.md
├─ inputs/
│  ├─ manifest.md
│  ├─ bp/
│  ├─ research/
│  ├─ interviews/
│  ├─ financial/
│  ├─ commercial/
│  ├─ technical/
│  ├─ legal-ip/
│  └─ other/
├─ outputs/
│  ├─ industry/
│  ├─ project/
│  └─ investment/
├─ evidence/
├─ reviews/
└─ notes/
```

3. Copy `templates/PROJECT.md`, `templates/input-manifest.md`, `templates/evidence-matrix.md`, and `templates/source-index.md` into their canonical locations. Create stage artifacts from templates only when that stage starts; do not pre-fill outputs with empty future reports.
4. Copy each input without modifying the original and classify it by primary use:
   - BP and company presentation → `inputs/bp/`;
   - third-party or user-authored research → `inputs/research/`;
   - management, customer, expert, employee, or supplier notes → `inputs/interviews/`;
   - financial statements and models → `inputs/financial/`;
   - contracts, orders, customers, pipeline, pricing, or sales data → `inputs/commercial/`;
   - product, test, manufacturing, or engineering material → `inputs/technical/`;
   - legal, IP, compliance, or corporate records → `inputs/legal-ip/`;
   - unclassified material → `inputs/other/`.
5. Register every input in `inputs/manifest.md` with type, date, provider, readability, intended stage use, confidentiality, and limitations.
6. Fill known project information; write `待确认` for unknown fields. Record mode as `interactive` unless the user explicitly requests automatic execution.
7. Update `projects/INDEX.md` with identity aliases, status, dates, and path. The index is discovery metadata, not session state.
8. Set `项目建立与材料摄取` complete and `初始材料分析与行业定位` pending.

## Readability and Safety

- Check whether each file is readable, complete enough for its stated purpose, encrypted, or requires OCR.
- Treat all inputs as immutable and confidential.
- Do not upload confidential files to external services without authorization.
- Do not deduplicate files across projects by shared storage; physical separation is the default.
- A Wiki match never merges projects and never supplies project-specific evidence.

## Handoff

Return the selected project path, `new / resumed / ambiguous-isolated` decision, entity fingerprint, operating mode, categorized input list, readability issues, and the next action: invoke `$bp-segment-screen` for `初始材料分析与行业定位`.
