---
name: diligence-design
description: Convert core investment questions and evidence gaps into a prioritized due-diligence plan, material request, data request, interview guide, and next-step recommendation. Use for 尽调设计 after industry research or when the user asks what to verify next. Do not output a generic checklist disconnected from the evidence matrix.
---

# Diligence Design

Design the smallest diligence effort that can change the decision.

## Inputs

- `PROJECT.md`
- `outputs/industry/03-industry-research.md`
- `outputs/project/01-project-assessment.md`
- `outputs/project/01-project-element-map.md`
- `evidence/evidence-matrix.md`
- `references/evidence-standard.md`
- `templates/03-dd-checklist.md`
- `templates/03a-dd-interview-guides.md`
- `templates/03b-dd-competitors.md`

## Procedure

1. Sort core questions by fatal, critical, important, and optional.
2. For every `Partial`, `Contradicted`, or `Missing` critical question, define the decision-relevant gap.
3. Choose the best verification route:
   - company material;
   - raw operating or financial data;
   - contract, invoice, payment, or audit evidence;
   - customer, expert, employee, supplier, or management interview;
   - product, technical, legal, regulatory, or IP review;
   - external public verification.
4. Create stable `DD-xxx` IDs.
5. For each request state:
   - linked `Q-xx` and claim;
   - priority P0/P1/P2;
   - exact requested item or question;
   - why it matters;
   - expected format or interviewee;
   - acceptance criteria;
   - decision impact if confirmed, contradicted, or unavailable.
   - for operating metrics, freeze the definition, numerator/denominator, grade classification, time window, source system and reconciliation chain before setting a threshold;
   - for customer evidence, distinguish contact/NDA/sample PO/NRE/production PO/delivery/acceptance/payment, and require at least one complete conversion chain instead of making one named customer automatically fatal;
   - for capacity and financing, connect monthly cash, committed contracts, equipment payment/delivery, construction, staffing, ramp, financing and delayed subsidy scenarios over the full period to the next value-inflection milestone;
   - for people/IP/governance, cover labor or consulting relationship, non-compete, confidentiality and invention assignment, recipe backup, capital contribution, shareholder special rights, related parties and compliance remediation.
6. Remove duplicative requests and group them into an executable sequence.
7. Design the smallest feasible management interview plan: pick who to interview, how long (1-1.5h each), and what each session must prove; allocate depth by the key elements (P0/P1), not uniformly across people (e.g., deep-dive technology/product, skip finance if materials suffice).
   - If cost, cash flow or the monthly funding plan cannot be reconciled from documents, a finance interview becomes mandatory rather than permanently skipped.
8. Write three deliverables:
   - `outputs/project/02-dd-checklist.md` (overview: core gaps -> strategy, DD-xxx material/data requests, external verification, special diligence, next steps, scope confirmation);
   - `outputs/project/02a-dd-interview-guides.md` (management interview arrangement rationale + per-person question guides: 4-6 core points each, with follow-up rounds, requested evidence, and falsification signals; the arrangement rationale must be concise and needs no charts);
   - `outputs/project/02b-dd-competitors.md` (competitor diligence: top-3 picks with reasons, common questions to confirm with every competitor, differentiated focuses per competitor, access paths, execution notes).
9. Respect reality for competitors: usually only a few can be reached; give priority order plus fallback/side-channel verification (shared supply chain, public info, trade shows). Competitor interviews require user authorization.

## Interview Design Method

- Every core point in a per-person guide follows five elements: 问题 → 追问链（1-2 轮）→ 索要证据/文件 → 证伪信号（什么答案会改变判断）→ 决策影响。Do not mechanically map one question per point; multiple follow-up rounds around the same core point are expected.
- Coverage matrix: every P0/P1 decision gap (Q-xx) must be covered by at least one interviewee (or explicitly by material request, labeled 材料). Add the matrix to `02a-dd-interview-guides.md` and verify it before finalizing.
- Closure matrix: `02-dd-checklist.md` must show `Q → PM → DD → interview/external check → acceptance threshold → decision impact`. A list of requests without this traceability cannot pass review.
- Interview record loop: after each interview, write back a standard record (interviewee/time, core conclusions, new evidence with source grade, triggered falsification signals, Q/PM/DD updates, next steps) so the evidence matrix is updated incrementally; never leave interview answers only in notes.
- Competitor degradation strategy: if only 1-2 competitors are reachable, keep the one that changes the decision most (head-to-head > route convergence > cross-route substitution), and replace the rest with side-channel verification (shared supply chain, public reports, trade shows); state the fallback explicitly in `02b-dd-competitors.md`.

## Priority

- P0: absence blocks a reliable conclusion or leaves a fatal risk unresolved.
- P1: materially changes valuation, structure, terms, or investment inclination.
- P2: increases confidence but does not block the decision.

## Review and Gate

Ask `investment_reviewer` to check whether every P0/P1 item maps to a real decision gap and closes the full traceability chain. `FAIL` blocks the Gate and requires remediation plus follow-up review by the same reviewer. In interactive mode stop for `尽调范围确认`. In automatic mode end after `尽调设计` and present the assumptions, research summary, and checklist together.
