---
name: investment-verdict
description: Produce an evidence-calibrated DD conclusion and investment advice before final transaction terms, including A/B/C evidence sufficiency, probability and odds, entry timing, core bets, dilution, and term or closing-condition recommendations. Use after supplemental diligence is complete. Do not issue the final investment decision or overwrite this verdict when terms later arrive.
---

# Investment Verdict（尽调结论与投资建议）

## Boundary

本阶段交付“尽调结论 + 下一步投资建议”，不是最终投资结论。用户未提供最终条款时禁止输出最终决策；条款到达后也不覆盖本文件，而是依次交给 `$investment-memo` 最终Markdown模式和 `$final-investment-decision`。

## Required reading

- 当前项目全部canonical研究、要素表、尽调设计、补充材料与终局DD状态
- `evidence/evidence-matrix.md`、`evidence/source-index.md`、矛盾清单
- `references/evidence-standard.md`、`references/investment-rubric.md`
- `templates/05-verdict.md`

## Procedure

1. 对专利、客户/订单、产能/设备、融资/估值和技术路线执行线索驱动外部追证，记录“动作+新证据/冲突/无果”；无果也是结论。
2. 逐项审阅所有Fatal/Critical问题和终局DD完成/部分确认/缺失状态，禁止只看汇总覆盖率。
3. 给出Bull/Bear和少数真正决定结果的假设；识别unsupported leap、反证、口径冲突和价格/融资敏感性。
4. 按rubric给A/B/C证据充分度；Fatal未解决不得上调，条款保护不能改变证据等级。
5. 对量产、客户转化、放量、资金和合规等核心判断给概率区间、依据强度和反证方向；终局分支相互排斥且完全覆盖，相关性写入条件概率，禁止重复计数。
6. 用估值回报反推隐含要求成功率并与估计概率比较；至少测试0%/15%/30%稀释，计算不跟投和维持持股所需追加资本，基金MOIC分母包含追加资本。
7. 比较早鸟高赔率/高不确定与量产确认后低赔率/低不确定，说明哪个时点更适合LP；明确1-2个超额收益核心bet及证伪信号。
8. 形成交易建议：估值锚、里程碑分期、估值调整、不可豁免CP、清算/反稀释/回购/最惠、跟投上限、治理与信息权；法律税务会计交专业顾问。
9. 用户尽调预算已用完时不追加请求；将未验证项转成概率影响、估值折扣和条款保护。
10. 写 `outputs/investment/01-verdict.md`，保持为独立、冻结的尽调结论。

## Independent review and Gate

`investment_reviewer`必须复算互斥概率树、未稀释回报、累计稀释、跟投资金分母和隐含成功率；不可复算即FAIL。通过后停在“请确认尽调结论与投资建议”。
