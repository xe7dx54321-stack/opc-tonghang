---
name: industry-wiki
description: Find, reuse, refresh, and promote cross-project commercial-industry and technology-landscape research stored under wiki/. Use when a project needs prior industry knowledge, a frontier technology map, a stale-topic update, or approved de-projectized work should enter the knowledge base. Never copy confidential project materials, management claims, interviews, customer names, or project evidence into the Wiki.
---

# Industry and Technology Wiki

Reuse public industry knowledge without leaking one project into another.

## Required Reading

- `wiki/INDEX.md`
- The candidate topic's `TOPIC.md`
- `references/wiki-schema.md` when creating or updating a topic

Do not read another project's `PROJECT.md`, inputs, evidence matrix, outputs, or notes to answer a Wiki lookup.

## Match a Topic

1. Derive two locators when relevant:
   - commercial industry locator: broad industry, customer budget, end use, value-chain layer, certification, and segment aliases;
   - technology locator: core model/technology route, system function, training/deployment loop, and recognized technical aliases.
2. Search only `wiki/INDEX.md` and topic metadata first.
3. For `topic_kind: industry`, require commercial scope compatibility. A shared technology label is insufficient when customer budget, end use, certification system, competitive set, or value pool differs.
4. For `topic_kind: technology-landscape`, match on the actual technical route or learning/deployment function. It may be read alongside an industry topic but cannot replace commercial market or competition analysis.
5. Return `exact`, `adjacent`, or `no match` separately for each topic. Read full topic files only for exact or plausibly adjacent matches.

## Apply Freshness Rules

1. Run `scripts/check-wiki-freshness.ps1 -IndustryId <industry_id>` to compute age from `last_verified_at` in `TOPIC.md` using calendar days. Pass `-MaterialEvent` when an event trigger exists.
2. If age is within the topic's own freshness window, status is `fresh`, source verification is `verified`, and no event trigger exists, reuse supported conclusions with their original public sources and disclose the verification date.
3. If age exceeds 60 days, run a quick update before reuse. Do not rerun the whole industry study by default.
4. Update even within 60 days when a material event may invalidate conclusions: new regulation, major financing or M&A, price or capacity shock, new product generation, material technical benchmark, customer procurement change, or a contradiction from a current primary source.
5. Treat market size, growth, price, capacity, competition, regulation, and company rankings as volatile. Treat definitions and value-chain structure as more stable but still scope-check them.
6. Technology-landscape mappings and forecasts default to 30-day freshness. `partial/unverified` source status or `review_due/updating` status always requires a quick source rebuild before factual reuse; working theses may still guide search if clearly labeled.

## Run a Quick Update

1. Start from claims marked `volatile` or `review_due` in `claims.md`.
2. Search only for changes since the previous source cutoff, plus authoritative replacements for inaccessible sources.
3. Open original pages or files; never use search snippets as evidence.
4. Classify every reviewed claim as `unchanged`, `updated`, `new`, `retired`, or `contradicted`.
5. Write `updates/YYYY-MM-DD.md` using `templates/wiki-update.md`.
6. Update affected topic files, `last_verified_at`, `source_cutoff`, `next_review_due`, and `wiki/INDEX.md`. Preserve prior conclusions in the update log; do not silently overwrite them.

## Reuse in a Project

1. Copy only the relevant conclusion and original public-source provenance into the selected project's files.
2. Allocate new project-local `SRC-xxx`, `E-xxx`, and claim IDs. Never reuse IDs from another project or treat a Wiki claim as project evidence.
3. Record the Wiki topic, version date, reused scope, and any boundary changes in the selected `PROJECT.md` and `inputs/manifest.md`.
4. Distinguish `reused public industry fact`, `fresh update`, `management claim`, and `project-specific inference`.
5. Research from scratch only for unmatched scope, missing critical coverage, or conclusions invalidated by the quick update.
6. When a technology-landscape topic matches, read its `taxonomy.md`, `conclusions.md`, `theses.md`, and `technology-map.md`. Use them to frame technology direction, alternatives, global/China mapping, counters, and milestones; do not copy them as project evidence.

## Promote Approved Work

Promote project work only when the industry artifact is complete, independently reviewed where required, and confirmed by the user or released by automatic policy.

### Two-stage promotion trigger

`AGENTS.md` 第 498 行把沉淀拆成两阶段，避免新项目来时 Wiki 仍是 partial：

- **行业级沉淀**（行业图谱、L1 排名底稿、结构性变化地图、KPI 锚点、5 个 L1 方向结论）：只要来源完整、`细分筛选确认` Gate 的 reviewer 通过、且经过用户确认或自动策略放行，**立即允许**沉淀为 Wiki canonical；不得被核心判断或最终投资结论阻塞。
- **项目级沉淀**（项目评估、要素表、项目财务/融资/条款、项目判断）：继续等待完整项目流程、对应的 reviewer 通过且用户确认或自动策略放行；项目级内容禁止进入 Wiki。

`bp-segment-screen` SKILL 在写出 `01-screening-conclusion.md` 之后必须立即调用 `$industry-wiki` 触发行业级沉淀，不得等待用户确认核心判断。

Before promotion:

- strip company identity, BP content, management claims, interviews, financials, customer names, transaction details, and project-specific conclusions;
- retain only public-source facts, generic industry inferences, definitions, taxonomies, segment rankings, and reusable methods;
- conversation-derived working theses may be retained only in `theses.md` with origin, confidence, falsifiers and verification status; they must never be represented as Supported facts;
- public company facts from the company-level rough screen (who makes what, product stage, route differences) may be retained as part of the competition landscape after de-identification; non-public interviews, financing terms, customer names, and project conclusions remain prohibited;
- replace project IDs with Wiki IDs defined in `references/wiki-schema.md`;
- disclose source scope, date, confidence, contrary evidence, and next review date;
- create a new topic rather than broadening an old topic across incompatible customer budgets.

### Fast swizzle from adjacent completed projects

当一个相邻项目已经走完 `细分筛选确认` Gate 且 reviewer 通过时，其去项目化的**行业级结论**（行业图谱、L1 排名底稿、结构性变化地图、KPI 锚点）可以直接转存入对应 Wiki Topic 的 `conclusions.md` 与 `theses.md`，无需重做公开原始来源重建。这条快路径只解决"行业级结论延迟"，不替代 `partial → verified` 的全量公开来源重建；公司级 claim 仍按原规则要求公开原始来源重建。

前置条件：

1. 源项目的 `细分筛选确认` Gate 已被 reviewer 通过（`reviews/segment-screen-review.md` 存在并 PASS/PASS WITH CONDITIONS）；
2. 转存内容在写入 Wiki 前必须剥除公司名、BP、访谈、客户、财务、融资、条款、项目判断；
3. 公开来源 URL 必须保留在 Wiki 的 `claims.md` 与 `source-index.md`，不得只剩项目本地 ID；
4. 必须在 `claims.md` 与 `conclusions.md` 头部记录来源项目 ID、转存日期与触发 Gate（`细分筛选确认` / reviewer 姓名 / 日期）；
5. 转存后该 Wiki Topic 的 `source_verification` 升为 `verified`（**仅限行业级结论**），公司级 claim 仍标记为 `partial` 直至完成原始来源重建；
6. 不得把"相邻项目研究产物"作为唯一来源——后续快速更新（`updates/YYYY-MM-DD.md`）仍需独立核验公开来源，发现矛盾时按 `contradicted` 记录并保留历史。

快路径触发器由 `bp-segment-screen` SKILL 在用户确认 `01-screening-conclusion.md` 后自动调用一次；后续新项目做行业定位时如命中同一 Wiki Topic，必须仍跑 `Apply Freshness Rules` 与必要的 Quick Update，不能把快路径当作"永久 verified"。

## Handoff

Return the matched topic, scope match, freshness status, reused conclusions, changed conclusions, unresolved gaps, Wiki files touched, and whether full external research is still needed.
