# Industry Wiki Schema

## Topic directory

```text
wiki/<industry_id>/
├─ TOPIC.md
├─ taxonomy.md
├─ conclusions.md
├─ theses.md                 # optional: working hypotheses, never project evidence
├─ technology-map.md         # required for technology-landscape topics
├─ claims.md
├─ source-index.md
└─ updates/
   └─ YYYY-MM-DD.md
```

Use lowercase ASCII hyphenated `industry_id` values. One topic must have one coherent customer-budget, end-use, certification, competition, and value-pool boundary.

## Required TOPIC metadata

- `industry_id`
- `topic_kind`: `industry / technology-landscape`
- `title`
- `aliases`
- `scope`
- `geography`
- `last_verified_at`
- `source_cutoff`
- `freshness_days` (default `60`)
- `next_review_due`
- `status`: `fresh / review_due / updating / archived`
- `volatility`: `high / medium / low`
- `source_verification`: `verified / partial / unverified`

## Stable Wiki IDs

- Claim: `W-C-001`
- Source: `W-SRC-001`
- Change: `W-U-001`

Never place project `Q-xx`, `C-xxx`, `E-xxx`, `SRC-xxx`, or `DD-xxx` IDs in Wiki canonical files.

## Claims table

| Claim ID | Reusable claim | Type | Status | Confidence | Volatility | Evidence | Last verified | Review due | Counterevidence |
|---|---|---|---|---|---|---|---|---|---|

Allowed claim status: `Supported / Partial / Contradicted / Retired`.

## Technology-landscape topics

Technology-landscape topics capture cross-industry technology evolution, working theses, and team/research mappings. They may match a project in parallel with a commercial industry topic.

- Use `taxonomy.md` for stable route definitions and relationships.
- Use `theses.md` for forecasts and strategic hypotheses, with confidence, falsifiers, project implications, and verification status.
- Use `technology-map.md` for global/China team and research-route leads. Treat mappings as volatile and refresh them before project use.
- A conversation, meeting note, or analyst synthesis may be listed as an origin source for a working thesis, but never substitutes for a public primary source supporting a factual claim.
- Technology-landscape content cannot support market size, customer-budget, company-ranking, financing, or project-evidence claims without fresh primary-source verification.

## Confidentiality boundary

Wiki may contain public-source industry facts, generic analysis, and clearly labeled working theses. It must not contain BP excerpts, non-public interviews, customer names supplied by a project, company operating data, financing details, project verdicts, or a project's evidence matrix. Working theses must carry origin, verification status, confidence, and falsifiers and are not evidence.
