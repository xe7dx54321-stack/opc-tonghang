---
name: harness-evolution
description: Turn user dissatisfaction, professional corrections, and repeated workflow feedback into isolated project rules, user-profile methodology overrides, or tested core Harness improvements. Use whenever a user asks the agent to remember a preferred investment method, adjust a Skill or workflow, make future outputs behave differently, or evolve the Harness. Preserve user isolation, validation, versioning, and rollback.
---

# Harness Evolution

把反馈变成可复现规则，而不是一句“以后注意”。完整遵循根目录 `EVOLUTION.md`。

## Required reading

- `EVOLUTION.md`
- `profiles/INDEX.md`
- 当前session已选中Profile的 `PROFILE.md`、`methodology.md`、`feedback-log.md`
- 当前项目 `notes/professional-feedback.md`（若已选择项目）
- 被反馈影响的公共Skill、Profile override、模板或Workflow

禁止读取其他用户Profile正文。

## Triage

1. 复述不满意结果、理想行为和期望适用范围。
2. 判断根因：数据/证据不足、执行偏差、模板问题、公共Skill问题、用户方法差异或系统bug。
3. 选择最窄层级：
   - Project：只对当前项目；
   - Profile：当前用户未来项目；
   - Core：所有用户公共基线。
4. 用户明确说“以后都这样”时建议Profile层；单个案例不得自动升格Core。

## Project evolution

写入 `projects/<id>/notes/professional-feedback.md`：原结果、用户纠正、当前项目后续动作。不得改变其他项目或Profile。

## Profile evolution

1. 若用户没有独立Profile，使用 `templates/user-profile.md` 创建 `profiles/<profile_id>/`，并更新 `profiles/INDEX.md`。
2. 将长期投资偏好写入 `methodology.md`；Skill差异写入 `overrides/<skill-name>.md`，只写差异。
3. 使用 `templates/methodology-override.md` 定义触发、规则、非触发案例、测试与回退。
4. 更新 `feedback-log.md`。长期规则激活前取得用户确认。
5. 在后续任务中先读公共Skill，再叠加选中Profile override。

## Core evolution

1. 从 `templates/evolution-proposal.md` 建立proposal。
2. 至少设计触发案例、非触发案例和边界/反例；用不同项目或去敏fixture验证。
3. 明确受影响文件、兼容性、迁移和rollback。
4. 经用户批准后才改公共规则或 `evolution/runtime-skill-source/`。
5. 运行 `scripts/validate-evolution.ps1`、Skill quick validation和Harness回归。
6. Runtime Skill由用户在活动session外执行 `scripts/sync-runtime-skills.ps1 -Apply` 发布；新session验证后标记Released。

## Immutable baseline

Profile和Core业务方法都不得静默放松项目/Profile隔离、证据真实性、保密安全、事实/假设区分、用户Gate、法律合规和reviewer独立性。若用户明确要求改变底线，先披露风险并取得单独确认。

## Completion

反馈层级、可执行规则、测试、用户确认、版本、发布状态和回退方式全部落盘后，才可宣布演进完成。
