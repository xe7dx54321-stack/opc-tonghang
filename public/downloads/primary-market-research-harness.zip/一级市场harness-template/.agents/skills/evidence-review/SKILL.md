---
name: evidence-review
description: Independently audit segment rankings, project claims, source provenance, contradictions, evidence gaps, diligence traceability, and whether conclusions are calibrated. Use by the investment_reviewer agent before segment-screening confirmation, core-judgment confirmation, diligence-scope confirmation, investment-verdict confirmation, or the final memo, or whenever the user asks for an independent challenge. Do not rewrite the investment thesis.
---

# Evidence Review

Audit the research without becoming a second author.

## Required Reading

- The artifacts named in the review request (the task package under `.agent-inbox/<reviewer-task-name>.md` lists the exact files)
- `evidence/evidence-matrix.md`
- `evidence/source-index.md`
- `references/evidence-standard.md`
- `references/investment-rubric.md` for verdict reviews

## Tiered Review (Default = Substantive + Auto-Formal)

**不要把全部 7 条 review sequence 全跑一遍。** 按当前阶段挑实质性章节与算式集中用力；机械形式检查（文件存在、章节齐全、图片路径、核心结论 bold）已由 `scripts/validate-evidence.ps1` 接管，reviewer **直接读取**该脚本的输出当作形式审核结论，不要重跑、不要重读章节内容去复验结构。

### Substantive Review (default, mandatory for core-judgment / verdict / final-decision)

只对真正驱动投资决策的章节与算式集中用力：

| 当前阶段 | 实质性审核重点章节 | 算式复算 |
| --- | --- | --- |
| 细分筛选确认前 | 第 2 章排名底稿 + 第 2 章公司层粗筛（仅 P1/P2 + 项目方向） | 排名轴是否同层级；公司清单是否公开来源支撑；权重敏感性 |
| 核心判断确认前 | 第 4 章（产业链与价值链：瓶颈识别、议价力结论）/ 第 6 章（硬科技项目必须含论文/专利检索证据）/ 第 7 章（替代周期判断）/ 第 8 章（竞争集合完整性与头对头诚实性）/ 第 9 章（KSF 衡量指标与"龙头阈值"）/ 第 10 章（核心 3-4 条风险的影响路径） | 不做算式复算 |
| 投资判断 / 最终结论前 | 同核心判断阶段 + 01-verdict.md 的概率树、稀释假设、MOIC/IRR 是否可重算 | **逐条复算**：概率树必须 mutually exclusive and collectively exhaustive；客户/产能里程碑若在多个分支出现即为阻断性双重计入；估值口径必须区分最新完成轮 vs 拟议轮；不能用定性结论替代算式不可复算的事实 |
| 最终投资结论 | 同上 + 02-final-decision.md 的五层估值、条款现金流、跟投预算 | 同上 + 顺位竞争、回购触发日、清偿能力折扣 |

**实质性审核不审**：第 1 章行业概述、第 3 章生命周期（非拐点判断部分）、第 11 章研究范围与 Wiki 复用。这些章节的结构完整性由 `validate-evidence.ps1` 覆盖，reviewer 不必重读。

### Formal Review (always on, but lightweight and delegate-able)

- 文件存在性、章节齐全度、`###` 子节结构、图片相对路径、核心结论 bold 格式、章节 11 字面漂移 → **由 `scripts/validate-evidence.ps1 -ProjectId <id>` 自动覆盖**，reviewer 直接读其输出当作形式审核结论，**禁止重跑或重读章节去复验结构**
- Wiki 复用范围、Source 编号去重 → 由 `validate-evidence.ps1` 覆盖
- 任务包中列出的形式字段存在性 → reviewer 一次性核对

### Time Budget

按当前阶段一行预算：默认 reviewer 的工作预算上限（不是主 Agent 的）。**超过预算即必须把已得发现写入 review 文件并标注 "review incomplete due to budget"，禁止用 redo / 重跑 / 扩大范围来拖延**。

| 阶段 | 实质性预算 | 形式预算 |
| --- | --- | --- |
| 细分筛选 | 15 分钟 | 3 分钟 |
| 核心判断 | 20 分钟 | 3 分钟 |
| 投资判断 / 最终结论 | 25 分钟 | 3 分钟 |
| 最终投资结论 | 30 分钟 | 3 分钟 |

预算由 `.agent-inbox/<reviewer-task-name>.md` 任务包传入；reviewer 必须在产出末尾写明实际耗时，超预算必须解释（"卡在哪个具体来源"+ 该来源验证了什么）。

## Substantive Review Sequence (按阶段挑重点，不要全跑)

1. **Completeness (实质性章节)** — 该阶段的实质性章节是否齐全；critical questions 是否有 explicit status；决定投资判断的关键主张是否都有 E-xxx 引用。
2. **Provenance (实质性章节)** — 该阶段决定性事实的证据 ID 都能 resolve；管理层口径没有被包装成独立事实；Wiki 复用是否 scope 兼容并已重新分配本地 ID；没有跨项目泄露。
3. **Contradictions** — 反证是否显式处理；可比性（口径/期间/币种/样本）是否成立。
4. **Reasoning** — 关键推断是否从证据自然推导；替代解释与样本偏差是否考虑；行业证据没有直接当公司证据用。
5. **Segment-ranking calibration (only before segment-screening confirmation)** — 排名轴、池子层级、公司清单支撑、证据置信度分离、权重敏感性。
6. **Decision calibration** — fatal 风险压过总分；结论强度匹配关键证据；条件与尽调请求对应具体风险；项目证据充分度不与行业吸引力混淆；存在专利/客户/投资人/PO/工厂/访谈不等于存在可执行护城河或客户转化。
7. **Probability / odds arithmetic (only for verdict / final memo / final decision)** — 复算每条概率树、联合概率、期望值、稀释假设、所有权结果、隐含回报门槛；terminal branches mutually exclusive and collectively exhaustive；区分最新完成轮 vs 拟议轮；反推估值隐含成功概率；跟投预算缺失必须展示稀释敏感性；算式不可复算即 FAIL。

## Hard Gate

- `PASS`: no decision-changing defect remains; residual limitations are disclosed.
- `PASS WITH CONDITIONS`: only bounded fixes remain and none can reverse the current stage decision. The main Agent must record each condition and completion evidence before treating the Gate as passed.
- `FAIL`: any blocking issue remains, including incomparable segment pools, missing investable-company-set hard constraint, unresolved critical provenance, stale project artifacts that overstate current evidence, unmapped P0 diligence requests, or non-reproducible probability/odds arithmetic.
- A failed review must not be described as complete, confirmed, approved, or automatically released. The main Agent must remediate and send the same reviewer a follow-up review, or explicitly stop the workflow.

## Output

Return:

- `PASS`, `PASS WITH CONDITIONS`, or `FAIL`;
- scope and reviewed artifact versions;
- actual time spent (within budget / exceeded budget — must declare and explain what blocked progress);
- findings ordered by decision impact;
- affected `Q-xx`, claim, evidence, or `DD-xxx` IDs;
- required fixes or additional evidence;
- residual limitations after fixes;
- for `PASS WITH CONDITIONS`, an explicit closure checklist;
- for verdict / final reviews, a compact arithmetic audit table showing stated value, recomputed value and variance;
- **for substantive-tier reviews, the explicit chapter list actually inspected** (proves tier discipline).

Do not modify canonical files. The main Agent decides how to merge findings and records the final review under `reviews/`.
