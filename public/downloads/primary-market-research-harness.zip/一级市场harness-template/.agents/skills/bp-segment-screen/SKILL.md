---
name: bp-segment-screen
description: Analyze a selected project's initial BP, interview notes, user research, and other materials only to locate what the company does, then build a top-down map of investment-relevant industry segments and decide whether segment screening is worthwhile. Use after project setup for 初始材料分析与行业定位. May reuse fresh public industry Wiki knowledge, but must not verify project highlights, create diligence requests, or inherit another project's evidence.
---

# Initial Materials and Industry Positioning

Treat the initial material bundle as a locator and context source, not as the investment anchor.

## Required Reading

- The selected `projects/<project_id>/PROJECT.md`
- The selected `inputs/manifest.md` and registered files under that project's `inputs/`
- `wiki/INDEX.md`
- `references/segment-screening-framework.md`
- `templates/01-segment-map.md`
- `templates/01-screening-conclusion.md`

Do not read any unselected project directory.

## Use the Initial Materials

1. Extract only what is needed to locate the company: what it sells, who pays, what job it solves, its value-chain position, and revenue form.
2. Treat material types differently:
   - BP/company deck: management self-description;
   - interview: observed statement or interviewee inference, with role and bias;
   - user/third-party research: background evidence whose author, date, scope, and sources require calibration;
   - financial, commercial, technical, or legal files: use only locator fields at this stage and reserve substantive verification for later stages.
3. Compare locator information across files. Record convergence, conflict, and date mismatch in `inputs/manifest.md`; multiple documents repeating one management claim are not independent verification.
4. Write a one-sentence company description. Do not summarize or assess team, performance, customers, orders, capacity, financing story, or claimed market size.

## Build the Industry Position

1. Start from the broad industry and build a top-down L0-L3 map. Define the L1 axis explicitly as the broad industry's major investment directions (technology routes, business models, or value-chain layers). Application lists of the target project's technology are not an L1 axis; applications belong inside a selected route as secondary detail (customer budget, maturity, certification, typical scenarios). When the project touches two broad industries (e.g., display and optical interconnect), build a separate map and screening conclusion for each and never merge them into one map or table.
2. Apply `references/segment-screening-framework.md`. Require independent customer budget and competitive set; do not create BOM-, ingredient-, screw-, or process-step segments without a distinct value pool and investable company set.
3. Identify one `primary_segment`, relevant `sibling_directions`, `adjacent_directions`, and explicit `excluded_directions`.
4. After the provisional industry scope is clear, invoke `$industry-wiki`:
   - first match commercial industry topics by customer budget, end use, value-chain layer, certification, and aliases;
   - for frontier AI, robotics, chip architecture, or other technology-led projects, also match `technology-landscape` topics by technical route and learning/deployment function;
   - reuse only scope-compatible public industry knowledge;
   - apply each topic's own freshness and source-verification status; `partial/unverified` or `review_due` requires a quick source rebuild before factual reuse;
   - never read an old project's outputs as a substitute for Wiki lookup.
5. Use a matched technology landscape only to position the route, identify trend migration, global/China mapping, alternatives, counters, and milestones. Do not use it for market size, customer-budget ranking, or as project evidence.
6. Use limited public research only to confirm missing classification nodes or changes not covered by a fresh Wiki. Record opened originals in `evidence/source-index.md`.
7. Compare the project segment with sibling directions using industry-level priors: structural demand, value/profit pool, barriers, scalability, capital cycle, and project exposure.
8. Decide `继续`, `有条件继续`, or `停止`. If conditional, define what broad-industry comparison the next stage must perform.
9. Annotate 1-3 representative public players per major investable direction (company names, public sources only) so the map carries a first company-level panorama.

## Outputs

1. Write:
   - `outputs/industry/01-segment-map.md`;
   - `outputs/industry/01-screening-conclusion.md`.
2. Create an information-rich 16:10 landscape industry map and save the canonical image as `outputs/industry/01-industry-map.png`; keep raw generations under `outputs/industry/assets/`.
3. Require one-line introductions for major investable directions, representative public players per direction, a numbered project path, project-industry definition/customer budget/applications/investment attributes/risks, and the screening conclusion.
4. Deliver exactly 3840×2400 pixels by proportional high-quality resampling plus minimal padding/cropping when needed. Never stretch text or icons. Inspect dimensions, hierarchy, text, path, cropping, and distortion before replacing canonical.
5. Update `inputs/manifest.md`, `evidence/source-index.md`, `PROJECT.md`, and the selected row in `projects/INDEX.md`.
6. **必须为本项目设定一个具体的 `Primary industry Wiki topic_id`**，写入 `PROJECT.md` 第 7 节和 `projects/INDEX.md` 对应行的 `Primary industry Wiki` 字段。
   - 若匹配的 Wiki Topic 尚未创建，使用稳定的 `<industry_id>`（如 `ai-cluster-optical-interconnect`、`high-performance-composites`），并在 `PROJECT.md` 第 7 节注明 `(topic to be created via $industry-wiki at 细分筛选确认)`。
   - 禁止把 `Primary industry Wiki` 留空或写 `待建立` / `none` / `未知`——这会导致 Codex 在新 session 启动时无法做行业匹配，被迫从零做细分筛选。
   - 决定 `industry_id` 的依据：客户预算、终端用途、价值链层级、认证体系、竞争集合与已有 Wiki Topic 的别名是否同 Scope；命名遵循 `wiki/INDEX.md` 现有 Topic 的 kebab-case 风格。
7. **写入 `01-screening-conclusion.md` 后立即触发行业级 Wiki 沉淀**：调用 `$industry-wiki`，把去项目化的行业图谱、L1 排名底稿、结构性变化地图、5 个 L1 方向结论转存入对应 Topic 的 `conclusions.md` 与 `theses.md`。这是行业级沉淀，不是项目级沉淀，不需要等核心判断或最终投资结论。如果 Topic 不存在，按 `industry-wiki` SKILL 的"创建新 Topic"流程新建。

## Hard Boundary

During initial materials analysis and industry positioning, do not:

- initialize or populate `evidence/evidence-matrix.md`;
- create `Q-xx`, `C-xxx`, `E-xxx`, or `DD-xxx` records;
- output core investment questions, diligence questions, material requests, interview questions, or P0/P1/P2 actions;
- verify product performance, customer conversion, orders, capacity, team, IP, unit economics, financing, or claimed project advantages;
- use downstream equipment or end-market TAM as the project's market size;
- use the project technology's application list as the industry L1 axis or the future segment-screening universe;
- copy project claims or evidence from another project or promote current confidential inputs into the Wiki.

## Gate

In interactive mode, stop and ask the user to confirm the map, segment boundaries, input conflicts that affect positioning, screening conclusion, and next-stage comparison scope. In automatic mode, record policy release and continue to segment screening.
