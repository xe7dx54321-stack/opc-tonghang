---
name: industry-opportunity-screen
description: Rank investment-relevant segments inside the broad industry after BP analysis and industry positioning, before spending research time on the target project. Use after the user confirms the industry map to identify structural demand, technology and policy changes, compare market size, growth, lifecycle, competition, profit pools, barriers and scalability, determine the target segment's priority, and decide whether a single-slot or multi-slot sector strategy should continue with the current project. Do not perform project diligence or deep company verification.
---

# Broad-industry Opportunity Screen

Compare industries before researching the company. The target project is a marker on the map, not the anchor of the ranking.

## Required Reading

- `projects/<project_id>/PROJECT.md`
- `outputs/industry/01-segment-map.md`
- `references/segment-priority-framework.md`
- `templates/02-segment-priority.md`
- `evidence/source-index.md`
- Any scope-compatible Wiki topic recorded in `inputs/manifest.md`

## Define the Ranking Axis

1. State the ranking axis and economic level before building any table: the axis must be the broad industry's major investment directions (technology routes, business models, or value-chain layers) at one decision level.
2. Application lists of the target technology are not a ranking axis. Applications belong inside a selected route as secondary detail (customer budget, maturity, certification, profit pool per application).
3. When the project spans two broad industries, produce one formal ranking per industry and merge only in the portfolio conclusion; never mix nodes from different industries in one table.
4. If the user explicitly wants capital allocation by application, treat it as a separate user-requested ranking with a different axis and keep it out of the standard industry ranking.

## Build a Comparable Universe

1. Start from every investment-relevant direction admitted in the confirmed industry map, not only the project branch.
2. Compare nodes at the same economic level. Do not mix parent industries, child technologies, end markets, BOM parts, or process steps in one ranking.
3. Require an independent customer budget, competitive set, value pool, and investable company set. Mark non-comparable or data-poor nodes explicitly rather than forcing a score.
4. Preserve the industry-map labels and record any boundary correction before ranking.
5. Normalize formally ranked directions to the same customer-budget, competition-set and value-chain boundary. Treat a broad parent market only as a ceiling or proxy for a narrower direction. Move heterogeneous catch-all groups out of the formal ranking.
6. Reuse Wiki claims only after checking scope and freshness. Copy original public provenance into new project-local IDs; never reuse another project's IDs or project-specific conclusions.
7. A matched technology-landscape topic may inform structural technology change, alternative routes, global/China mapping and falsifiers. It cannot provide market-size, customer-budget or company-ranking evidence, and its working theses/mapping leads require fresh primary-source verification before scoring.

## Identify Structural Changes

1. Find material demand, technology, policy, supply-chain, cost, or regulatory changes in the broad industry.
2. For each change, state the direction, magnitude, durability, affected segments, winners, losers, evidence IDs, and strongest counterargument.
3. Distinguish a durable structural change from a cyclical rebound, policy slogan, downstream market growth, or one company's marketing claim.

## Score and Rank

1. Apply the common rubric in `references/segment-priority-framework.md` to every segment.
2. Score the eight dimensions on a 1-5 ordinal scale and calculate the weighted score in the Excel view. Keep evidence confidence separate from attractiveness; do not disguise weak evidence with precise decimals.
3. Apply fatal screens before aggregate scoring. A node without an independent budget/value pool, a realistic commercialization path, or an investable company set cannot become P1 because of a high market-growth score.
4. Rank segments, assign P1-P4 tiers, and show sensitivity when the top two are within five points or depend on non-comparable market definitions.
5. State the target project's segment rank, score gap to the leader, better alternative directions, and what evidence could change the ordering.
6. Define 2/4-point interpolation explicitly. For every formal segment, record all eight scores with a reason, Evidence IDs and confidence.
7. Run numerical sensitivity cases for weight shifts, weak-evidence score changes, and at least one joint case combining a reasonable upgrade to the current segment with a weak-evidence downgrade to the nearest competing segment. State whether the leader reverses, what evidence the current segment needs to enter the top three when others stay unchanged, and whether the result remains stable under the joint case.

## Separate Conclusions from Scoring

1. Build the user-facing conclusion table before the scoring table.
2. For every segment, state the market size with year, geography, currency and definition; growth with period and definition; lifecycle; inflection point; competition; direction of change; profit-pool evidence; main risk; priority and a plain-language investment conclusion.
3. Never substitute a score for a factual conclusion. “Market size score 4” is audit metadata, not the deliverable.
4. If no defensible direct size or growth exists, write `不可可靠测量` or `仅有代理量` and explain why. A range is allowed only when inputs, formula and upper/lower-bound logic are fully auditable; otherwise delete it and do not hard-code a midpoint.
5. The first complete conclusion table in both Markdown and Excel must include the industry definition and Evidence IDs for every row.
6. Put dimension scores, anchors, weights, confidence and evidence links in separate audit sheets/sections after the conclusion table.
7. A formal segment must share one customer budget, end use, certification system, competitive set and profit pool. Split the same material into separate segments when those economic boundaries differ; keep unresolved variants as observation directions outside the ranking.
8. Deliver the company-level rough screen (reference framework section 7) for P1/P2 directions and the target project's direction before the audit sheets.

## Portfolio Decision

Always provide both views unless the user already specified allocation constraints:

- **Single-slot strategy:** if the broad industry can receive only one investment, name the preferred segment and say `继续当前项目 / 暂停并优先找其他方向 / 停止`.
- **Multi-slot strategy:** identify the investable top tier, diversification logic, and which directions should not consume research budget.

Do not use project-specific technology, customer, team, or financing claims to lift its industry's rank. Those belong to industry and project deep research after the user confirms the direction.

## Delegate When Useful

For a broad universe, delegate up to three read-only `research_worker` packages by comparative dimension, not by giving all workers the current project segment:

- structural demand, technology and policy changes across the full universe;
- normalized market size, growth and lifecycle across the full universe;
- competition evolution, profit pools, barriers, scalability and investable target supply across the full universe (public company list per route: product, stage, public financing, head-to-head overlap with the target project).

Give every worker the same universe, geography, time horizon, scoring definitions, source rules and return table.

## Outputs and Gate

1. Write the canonical analysis to `outputs/industry/02-segment-priority.md`, titled `细分筛选` without workflow codes.
2. Write `outputs/industry/02-company-landscape.md`: company-level rough screen for P1/P2 directions and the target project's direction (company, product/deliverable, route and differentiation, customers/applications, stage, public financing/valuation if available, head-to-head overlap with the target project, evidence and confidence) plus a competition-relationship matrix (head-to-head / differentiated / whitespace).
3. Create the derived visual workbook `outputs/industry/02-segment-priority.xlsx` from the same matrix. It must include separate sheets for: conclusion overview, complete segment conclusions, structural-change evidence, market/growth/lifecycle evidence, competition/profit-pool evidence, company-level rough screen, dimension-by-dimension scoring evidence, scoring rules, scoring audit, numerical sensitivity, Evidence-to-Source mapping, complete used sources and checks. The Markdown file is the single truth source; the workbook must not introduce new scores or claims.
4. Update `evidence/source-index.md` and the affected portion of `evidence/evidence-matrix.md` with stable IDs.
5. Ask an independent `investment_reviewer` using `$evidence-review` to review the ranking axis and pool level, comparability, company-level rough screen, evidence coverage, scoring consistency, ranking sensitivity and portfolio conclusions. Save it as `reviews/segment-screen-review.md`.
6. In interactive mode, stop for the user to confirm the segment-screening conclusion. Do not call `$industry-project-research` until the user confirms which segment and project should receive deep research.
7. After confirmation or automatic policy release, invoke `$industry-wiki` to promote only the public, de-identified industry portion.

## Hard Boundary

During segment screening, do not verify the target company's performance, orders, customers, capacity, team, IP, unit economics, financing, valuation, or claims. Do not generate diligence requests. If the current segment ranks poorly, recommend stopping or parking the project before deep research.
