# Harness Evolution：用户方法论与持续调优

## 目标

让不同投资人把专业反馈持续沉淀为自己的研究方法，同时满足四个约束：

1. 反馈能在后续任务中稳定生效；
2. 不同用户互不污染；
3. 公共证据、隔离和风控底线不被单次偏好悄悄改掉；
4. 每次变化可测试、可审计、可回退。

## 三层演进模型

| 层级 | 适用范围 | 写入位置 | 是否需要用户确认 | 示例 |
|---|---|---|---|---|
| 项目层 | 仅当前公司 | `projects/<id>/notes/professional-feedback.md` | 普通纠正可直接记录 | 某项目客户定义、特殊交易假设 |
| Profile层 | 当前用户全部后续项目 | `profiles/<profile_id>/` | 升格为长期规则前确认 | 更偏好早期高赔率、报告章节权重、估值目标 |
| Core层 | 所有用户公共基线 | `AGENTS.md`、`WORKFLOW.md`、templates、runtime Skill source | 必须确认+回归测试 | 项目隔离bug、证据规则缺陷、通用流程修复 |

单个项目反馈默认从项目层开始；用户明确说“以后都这样”时进入Profile层；只有跨profile适用或属于系统缺陷时才讨论Core层。

## Session Profile 隔离

- Profile 是 session 级选择，不设全局 active profile。
- 新 session 只读 `profiles/INDEX.md`；用户明确指定后才读对应 profile 正文。未指定使用 `default`。
- 禁止读取、搜索、总结其他 profile 的 methodology、feedback 或 overrides。
- 同一用户可有多个策略 profile，例如 `deep-tech-early-stage`、`growth-late-stage`，但一个 session 只能选择一个。
- Profile 不能自动继承另一 profile；复制或合并必须由用户明确要求，并留下变更记录。

## Feedback → Rule 工作流

1. **复述反馈**：说明用户不满意的结果、期望行为和适用范围。
2. **定位原因**：区分数据不足、执行偏差、模板问题、Skill规则问题、用户方法差异或系统bug。
3. **选择层级**：项目 / Profile / Core；不确定时优先更窄范围。
4. **形成可执行规则**：写清触发条件、必须动作、禁止动作、交付变化和例外。
5. **定义回归案例**：至少包含触发案例、非触发案例和一个边界/反例；记录预期结果。
6. **执行验证**：用真实项目副本或去敏fixture测试，不直接拿未备份canonical产物做破坏性试验。
7. **用户确认**：Profile长期规则或Core规则变更前，向用户展示变化及可能副作用。
8. **发布与记录**：更新版本、change log和回退点；失败则保持Draft或撤回。

## Profile Override 规则

选中 Skill 时，主 Agent先完整读取公共 `SKILL.md`，再读取 `profiles/<profile_id>/overrides/<skill-name>.md`（若存在）。Override只写差异，不复制整个公共Skill。

优先级：系统/开发者安全规则 > Harness不可变底线 > 用户明确当前指令 > 选中Profile override > 公共Skill默认 > 项目历史反馈。

Profile可调整：

- 行业偏好、生命周期与回报门槛；
- 估值与概率方法的权重、情景范围；
- 研究预算、章节深度、报告风格；
- Gate前希望看到的额外分析；
- `投资/有条件投资/拒绝`的组合约束和基金目标。
- 项目池候选边界、早期/中后期偏好、可接受的未证明Bet、赔率/确定性/持有期/资本占用权重，以及一周可投入的跟进资源。

Profile不得静默放松：

- 项目与用户数据隔离；
- 来源真实性、证据可追溯和不伪造数据；
- 用户确认Gate与假设/事实区分；
- 保密、安全、法律合规；
- reviewer独立性及关键算术可复算。

## Core Promotion 门槛

Profile规则升格Core至少满足：

- 用户明确批准；
- 不是只对一个项目成立的经验；
- 至少2个不同项目或一个正例+一个反例通过；
- 不破坏已有fixture、证据验证和项目隔离；
- 写明受影响文件、迁移方式和rollback；
- runtime Skills发布后在新 session验证加载结果。

## Skill 发布边界

`evolution/runtime-skill-source/` 是可编辑、可评审的Skill发布源；`.agents/skills/` 是Codex运行时快照。活动 session 可能锁定后者，不能通过递归放宽ACL解决。

发布步骤：

1. 修改 source Skill和元数据；
2. 运行 `scripts/validate-evolution.ps1` 与 skill-creator `quick_validate.py`；
3. 生成release note与变更清单；
4. 用户确认；
5. 在没有加载该Harness Skills的外部PowerShell或维护session运行 `scripts/sync-runtime-skills.ps1 -Apply`；
6. 新开Codex session，运行 `scripts/validate-all.ps1`并做冒烟测试；
7. 失败时用同步脚本生成的backup恢复。

## 完成定义

一次Evolution只有在“规则已落盘、范围明确、测试通过、版本记录完整、下次session可复现”时才算完成。仅在对话中说“以后注意”不算完成。
