# 聊天认知沉淀记录

## 会话元数据

- 标题：
- Thread ID：
- 类型：ChatGPT / Codex
- 提炼日期：`YYYY-MM-DD`
- 总轮次：
- 读取完整度：完整 / 部分（说明截断、附件或图片限制）

## 本次纳入范围

- 

## 明确排除

- 项目特定分析：
- 非公开材料：
- 用户方法论（是否另行写入Profile）：

## 候选知识资产

| 类型 | 内容 | 目标 Topic/文件 | 外部来源核验 | 处理 |
|---|---|---|---|---|
| 公开事实 / 工作假设 / 技术Mapping | | | verified / partial / pending | promote / hold / exclude |

## Promotion 结果

- 新建/更新 Topic：
- Wiki INDEX 别名与Scope：
- Freshness：
- 待公开来源复核：
- 后续项目命中方式：
