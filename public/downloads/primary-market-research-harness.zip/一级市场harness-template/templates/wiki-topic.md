# <行业主题>

## Metadata

- industry_id：`<industry_id>`
- topic_kind：`industry / technology-landscape`
- aliases：
- scope：
- geography：
- last_verified_at：`YYYY-MM-DD`
- source_cutoff：`YYYY-MM-DD`
- freshness_days：`60`
- next_review_due：`YYYY-MM-DD`
- status：`fresh / review_due / updating / archived`
- volatility：`high / medium / low`
- source_verification：`verified / partial / unverified`

## 可复用范围

- 包含：
- 不包含：
- 相邻但不可直接复用：

## 文件

- `taxonomy.md`
- `conclusions.md`
- `theses.md`（技术版图或含工作假设的Topic）
- `technology-map.md`（技术版图Topic）
- `claims.md`
- `source-index.md`
- `updates/`
