# 初始材料清单

## 项目选择

- Session 选择依据：本次上传 / 明确项目名 / 用户要求继续
- 是否命中既有实体：否 / 是（Project ID） / 不确定
- 新建或续接理由：
- 禁止读取的其他项目：默认 `projects/` 下全部未选中项目

## 材料登记

| 文件 | 类型 | 原始日期 | 接收日期 | 提供方 | 是否可读 | 首轮允许用途 | 局限/保密 |
|---|---|---|---|---|---|---|---|
| | BP / Research / Interview / Financial / Commercial / Technical / Legal-IP / Other | | | | | 行业定位 / 背景参考 / 后续证据 | |

## 初始材料之间的定位一致性

- 对“卖什么”的一致/冲突：
- 对“谁付费”的一致/冲突：
- 对“解决什么任务”的一致/冲突：
- 对“价值链位置”的一致/冲突：

## 行业 Wiki 匹配

| Wiki Topic | 类型 | 匹配类型 | Scope 是否一致 | Last verified | Source status / Freshness | 本项目使用方式 |
|---|---|---|---|---|---|---|
| | industry / technology-landscape | exact / adjacent / none | | | verified/partial；fresh/update required | 市场与竞争 / 技术趋势与Mapping；不得直接作为项目证据 |
