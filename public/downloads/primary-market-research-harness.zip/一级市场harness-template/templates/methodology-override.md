# <skill-name> Profile Override

- Profile ID：
- 适用 Skill：`<skill-name>`
- 状态：`Draft / Tested / Active / Reverted`
- 版本：
- 生效日期：
- 来源反馈：

## 触发条件

## 覆盖规则

## 保持不变的公共规则

## 非触发/例外

## 测试案例与预期

| 案例 | 是否触发 | 预期行为 | 实际结果 |
|---|---|---|---|
| | | | |

## 副作用与回退
