# <项目名称> · Research Project

## 1. 基础信息

- Project ID：`<project_id>`
- 公司主体：待确认
- 产品/品牌：待确认
- 融资轮次：待确认
- 本轮融资：待确认
- 地域：待确认
- 决策场景：待确认
- 研究负责人：Codex 主 Agent
- 实体指纹：法定主体 / 品牌 / 官网域名 / 产品主体（待确认）
- 本次选择：`new / resumed / ambiguous-isolated`
- 创建日期：`YYYY-MM-DD`
- 最后更新：`YYYY-MM-DD`

## 2. 运行模式

- 模式：`interactive / automatic`
- 自动模式终点：默认“尽调设计”
- 外部公开信息研究：`允许 / 不允许 / 待确认`
- 原始材料外发：默认不允许
- 时间范围：待确认

## 3. 当前研究边界

- Primary segment：待确认
- Adjacent segments：待确认
- Excluded segments：待确认
- 地域：待确认
- 比较公司：待确认
- Scope 备注：无

## 4. 里程碑

| 阶段 | 状态 | 产物 | 更新时间 |
|---|---|---|---|
| 项目建立与材料摄取 | Pending | `PROJECT.md` | |
| 初始材料分析与行业定位 | Pending | `outputs/industry/01-segment-map.md`、`01-industry-map.png`、`01-screening-conclusion.md` | |
| 行业定位确认 | Pending | 本文件第5节 | |
| 细分筛选 | Pending | `outputs/industry/02-segment-priority.md`、`02-segment-priority.xlsx` | |
| 细分筛选确认 | Pending | 本文件第5节 | |
| 行业与项目深研 | Pending | `outputs/industry/03-industry-research.md`、`outputs/project/01-project-assessment.md` | |
| 核心判断确认 | Pending | 本文件第5节 | |
| 尽调设计 | Pending | `outputs/project/02-dd-checklist.md` | |
| 尽调范围确认 | Pending | 本文件第5节 | |
| 补充材料分析 | Pending | `outputs/project/03-material-update-YYYY-MM-DD.md` | |
| 投资判断 | Pending | `outputs/investment/01-verdict.md` | |
| 投资结论确认 | Pending | 本文件第5节 | |
| 最终版研究报告（Markdown） | Pending | `outputs/industry/04-industry-research-final.md`、`outputs/investment/02-investment-memo.md` | |
| 最终投资结论 | Pending | `outputs/investment/02-final-decision.md` | |
| 最终投资结论确认 | Pending | 本文件第5节 | |
| Word 正式报告 | Optional | 两份 `*-submission.docx` | |

状态只能使用：`Pending / In Progress / Completed / Awaiting User / Blocked / Skipped by Policy / Optional`。

## 5. Gate 记录

| 确认节点 | 决策 | 决策者 | 日期 | 说明 |
|---|---|---|---|---|
| 行业定位确认 | Pending | | | |
| 细分筛选确认 | Pending | | | |
| 核心判断确认 | Pending | | | |
| 尽调范围确认 | Pending | | | |
| 投资结论确认 | Pending | | | |
| 最终投资结论确认 | Pending | | | |

决策者只能写：`User / Automatic Policy`。不得把策略放行写成 User。

## 6. 输入材料

| 文件 | 类型 | 接收日期 | 是否可读 | 备注 |
|---|---|---|---|---|
| | BP / Research / Interview / Financial / Commercial / Technical / Legal-IP / Other | | | |

完整登记见 `inputs/manifest.md`。

## 7. 行业 Wiki 复用

- **Primary industry Wiki topic_id**：`<industry_id>`（必填）。决定依据：客户预算、终端用途、价值链层级、认证体系、竞争集合与 `wiki/INDEX.md` 现有 Topic 的别名是否同 Scope；命名遵循 `wiki/INDEX.md` 现有 Topic 的 kebab-case 风格。**禁止留空或写 `待建立`/`none`/`未知`**，否则 Codex 启动时无法做行业匹配，会被迫从零做细分筛选。
- 若 Primary Wiki Topic 尚未创建，写目标 `<industry_id>` 并注明 `(topic to be created via $industry-wiki at 细分筛选确认)`。

| Wiki Topic | 类型 | Scope 匹配 | Last verified | Source status / Freshness | 复用/更新内容 | 项目本地证据处理 |
|---|---|---|---|---|---|---|
| | industry / technology-landscape | exact / adjacent / none | | verified/partial；fresh/update required | | 打开原始来源并重新分配本地 ID；工作假设不作证据 |

## 8. 关键假设与限制

- 待补充。

## 9. 特殊约束

- 待补充。

## 10. 专业反馈

项目特有纠正写入 `notes/professional-feedback.md`，此处只保留摘要和链接。
